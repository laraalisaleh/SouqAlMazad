-- SouqAlMazad Expert Integrity Check Queries
USE souqalmazad;

-- 1) Users missing subtype rows
SELECT u.*
FROM `user` u
LEFT JOIN buyer b ON u.user_id=b.user_id AND u.user_type='buyer'
LEFT JOIN seller s ON u.user_id=s.user_id AND u.user_type='seller'
LEFT JOIN `admin` a ON u.user_id=a.user_id AND u.user_type='admin'
WHERE (u.user_type='buyer' AND b.buyer_id IS NULL)
   OR (u.user_type='seller' AND s.seller_id IS NULL)
   OR (u.user_type='admin' AND a.admin_id IS NULL);

-- 2) Auction/both products without auction record
SELECT p.*
FROM product p
LEFT JOIN auction a ON p.product_id=a.product_id
WHERE p.sale_type IN ('auction','both')
  AND p.is_active=TRUE
  AND a.auction_id IS NULL;

-- 3) Active/upcoming auctions whose products are inactive
SELECT a.*, p.title, p.is_active
FROM auction a
JOIN product p ON a.product_id=p.product_id
WHERE a.status IN ('active','upcoming')
  AND p.is_active=FALSE;

-- 4) Orders without payment
SELECT o.*
FROM `order` o
LEFT JOIN payment p ON o.order_id=p.order_id
WHERE p.payment_id IS NULL;

-- 5) Orders without shipment
SELECT o.*
FROM `order` o
LEFT JOIN shipment s ON o.order_id=s.order_id
WHERE s.shipment_id IS NULL;

-- 6) Products with negative stock
SELECT *
FROM product
WHERE stock_quantity < 0;

-- 7) Ended auctions with bids but no winner
SELECT a.auction_id, p.title, COUNT(b.bid_id) AS bids
FROM auction a
JOIN product p ON a.product_id=p.product_id
LEFT JOIN bid b ON a.auction_id=b.auction_id
WHERE a.status='ended'
GROUP BY a.auction_id, p.title, a.winner_buyer_id
HAVING bids > 0 AND a.winner_buyer_id IS NULL;
