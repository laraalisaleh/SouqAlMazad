# db_helper.py
# SouqAlMazad database helper — compatible with your provided MySQL schema.
# Tables used: `user`, buyer, seller, `admin`, product, category, store, auction, bid, `order`,
# order_item, payment, shipment, review, product_image, notification, report.

import os
from datetime import datetime
from decimal import Decimal
from dotenv import load_dotenv
import mysql.connector

load_dotenv()

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "souqalmazad"),
}


def connect():
    return mysql.connector.connect(**DB_CONFIG)


def _fetch_all(query, params=None):
    conn = connect()
    cur = conn.cursor(dictionary=True)
    cur.execute(query, params or ())
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def _fetch_one(query, params=None):
    rows = _fetch_all(query, params)
    return rows[0] if rows else None


def _execute(query, params=None):
    conn = connect()
    cur = conn.cursor()
    cur.execute(query, params or ())
    conn.commit()
    last_id = cur.lastrowid
    cur.close()
    conn.close()
    return last_id


def _column_exists(table_name, column_name):
    row = _fetch_one("""
        SELECT COUNT(*) AS c
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = %s
          AND COLUMN_NAME = %s
    """, (table_name, column_name))
    return bool(row and row.get("c"))


def _store_description_column():
    # Project schema uses store_description, but this keeps the app working if DB was created with description.
    return "store_description" if _column_exists("store", "store_description") else "description"


def _validate_seller_id(seller_id):
    try:
        seller_id = int(str(seller_id).strip())
    except (TypeError, ValueError):
        raise ValueError("Seller ID must be a valid number.")
    seller = _fetch_one("SELECT seller_id FROM seller WHERE seller_id=%s", (seller_id,))
    if not seller:
        raise ValueError(f"Invalid Seller ID {seller_id}. Choose an existing seller from the Users/Sellers data.")
    return seller_id



def _try_log(action, entity_type=None, entity_id=None, details=None):
    """Optional: logs activity if activity_log table exists. Never breaks the app."""
    try:
        _execute(
            """INSERT INTO activity_log (action, entity_type, entity_id, details)
               VALUES (%s, %s, %s, %s)""",
            (action, entity_type, entity_id, details),
        )
    except Exception:
        pass


# ---------------- Dashboard ----------------

def get_stats():
    users = _fetch_one("SELECT COUNT(*) AS c FROM `user`")["c"]
    products = _fetch_one("SELECT COUNT(*) AS c FROM product WHERE is_active=TRUE")["c"]
    orders = _fetch_one("SELECT COUNT(*) AS c FROM `order`")["c"]
    auctions = _fetch_one("SELECT COUNT(*) AS c FROM auction WHERE status='active'")["c"]
    return {"users": users, "products": products, "orders": orders, "auctions": auctions}


def get_dashboard_analytics():
    """Extra analytics for future dashboard improvements."""
    revenue = _fetch_one("""
        SELECT COALESCE(SUM(final_amount), 0) AS revenue
        FROM `order`
        WHERE status IN ('confirmed','processing','shipped','delivered')
    """)["revenue"]

    top_products = _fetch_all("""
        SELECT p.product_id, p.title, COALESCE(SUM(oi.quantity),0) AS sold_qty
        FROM product p
        LEFT JOIN order_item oi ON p.product_id=oi.product_id
        GROUP BY p.product_id, p.title
        ORDER BY sold_qty DESC
        LIMIT 5
    """)

    top_stores = _fetch_all("""
        SELECT s.store_id, s.store_name, COALESCE(SUM(oi.subtotal),0) AS revenue
        FROM store s
        LEFT JOIN order_item oi ON s.store_id=oi.store_id
        GROUP BY s.store_id, s.store_name
        ORDER BY revenue DESC
        LIMIT 5
    """)

    pending_reports = _fetch_one("SELECT COUNT(*) AS c FROM report WHERE status='pending'")["c"]

    return {
        "revenue": float(revenue or 0),
        "top_products": top_products,
        "top_stores": top_stores,
        "pending_reports": pending_reports,
    }


# ---------------- Users ----------------

def get_all_users():
    return _fetch_all("""
        SELECT u.user_id, u.first_name, u.last_name, u.email, u.phone, u.user_type, u.is_active, u.created_at,
               b.buyer_id, se.seller_id, a.admin_id
        FROM `user` u
        LEFT JOIN buyer b ON u.user_id=b.user_id
        LEFT JOIN seller se ON u.user_id=se.user_id
        LEFT JOIN `admin` a ON u.user_id=a.user_id
        ORDER BY u.user_id DESC
    """)


def _ensure_subtype_for_user(user_id, user_type, first_name=None):
    """Create the required ISA subtype row if it does not already exist.
    We do not delete existing subtype rows because the project allows a user to also act as buyer/seller.
    """
    user_type = str(user_type or "buyer").strip().lower()
    if user_type == "buyer":
        if not _fetch_one("SELECT buyer_id FROM buyer WHERE user_id=%s", (user_id,)):
            _execute("INSERT INTO buyer (user_id, loyalty_points) VALUES (%s, 0)", (user_id,))
    elif user_type == "seller":
        if not _fetch_one("SELECT seller_id FROM seller WHERE user_id=%s", (user_id,)):
            _execute("INSERT INTO seller (user_id, business_name, is_verified) VALUES (%s, %s, FALSE)", (user_id, f"{first_name or 'Seller'} Store"))
    elif user_type == "admin":
        if not _fetch_one("SELECT admin_id FROM `admin` WHERE user_id=%s", (user_id,)):
            _execute("INSERT INTO `admin` (user_id, role, permissions) VALUES (%s, 'support', 'basic')", (user_id,))
    else:
        raise ValueError("Invalid user type.")


def add_user(first_name, last_name, email, password_hash="hash", phone=None, user_type="buyer"):
    first_name = str(first_name).strip()
    last_name = str(last_name).strip()
    email = str(email).strip()
    phone = str(phone or "").strip()
    user_type = str(user_type or "buyer").strip().lower()
    if user_type not in {"buyer", "seller", "admin"}:
        raise ValueError("Invalid user type.")

    conn = connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            INSERT INTO `user` (first_name, last_name, email, password_hash, phone, user_type)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (first_name, last_name, email, password_hash or "hash", phone, user_type))
        user_id = cur.lastrowid
        if user_type == "buyer":
            cur.execute("INSERT INTO buyer (user_id, loyalty_points) VALUES (%s, 0)", (user_id,))
        elif user_type == "seller":
            cur.execute("INSERT INTO seller (user_id, business_name, is_verified) VALUES (%s, %s, FALSE)", (user_id, f"{first_name} Store"))
        elif user_type == "admin":
            cur.execute("INSERT INTO `admin` (user_id, role, permissions) VALUES (%s, 'support', 'basic')", (user_id,))
        conn.commit()
        _try_log("add_user", "user", user_id, email)
        return user_id
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def update_user(user_id, first_name, last_name, email, phone, user_type=None):
    user_id = int(user_id)
    first_name = str(first_name).strip()
    last_name = str(last_name).strip()
    email = str(email).strip()
    phone = str(phone or "").strip()
    if user_type is not None:
        user_type = str(user_type).strip().lower()
        if user_type not in {"buyer", "seller", "admin"}:
            raise ValueError("Invalid user type.")
        _execute("""
            UPDATE `user`
            SET first_name=%s, last_name=%s, email=%s, phone=%s, user_type=%s
            WHERE user_id=%s
        """, (first_name, last_name, email, phone, user_type, user_id))
        _ensure_subtype_for_user(user_id, user_type, first_name)
    else:
        _execute("""
            UPDATE `user`
            SET first_name=%s, last_name=%s, email=%s, phone=%s
            WHERE user_id=%s
        """, (first_name, last_name, email, phone, user_id))
    _try_log("update_user", "user", user_id, email)


def delete_user(user_id):
    # Delete dependents first to avoid foreign-key errors.
    buyer = _fetch_one("SELECT buyer_id FROM buyer WHERE user_id=%s", (user_id,))
    if buyer:
        bid = buyer["buyer_id"]
        _execute("UPDATE auction SET winner_buyer_id=NULL WHERE winner_buyer_id=%s", (bid,))
        _execute("DELETE FROM wishlist WHERE buyer_id=%s", (bid,))
        _execute("DELETE FROM bid WHERE buyer_id=%s", (bid,))
        _execute("DELETE FROM review WHERE buyer_id=%s", (bid,))
        orders = _fetch_all("SELECT order_id FROM `order` WHERE buyer_id=%s", (bid,))
        for o in orders:
            oid = o["order_id"]
            _execute("DELETE FROM shipment WHERE order_id=%s", (oid,))
            _execute("DELETE FROM payment WHERE order_id=%s", (oid,))
            _execute("DELETE FROM review WHERE order_id=%s", (oid,))
            _execute("DELETE FROM order_item WHERE order_id=%s", (oid,))
        _execute("DELETE FROM `order` WHERE buyer_id=%s", (bid,))
        _execute("DELETE FROM buyer WHERE buyer_id=%s", (bid,))

    seller = _fetch_one("SELECT seller_id FROM seller WHERE user_id=%s", (user_id,))
    if seller:
        sid = seller["seller_id"]
        stores = _fetch_all("SELECT store_id FROM store WHERE seller_id=%s", (sid,))
        for st in stores:
            delete_store(st["store_id"])
        _execute("DELETE FROM seller WHERE seller_id=%s", (sid,))

    admin = _fetch_one("SELECT admin_id FROM `admin` WHERE user_id=%s", (user_id,))
    if admin:
        _execute("UPDATE report SET admin_id=NULL WHERE admin_id=%s", (admin["admin_id"],))
        _execute("DELETE FROM `admin` WHERE admin_id=%s", (admin["admin_id"],))

    _execute("DELETE FROM report WHERE reporter_id=%s", (user_id,))
    _execute("DELETE FROM notification WHERE user_id=%s", (user_id,))
    _execute("DELETE FROM `user` WHERE user_id=%s", (user_id,))
    _try_log("delete_user", "user", user_id, None)


# ---------------- Products ----------------

def get_all_products():
    return _fetch_all("""
        SELECT
            p.product_id, p.store_id, p.category_id,
            p.title, p.description, p.price, p.stock_quantity,
            p.sale_type, p.item_condition, p.is_active, p.view_count,
            s.store_name,
            c.name AS category,
            pi.image_url AS primary_image
        FROM product p
        JOIN store s ON p.store_id=s.store_id
        JOIN category c ON p.category_id=c.category_id
        LEFT JOIN product_image pi
            ON p.product_id=pi.product_id AND pi.is_primary=TRUE
        WHERE p.is_active=TRUE
        ORDER BY p.product_id DESC
    """)



def _validate_product_refs(store_id, category_id):
    """Validate Product foreign keys before INSERT/UPDATE so the UI shows a clear message instead of MySQL FK error 1452."""
    try:
        store_id = int(store_id)
        category_id = int(category_id)
    except (TypeError, ValueError):
        raise ValueError("Store ID and Category ID must be valid numbers.")

    store = _fetch_one("SELECT store_id FROM store WHERE store_id=%s", (store_id,))
    if not store:
        raise ValueError(f"Invalid Store ID {store_id}. Choose an existing store from the Stores page.")

    category = _fetch_one("SELECT category_id FROM category WHERE category_id=%s", (category_id,))
    if not category:
        raise ValueError(f"Invalid Category ID {category_id}. Choose an existing category from the Categories page or add it first.")

    return store_id, category_id

def add_product(store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition):
    store_id, category_id = _validate_product_refs(store_id, category_id)
    product_id = _execute("""
        INSERT INTO product
        (store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
    """, (store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition))
    _try_log("add_product", "product", product_id, title)
    return product_id


def update_product(product_id, title, description, price, stock_quantity):
    """Backward-compatible product update."""
    _execute("""
        UPDATE product
        SET title=%s,
            description=%s,
            price=%s,
            stock_quantity=%s
        WHERE product_id=%s
    """, (title, description, float(price), int(stock_quantity), int(product_id)))
    _try_log("update_product", "product", product_id, title)


def update_product_full(product_id, store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition):
    """Full product update used by the final Products page."""
    store_id, category_id = _validate_product_refs(store_id, category_id)
    _execute("""
        UPDATE product
        SET store_id=%s,
            category_id=%s,
            title=%s,
            description=%s,
            price=%s,
            stock_quantity=%s,
            sale_type=%s,
            item_condition=%s
        WHERE product_id=%s
    """, (
        int(store_id),
        int(category_id),
        title,
        description,
        float(price),
        int(stock_quantity),
        sale_type,
        item_condition,
        int(product_id)
    ))
    _try_log("update_product_full", "product", product_id, title)


def delete_product(product_id):
    # Soft delete is safer for a marketplace database.
    # Also clean up active auctions for this product
    _execute("UPDATE auction SET status='cancelled' WHERE product_id=%s AND status='active'", (product_id,))
    _execute("UPDATE product SET is_active=FALSE WHERE product_id=%s", (product_id,))
    _try_log("soft_delete_product", "product", product_id, None)


def set_product_image(product_id, image_url, is_primary=True):
    if is_primary:
        _execute("UPDATE product_image SET is_primary=FALSE WHERE product_id=%s", (product_id,))
    image_id = _execute("""
        INSERT INTO product_image (product_id, image_url, is_primary, display_order)
        VALUES (%s, %s, %s, 0)
    """, (product_id, image_url, is_primary))
    _try_log("set_product_image", "product", product_id, image_url)
    return image_id


# ---------------- Orders ----------------

def get_all_orders():
    return _fetch_all("""
        SELECT
            o.order_id,
            u.first_name,
            u.last_name,
            o.order_type,
            o.shipping_address,
            o.total_amount,
            o.discount_amount,
            o.final_amount,
            o.status,
            sh.status AS shipment_status,
            p.status AS payment_status,
            o.created_at
        FROM `order` o
        JOIN buyer b ON o.buyer_id=b.buyer_id
        JOIN `user` u ON b.user_id=u.user_id
        LEFT JOIN shipment sh ON o.order_id=sh.order_id
        LEFT JOIN payment p ON o.order_id=p.order_id
        ORDER BY o.order_id DESC
    """)


def update_order_status(order_id, status):
    valid = {"pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"}
    if status not in valid:
        raise ValueError("Invalid order status.")
    old = _fetch_one("SELECT status FROM `order` WHERE order_id=%s", (order_id,))
    if not old:
        raise ValueError("Order ID does not exist.")
    old_status = str(old.get("status") or "").lower()
    if old_status in {"cancelled", "returned"} and status not in {"cancelled", "returned"}:
        raise ValueError("Cancelled/returned orders cannot be moved back to active statuses because stock was already restored.")
    if status in {"cancelled", "returned"} and old_status not in {"cancelled", "returned"}:
        # Restock once when the order first becomes cancelled/returned.
        items = _fetch_all("SELECT product_id, quantity FROM order_item WHERE order_id=%s", (order_id,))
        for it in items:
            _execute("UPDATE product SET stock_quantity=stock_quantity+%s WHERE product_id=%s", (it.get("quantity") or 0, it.get("product_id")))
    _execute("UPDATE `order` SET status=%s WHERE order_id=%s", (status, order_id))
    _sync_order_related_statuses(order_id, status)
    _safe_notify(_order_buyer_user_id(order_id), "order_update", "Order status updated", f"Order #{order_id} is now {status}.")
    _try_log("update_order_status", "order", order_id, status)


def update_shipment_status(order_id, status):
    if not _fetch_one("SELECT order_id FROM `order` WHERE order_id=%s", (order_id,)):
        raise ValueError("Order ID does not exist.")
    valid = {"preparing", "shipped", "in_transit", "delivered", "returned"}
    if status not in valid:
        raise ValueError("Invalid shipment status.")
    exists = _fetch_one("SELECT shipment_id FROM shipment WHERE order_id=%s", (order_id,))
    if exists:
        _execute("UPDATE shipment SET status=%s WHERE order_id=%s", (status, order_id))
    else:
        _execute("INSERT INTO shipment (order_id, status) VALUES (%s, %s)", (order_id, status))
    _safe_notify(_order_buyer_user_id(order_id), "order_update", "Shipment status updated", f"Shipment for order #{order_id} is now {status}.")
    _try_log("update_shipment_status", "order", order_id, status)


def update_payment_status(order_id, status):
    if not _fetch_one("SELECT order_id FROM `order` WHERE order_id=%s", (order_id,)):
        raise ValueError("Order ID does not exist.")
    valid = {"pending", "completed", "failed", "refunded"}
    if status not in valid:
        raise ValueError("Invalid payment status.")
    exists = _fetch_one("SELECT payment_id FROM payment WHERE order_id=%s", (order_id,))
    if exists:
        _execute("UPDATE payment SET status=%s, paid_at=CASE WHEN %s='completed' THEN COALESCE(paid_at, NOW()) ELSE paid_at END WHERE order_id=%s", (status, status, order_id))
    else:
        order = _fetch_one("SELECT final_amount FROM `order` WHERE order_id=%s", (order_id,))
        if not order:
            raise ValueError("Order ID does not exist.")
        _execute("INSERT INTO payment (order_id, payment_method, amount, status, paid_at) VALUES (%s, 'cash_on_delivery', %s, %s, CASE WHEN %s='completed' THEN NOW() ELSE NULL END)", (order_id, order.get('final_amount') or 0, status, status))
    _safe_notify(_order_buyer_user_id(order_id), "order_update", "Payment status updated", f"Payment for order #{order_id} is now {status}.")
    _try_log("update_payment_status", "order", order_id, status)


def delete_order(order_id):
    order_id = int(order_id)
    order = _fetch_one("SELECT status FROM `order` WHERE order_id=%s", (order_id,))
    if not order:
        raise ValueError("Order ID does not exist.")
    # If the order had already reduced stock, deleting it should not leave inventory missing.
    if str(order.get("status") or "").lower() not in {"cancelled", "returned"}:
        items = _fetch_all("SELECT product_id, quantity FROM order_item WHERE order_id=%s", (order_id,))
        for it in items:
            _execute("UPDATE product SET stock_quantity=stock_quantity+%s WHERE product_id=%s", (it.get("quantity") or 0, it.get("product_id")))
    _execute("DELETE FROM shipment WHERE order_id=%s", (order_id,))
    _execute("DELETE FROM payment WHERE order_id=%s", (order_id,))
    _execute("DELETE FROM review WHERE order_id=%s", (order_id,))
    _execute("DELETE FROM order_item WHERE order_id=%s", (order_id,))
    _execute("DELETE FROM `order` WHERE order_id=%s", (order_id,))
    _try_log("delete_order", "order", order_id, None)


# ---------------- Auctions / Bids ----------------

def get_auctions():
    return _fetch_all("""
        SELECT
            a.auction_id,
            a.product_id,
            p.title AS product_title,
            s.store_name,
            a.starting_price,
            a.reserve_price,
            a.current_highest,
            a.start_time,
            a.end_time,
            a.status,
            a.winner_buyer_id,
            CONCAT(wu.first_name, ' ', wu.last_name) AS winner_name,
            COUNT(b.bid_id) AS bid_count
        FROM auction a
        JOIN product p ON a.product_id=p.product_id
        JOIN store s ON p.store_id=s.store_id
        LEFT JOIN buyer wb ON a.winner_buyer_id=wb.buyer_id
        LEFT JOIN `user` wu ON wb.user_id=wu.user_id
        LEFT JOIN bid b ON a.auction_id=b.auction_id
        GROUP BY a.auction_id, a.product_id, p.title, s.store_name, a.starting_price,
                 a.reserve_price, a.current_highest, a.start_time, a.end_time,
                 a.status, a.winner_buyer_id, wu.first_name, wu.last_name
        ORDER BY
            CASE a.status WHEN 'active' THEN 1 WHEN 'upcoming' THEN 2 WHEN 'ended' THEN 3 ELSE 4 END,
            a.end_time ASC
    """)


def place_bid(auction_id, buyer_id, bid_amount):
    """Place a bid atomically only if the auction is active and the bid is higher than current_highest."""
    auction_id = int(auction_id)
    buyer_id = resolve_buyer_id(buyer_id)
    bid_amount = float(bid_amount)
    if bid_amount <= 0:
        raise ValueError("Bid amount must be greater than zero.")
    if not _fetch_one("SELECT buyer_id FROM buyer WHERE buyer_id=%s", (buyer_id,)):
        raise ValueError("Buyer ID does not exist.")

    conn = connect()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute("""
            SELECT auction_id, current_highest, starting_price, status, winner_buyer_id
            FROM auction
            WHERE auction_id=%s
            FOR UPDATE
        """, (auction_id,))
        auc = cur.fetchone()
        if not auc:
            raise ValueError("Auction not found.")
        if str(auc.get("status", "")).lower() != "active":
            raise ValueError("This auction is not active.")
        current = float(auc.get("current_highest") or 0)
        starting = float(auc.get("starting_price") or 0)
        if bid_amount < starting:
            raise ValueError(f"Bid must be at least the starting price (${starting:,.2f}).")
        if bid_amount <= current:
            raise ValueError(f"Bid must be higher than current highest bid (${current:,.2f}).")

        previous_winner = auc.get("winner_buyer_id")
        cur.execute("UPDATE bid SET is_winning=FALSE WHERE auction_id=%s", (auction_id,))
        cur.execute("""
            INSERT INTO bid (auction_id, buyer_id, bid_amount, is_winning)
            VALUES (%s, %s, %s, TRUE)
        """, (auction_id, buyer_id, bid_amount))
        bid_id = cur.lastrowid
        cur.execute("UPDATE auction SET current_highest=%s, winner_buyer_id=%s WHERE auction_id=%s", (bid_amount, buyer_id, auction_id))
        conn.commit()

        if previous_winner and int(previous_winner) != int(buyer_id):
            _safe_notify(_get_user_id_from_buyer(previous_winner), "outbid", "You were outbid", f"A higher bid was placed on auction #{auction_id}.")
        _safe_notify(_get_user_id_from_buyer(buyer_id), "system", "Bid placed", f"Your bid of ${bid_amount:,.2f} was placed on auction #{auction_id}.")
        _try_log("place_bid", "auction", auction_id, f"buyer={buyer_id}, amount={bid_amount}")
        return bid_id
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def get_all_reviews():
    return _fetch_all("""
        SELECT
            r.review_id,
            p.title,
            u.first_name,
            u.last_name,
            r.rating,
            r.comment,
            r.created_at
        FROM review r
        JOIN product p ON r.product_id=p.product_id
        JOIN buyer b ON r.buyer_id=b.buyer_id
        JOIN `user` u ON b.user_id=u.user_id
        ORDER BY r.created_at DESC
    """)


def add_review(product_id, buyer_id, order_id, rating, comment):
    buyer_id = resolve_buyer_id(buyer_id)
    if int(rating) < 1 or int(rating) > 5:
        raise ValueError("Rating must be between 1 and 5.")
    exists = _fetch_one("""
        SELECT oi.order_item_id
        FROM order_item oi
        JOIN `order` o ON oi.order_id=o.order_id
        WHERE oi.product_id=%s AND o.buyer_id=%s AND o.order_id=%s
    """, (product_id, buyer_id, order_id))
    if not exists:
        raise ValueError("Review rejected: this buyer did not purchase this product in this order.")
    review_id = _execute("""
        INSERT INTO review (product_id, buyer_id, order_id, rating, comment)
        VALUES (%s, %s, %s, %s, %s)
    """, (product_id, buyer_id, order_id, rating, comment))
    _try_log("add_review", "review", review_id, comment)
    return review_id


# ---------------- Reports / Notifications / Stores ----------------

def get_pending_reports():
    return _fetch_all("""
        SELECT r.*, u.first_name, u.last_name
        FROM report r
        JOIN `user` u ON r.reporter_id=u.user_id
        WHERE r.status='pending'
        ORDER BY r.created_at DESC
    """)


def update_report_status(report_id, status):
    allowed = {"pending", "reviewed", "resolved", "dismissed"}
    status = str(status).strip().lower()
    if status == "reviewing":
        status = "reviewed"
    if status not in allowed:
        raise ValueError("Invalid report status. Use pending, reviewed, resolved, or dismissed.")
    report = _fetch_one("SELECT report_id, reporter_id, admin_id FROM report WHERE report_id=%s", (report_id,))
    if not report:
        raise ValueError("Report ID does not exist.")
    admin = _fetch_one("SELECT admin_id FROM `admin` ORDER BY admin_id LIMIT 1")
    admin_id = report.get("admin_id") or (admin.get("admin_id") if admin else None)
    if status in {"resolved", "dismissed"}:
        _execute("UPDATE report SET status=%s, admin_id=%s, resolved_at=NOW() WHERE report_id=%s", (status, admin_id, report_id))
    else:
        _execute("UPDATE report SET status=%s, admin_id=%s, resolved_at=NULL WHERE report_id=%s", (status, admin_id, report_id))
    _safe_notify(report.get("reporter_id"), "system", "Report status updated", f"Your report #{report_id} is now {status}.")
    _try_log("update_report_status", "report", report_id, status)


def get_stores():
    desc_col = _store_description_column()
    return _fetch_all(f"""
        SELECT s.*, s.{desc_col} AS description, u.first_name, u.last_name
        FROM store s
        JOIN seller se ON s.seller_id=se.seller_id
        JOIN `user` u ON se.user_id=u.user_id
        ORDER BY s.store_id DESC
    """)


# ---------------- Final UI helper functions ----------------

def get_product_by_id(product_id):
    return _fetch_one("""
        SELECT
            p.product_id, p.store_id, p.category_id,
            p.title, p.description, p.price, p.stock_quantity,
            p.sale_type, p.item_condition, p.is_active, p.view_count,
            s.store_name,
            c.name AS category,
            pi.image_url AS primary_image
        FROM product p
        JOIN store s ON p.store_id=s.store_id
        JOIN category c ON p.category_id=c.category_id
        LEFT JOIN product_image pi
            ON p.product_id=pi.product_id AND pi.is_primary=TRUE
        WHERE p.product_id=%s
    """, (int(product_id),))


def get_buyers_for_dropdown():
    return _fetch_all("""
        SELECT b.buyer_id, b.user_id, u.first_name, u.last_name, u.email
        FROM buyer b
        JOIN `user` u ON b.user_id=u.user_id
        ORDER BY b.buyer_id
    """)


def get_active_products_for_auction():
    return _fetch_all("""
        SELECT product_id, title, price
        FROM product
        WHERE is_active=TRUE AND sale_type IN ('auction','both')
        ORDER BY product_id DESC
    """)


def create_auction(product_id, starting_price, reserve_price, start_time, end_time, status='active'):
    product_id = int(product_id)
    starting_price = float(starting_price)
    reserve_price = None if reserve_price in (None, "") else float(reserve_price)
    if starting_price <= 0:
        raise ValueError("Starting price must be greater than zero.")
    if reserve_price is not None and reserve_price < starting_price:
        raise ValueError("Reserve price cannot be less than starting price.")
    try:
        st = datetime.strptime(str(start_time), "%Y-%m-%d %H:%M:%S")
        et = datetime.strptime(str(end_time), "%Y-%m-%d %H:%M:%S")
    except ValueError:
        raise ValueError("Start/end time must use YYYY-MM-DD HH:MM:SS format.")
    if et <= st:
        raise ValueError("Auction end time must be after start time.")
    product = _fetch_one("SELECT product_id, sale_type FROM product WHERE product_id=%s AND is_active=TRUE", (product_id,))
    if not product:
        raise ValueError("Product does not exist or is inactive.")
    if product.get("sale_type") not in ("auction", "both"):
        raise ValueError("Only auction/both products can have auctions.")
    active = _fetch_one("SELECT auction_id FROM auction WHERE product_id=%s AND status IN ('upcoming','active')", (product_id,))
    if active:
        raise ValueError("This product already has an upcoming/active auction.")
    auction_id = _execute("""
        INSERT INTO auction
        (product_id, starting_price, reserve_price, current_highest, start_time, end_time, status)
        VALUES (%s, %s, %s, 0, %s, %s, %s)
    """, (product_id, starting_price, reserve_price, start_time, end_time, status))
    _try_log("create_auction", "auction", auction_id, f"product={product_id}")
    return auction_id


def update_auction_status(auction_id, status):
    status = str(status).strip().lower()
    allowed = {"upcoming", "active", "ended", "cancelled"}
    if status not in allowed:
        raise ValueError("Invalid auction status.")
    if status == "ended":
        order_id = close_auction_and_create_order(auction_id)
        _try_log("update_auction_status", "auction", auction_id, f"ended order={order_id}")
        return order_id
    _execute("UPDATE auction SET status=%s WHERE auction_id=%s", (status, auction_id))
    _try_log("update_auction_status", "auction", auction_id, status)
    return None


def get_auction_bid_history(auction_id):
    return _fetch_all("""
        SELECT bi.bid_id, bi.bid_amount, bi.bid_time, bi.is_winning,
               u.first_name, u.last_name, b.buyer_id
        FROM bid bi
        JOIN buyer b ON bi.buyer_id=b.buyer_id
        JOIN `user` u ON b.user_id=u.user_id
        WHERE bi.auction_id=%s
        ORDER BY bi.bid_amount DESC, bi.bid_time DESC
    """, (auction_id,))


# ---------------- Stores ----------------

def add_store(seller_id, store_name, description=""):
    seller_id = resolve_seller_id(seller_id)
    store_name = str(store_name).strip()
    description = str(description).strip()
    if not store_name:
        raise ValueError("Store name is required.")
    desc_col = _store_description_column()
    store_id = _execute(f"""
        INSERT INTO store (seller_id, store_name, {desc_col})
        VALUES (%s, %s, %s)
    """, (seller_id, store_name, description))
    _try_log("add_store", "store", store_id, store_name)
    return store_id


def update_store(store_id, store_name, description):
    try:
        store_id = int(str(store_id).strip())
    except (TypeError, ValueError):
        raise ValueError("Store ID must be selected before updating.")
    store_name = str(store_name).strip()
    description = str(description).strip()
    if not store_name:
        raise ValueError("Store name is required.")
    existing = _fetch_one("SELECT store_id FROM store WHERE store_id=%s", (store_id,))
    if not existing:
        raise ValueError(f"Store ID {store_id} does not exist.")
    desc_col = _store_description_column()
    _execute(f"""
        UPDATE store SET store_name=%s, {desc_col}=%s WHERE store_id=%s
    """, (store_name, description, store_id))
    _try_log("update_store", "store", store_id, store_name)


def delete_store(store_id):
    store_id = int(store_id)
    if not _fetch_one("SELECT store_id FROM store WHERE store_id=%s", (store_id,)):
        raise ValueError("Store ID does not exist.")
    # Soft delete keeps historical orders valid and prevents broken order totals/details.
    products = _fetch_all("SELECT product_id FROM product WHERE store_id=%s", (store_id,))
    for pr in products:
        pid = pr["product_id"]
        _execute("UPDATE auction SET status='cancelled' WHERE product_id=%s AND status IN ('upcoming','active')", (pid,))
        _execute("UPDATE product SET is_active=FALSE WHERE product_id=%s", (pid,))
    _execute("UPDATE store SET is_active=FALSE WHERE store_id=%s", (store_id,))
    _try_log("soft_delete_store", "store", store_id, None)


# ---------------- Categories ----------------

def get_categories():
    return _fetch_all("""
        SELECT c.category_id, c.name, c.description,
               COUNT(p.product_id) AS product_count
        FROM category c
        LEFT JOIN product p ON c.category_id=p.category_id AND p.is_active=TRUE
        GROUP BY c.category_id, c.name, c.description
        ORDER BY c.name
    """)


def add_category(name, description=""):
    name = str(name).strip()
    description = str(description or "").strip()
    if not name:
        raise ValueError("Category name is required.")
    cat_id = _execute("""
        INSERT INTO category (name, description) VALUES (%s, %s)
    """, (name, description))
    _try_log("add_category", "category", cat_id, name)
    return cat_id


def update_category(category_id, name, description):
    name = str(name).strip()
    description = str(description or "").strip()
    if not name:
        raise ValueError("Category name is required.")
    _execute("""
        UPDATE category SET name=%s, description=%s WHERE category_id=%s
    """, (name, description, category_id))
    _try_log("update_category", "category", category_id, name)


def delete_category(category_id):
    count = _fetch_one("SELECT COUNT(*) AS c FROM product WHERE category_id=%s AND is_active=TRUE", (category_id,))
    if count and count["c"] > 0:
        raise ValueError(f"Cannot delete: {count['c']} active products use this category.")
    _execute("DELETE FROM category WHERE category_id=%s", (category_id,))
    _try_log("delete_category", "category", category_id, None)


# ---------------- Wishlist ----------------

def get_wishlist():
    return _fetch_all("""
        SELECT w.wishlist_id, w.buyer_id, w.product_id, w.added_at,
               u.first_name, u.last_name,
               p.title AS product_title, p.price
        FROM wishlist w
        JOIN buyer b ON w.buyer_id=b.buyer_id
        JOIN `user` u ON b.user_id=u.user_id
        JOIN product p ON w.product_id=p.product_id
        ORDER BY w.added_at DESC
    """)


def add_wishlist(buyer_id, product_id):
    buyer_id = resolve_buyer_id(buyer_id)
    product_id = int(product_id)
    product = _fetch_one("SELECT product_id FROM product WHERE product_id=%s AND is_active=TRUE", (product_id,))
    if not product:
        raise ValueError("Product does not exist or is inactive.")
    existing = _fetch_one(
        "SELECT wishlist_id FROM wishlist WHERE buyer_id=%s AND product_id=%s",
        (buyer_id, product_id)
    )
    if existing:
        raise ValueError("This product is already in the buyer's wishlist.")
    wid = _execute("""
        INSERT INTO wishlist (buyer_id, product_id) VALUES (%s, %s)
    """, (buyer_id, product_id))
    _try_log("add_wishlist", "wishlist", wid, f"buyer={buyer_id}, product={product_id}")
    return wid


def remove_wishlist(wishlist_id):
    _execute("DELETE FROM wishlist WHERE wishlist_id=%s", (wishlist_id,))
    _try_log("remove_wishlist", "wishlist", wishlist_id, None)


# ---------------- Notifications ----------------

def get_notifications():
    return _fetch_all("""
        SELECT n.notification_id, n.user_id, n.type, n.title, n.content,
               n.is_read, n.created_at,
               u.first_name, u.last_name
        FROM notification n
        JOIN `user` u ON n.user_id=u.user_id
        ORDER BY n.created_at DESC
    """)


def add_notification(user_id, notif_type, title, content=""):
    allowed = {"outbid", "auction_won", "order_update", "new_message", "promotion", "system"}
    notif_type = str(notif_type or "system").strip().lower()
    if notif_type not in allowed:
        notif_type = "system"
    if not _fetch_one("SELECT user_id FROM `user` WHERE user_id=%s", (int(user_id),)):
        raise ValueError("Notification user_id does not exist.")
    nid = _execute("""
        INSERT INTO notification (user_id, type, title, content)
        VALUES (%s, %s, %s, %s)
    """, (user_id, notif_type, title, content))
    _try_log("add_notification", "notification", nid, title)
    return nid


def mark_notification_read(notification_id):
    _execute("UPDATE notification SET is_read=TRUE WHERE notification_id=%s", (notification_id,))


def delete_notification(notification_id):
    _execute("DELETE FROM notification WHERE notification_id=%s", (notification_id,))


# ---------------- Reports (UI support) ----------------

def get_all_reports():
    return _fetch_all("""
        SELECT r.report_id, r.reporter_id, r.reported_type, r.reported_id,
               r.reason, r.description, r.status, r.created_at, r.resolved_at,
               u.first_name, u.last_name
        FROM report r
        JOIN `user` u ON r.reporter_id=u.user_id
        ORDER BY
            CASE r.status WHEN 'pending' THEN 1 WHEN 'reviewed' THEN 2 ELSE 3 END,
            r.created_at DESC
    """)


def add_report(reporter_id, reported_type, reported_id, reason, description=""):
    reporter_id = int(reporter_id)
    reported_id = int(reported_id)
    reported_type = str(reported_type).strip().lower()
    reason = str(reason).strip().lower()
    if reported_type not in {"product", "store", "user"}:
        raise ValueError("Reported type must be product, store, or user.")
    if reason not in {"fake_product", "scam", "inappropriate", "harassment", "other"}:
        raise ValueError("Invalid report reason.")
    if not _fetch_one("SELECT user_id FROM `user` WHERE user_id=%s", (reporter_id,)):
        raise ValueError("Reporter User ID does not exist.")
    if reported_type == "product" and not _fetch_one("SELECT product_id FROM product WHERE product_id=%s", (reported_id,)):
        raise ValueError("Reported product does not exist.")
    if reported_type == "store" and not _fetch_one("SELECT store_id FROM store WHERE store_id=%s", (reported_id,)):
        raise ValueError("Reported store does not exist.")
    if reported_type == "user" and not _fetch_one("SELECT user_id FROM `user` WHERE user_id=%s", (reported_id,)):
        raise ValueError("Reported user does not exist.")
    rid = _execute("""
        INSERT INTO report (reporter_id, reported_type, reported_id, reason, description)
        VALUES (%s, %s, %s, %s, %s)
    """, (reporter_id, reported_type, reported_id, reason, description))
    for admin in _fetch_all("SELECT user_id FROM `admin` a JOIN `user` u ON a.user_id=u.user_id"):
        _safe_notify(admin.get("user_id"), "system", "New report submitted", f"Report #{rid} needs review.")
    _try_log("add_report", "report", rid, reason)
    return rid


# ---------------- Order Creation ----------------

def create_order(buyer_id, order_type, shipping_address, items, payment_method="cash_on_delivery"):
    """Create a full order with items, payment, and shipment.
    items = list of dicts: [{"product_id": ..., "store_id": ..., "quantity": ..., "unit_price": ...}, ...]
    """
    buyer_id = resolve_buyer_id(buyer_id)
    payment_method = str(payment_method or "cash_on_delivery").strip()
    if payment_method not in {"credit_card", "paypal", "cash_on_delivery"}:
        payment_method = "cash_on_delivery"
    total = sum(float(i["unit_price"]) * int(i["quantity"]) for i in items)

    order_id = _execute("""
        INSERT INTO `order` (buyer_id, order_type, shipping_address, total_amount, discount_amount, final_amount, status)
        VALUES (%s, %s, %s, %s, 0, %s, 'pending')
    """, (buyer_id, order_type, shipping_address, total, total))

    for item in items:
        subtotal = float(item["unit_price"]) * int(item["quantity"])
        _execute("""
            INSERT INTO order_item (order_id, product_id, store_id, quantity, unit_price, subtotal)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (order_id, item["product_id"], item["store_id"], item["quantity"], item["unit_price"], subtotal))

    _execute("""
        INSERT INTO payment (order_id, amount, payment_method, status)
        VALUES (%s, %s, %s, 'pending')
    """, (order_id, total, payment_method))

    _execute("""
        INSERT INTO shipment (order_id, status)
        VALUES (%s, 'preparing')
    """, (order_id,))

    _try_log("create_order", "order", order_id, f"buyer={buyer_id}, total={total}")
    return order_id


# ---------------- Order Details ----------------

def get_order_items(order_id):
    # LEFT JOIN keeps details working even if a referenced product/store was deleted/deactivated.
    return _fetch_all("""
        SELECT oi.order_item_id, oi.product_id,
               COALESCE(p.title, CONCAT('Product #', oi.product_id)) AS title,
               oi.store_id,
               COALESCE(s.store_name, CONCAT('Store #', oi.store_id)) AS store_name,
               oi.quantity, oi.unit_price, oi.subtotal
        FROM order_item oi
        LEFT JOIN product p ON oi.product_id=p.product_id
        LEFT JOIN store s ON oi.store_id=s.store_id
        WHERE oi.order_id=%s
        ORDER BY oi.order_item_id
    """, (order_id,))


def get_order_payment(order_id):
    return _fetch_one("""
        SELECT payment_id, amount, payment_method AS method, status, paid_at
        FROM payment
        WHERE order_id=%s
        ORDER BY payment_id DESC
        LIMIT 1
    """, (order_id,))


def get_order_shipment(order_id):
    return _fetch_one("""
        SELECT shipment_id, tracking_number, carrier_name AS carrier, status, shipped_at, actual_delivery AS delivered_at
        FROM shipment
        WHERE order_id=%s
        ORDER BY shipment_id DESC
        LIMIT 1
    """, (order_id,))


# ---------------- Sellers dropdown ----------------

def get_sellers_for_dropdown():
    return _fetch_all("""
        SELECT se.seller_id, u.first_name, u.last_name, se.business_name
        FROM seller se
        JOIN `user` u ON se.user_id=u.user_id
        ORDER BY se.seller_id
    """)


# ---------------- Chart Analytics ----------------

def get_orders_by_status():
    return _fetch_all("""
        SELECT status, COUNT(*) AS count
        FROM `order`
        GROUP BY status
        ORDER BY count DESC
    """)


def get_top_products_sold():
    return _fetch_all("""
        SELECT p.title, COALESCE(SUM(oi.quantity), 0) AS sold
        FROM product p
        LEFT JOIN order_item oi ON p.product_id=oi.product_id
        GROUP BY p.product_id, p.title
        HAVING sold > 0
        ORDER BY sold DESC
        LIMIT 6
    """)


def get_revenue_by_month():
    return _fetch_all("""
        SELECT DATE_FORMAT(created_at, '%Y-%m') AS month,
               COALESCE(SUM(final_amount), 0) AS revenue
        FROM `order`
        WHERE status IN ('confirmed','processing','shipped','delivered')
        GROUP BY month
        ORDER BY month DESC
        LIMIT 6
    """)


def get_auctions_by_status():
    return _fetch_all("""
        SELECT status, COUNT(*) AS count
        FROM auction
        GROUP BY status
    """)


def get_total_revenue():
    r = _fetch_one("""
        SELECT COALESCE(SUM(final_amount), 0) AS total
        FROM `order`
        WHERE status IN ('confirmed','processing','shipped','delivered')
    """)
    return float(r["total"] or 0) if r else 0.0




# ---------------- Automated Business Helpers ----------------

def _get_user_id_from_buyer(buyer_id):
    row = _fetch_one("SELECT user_id FROM buyer WHERE buyer_id=%s", (int(buyer_id),))
    return row["user_id"] if row else None


def _get_user_id_from_seller(seller_id):
    row = _fetch_one("SELECT user_id FROM seller WHERE seller_id=%s", (int(seller_id),))
    return row["user_id"] if row else None


def resolve_buyer_id(identifier):
    """Accept either buyer.buyer_id or user.user_id and return the real buyer_id."""
    try:
        ident = int(str(identifier).strip())
    except (TypeError, ValueError):
        raise ValueError("Buyer/User ID must be a valid number.")
    row = _fetch_one("SELECT buyer_id FROM buyer WHERE buyer_id=%s", (ident,))
    if row:
        return int(row["buyer_id"])
    row = _fetch_one("SELECT buyer_id FROM buyer WHERE user_id=%s", (ident,))
    if row:
        return int(row["buyer_id"])
    raise ValueError("No Buyer profile found for this ID. Enter a real buyer_id or a user_id that has a Buyer row.")


def resolve_seller_id(identifier):
    """Accept either seller.seller_id or user.user_id and return the real seller_id."""
    try:
        ident = int(str(identifier).strip())
    except (TypeError, ValueError):
        raise ValueError("Seller/User ID must be a valid number.")
    row = _fetch_one("SELECT seller_id FROM seller WHERE seller_id=%s", (ident,))
    if row:
        return int(row["seller_id"])
    row = _fetch_one("SELECT seller_id FROM seller WHERE user_id=%s", (ident,))
    if row:
        return int(row["seller_id"])
    raise ValueError("No Seller profile found for this ID. Enter a real seller_id or a user_id that has a Seller row.")


def _safe_notify(user_id, notif_type, title, content=""):
    try:
        if user_id:
            add_notification(int(user_id), notif_type, title, content)
    except Exception:
        pass


def _order_buyer_user_id(order_id):
    row = _fetch_one("""
        SELECT b.user_id
        FROM `order` o
        JOIN buyer b ON o.buyer_id=b.buyer_id
        WHERE o.order_id=%s
    """, (int(order_id),))
    return row["user_id"] if row else None


def _sync_order_related_statuses(order_id, order_status):
    """Small automation layer so Order, Shipment and Payment do not contradict each other."""
    order_status = str(order_status).strip().lower()
    if order_status == "processing":
        update_shipment_status(order_id, "preparing")
    elif order_status == "shipped":
        update_shipment_status(order_id, "shipped")
    elif order_status == "delivered":
        update_shipment_status(order_id, "delivered")
        pay = _fetch_one("SELECT payment_method, status FROM payment WHERE order_id=%s", (int(order_id),))
        if pay and pay.get("status") == "pending":
            update_payment_status(order_id, "completed")
    elif order_status == "cancelled":
        pay = _fetch_one("SELECT status FROM payment WHERE order_id=%s", (int(order_id),))
        if pay and pay.get("status") == "completed":
            update_payment_status(order_id, "refunded")
    elif order_status == "returned":
        update_shipment_status(order_id, "returned")
        pay = _fetch_one("SELECT status FROM payment WHERE order_id=%s", (int(order_id),))
        if pay and pay.get("status") == "completed":
            update_payment_status(order_id, "refunded")


def close_auction_and_create_order(auction_id):
    """End an auction automatically and atomically.
    If reserve is met, create an auction_win order for the winning buyer and reduce product stock once.
    """
    auction_id = int(auction_id)
    conn = connect()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute("""
            SELECT a.auction_id, a.product_id, a.reserve_price, a.current_highest, a.winner_buyer_id, a.status,
                   p.store_id, p.stock_quantity, p.title
            FROM auction a
            JOIN product p ON a.product_id=p.product_id
            WHERE a.auction_id=%s
            FOR UPDATE
        """, (auction_id,))
        auc = cur.fetchone()
        if not auc:
            raise ValueError("Auction not found.")
        if str(auc.get("status") or "").lower() == "ended":
            cur.execute("""
                SELECT o.order_id
                FROM `order` o
                JOIN order_item oi ON o.order_id=oi.order_id
                WHERE o.order_type='auction_win' AND oi.product_id=%s
                ORDER BY o.order_id DESC LIMIT 1
            """, (auc.get("product_id"),))
            existing = cur.fetchone()
            conn.commit()
            return existing["order_id"] if existing else None

        winner = auc.get("winner_buyer_id")
        highest = float(auc.get("current_highest") or 0)
        reserve = auc.get("reserve_price")
        if not winner:
            cur.execute("UPDATE auction SET status='ended' WHERE auction_id=%s", (auction_id,))
            conn.commit()
            return None
        if reserve is not None and highest < float(reserve):
            cur.execute("UPDATE auction SET status='ended', winner_buyer_id=NULL WHERE auction_id=%s", (auction_id,))
            conn.commit()
            _safe_notify(_get_user_id_from_buyer(winner), "system", "Auction ended without sale", f"Reserve price was not met for {auc.get('title')}.")
            return None
        if int(auc.get("stock_quantity") or 0) <= 0:
            raise ValueError("Cannot finalize auction because product stock is zero.")

        cur.execute("""
            SELECT o.order_id
            FROM `order` o
            JOIN order_item oi ON o.order_id=oi.order_id
            WHERE o.order_type='auction_win' AND o.buyer_id=%s AND oi.product_id=%s AND oi.unit_price=%s
            ORDER BY o.order_id DESC LIMIT 1
        """, (winner, auc.get("product_id"), highest))
        existing = cur.fetchone()
        if existing:
            cur.execute("UPDATE auction SET status='ended' WHERE auction_id=%s", (auction_id,))
            conn.commit()
            return existing["order_id"]

        cur.execute("""
            INSERT INTO `order` (buyer_id, order_type, shipping_address, total_amount, discount_amount, final_amount, status)
            VALUES (%s, 'auction_win', %s, %s, 0, %s, 'pending')
        """, (winner, "Auction win - address to be confirmed", highest, highest))
        order_id = cur.lastrowid
        cur.execute("""
            INSERT INTO order_item (order_id, product_id, store_id, quantity, unit_price, subtotal)
            VALUES (%s, %s, %s, 1, %s, %s)
        """, (order_id, auc.get("product_id"), auc.get("store_id"), highest, highest))
        cur.execute("INSERT INTO payment (order_id, amount, payment_method, status) VALUES (%s, %s, 'cash_on_delivery', 'pending')", (order_id, highest))
        cur.execute("INSERT INTO shipment (order_id, status) VALUES (%s, 'preparing')", (order_id,))
        cur.execute("UPDATE product SET stock_quantity=stock_quantity-1 WHERE product_id=%s", (auc.get("product_id"),))
        cur.execute("UPDATE auction SET status='ended' WHERE auction_id=%s", (auction_id,))
        conn.commit()

        _safe_notify(_get_user_id_from_buyer(winner), "auction_won", "You won an auction", f"You won {auc.get('title')} for ${highest:,.2f}. Order #{order_id} was created.")
        _try_log("close_auction", "auction", auction_id, f"order={order_id}")
        return order_id
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()

# ---------------- Role-Based User UI Support ----------------

def get_user_role_profile(user_id):
    """Return the linked buyer/seller/admin ids for one user account.
    This supports the project rule that one user may also be a buyer and seller if both subtype rows exist.
    """
    user = _fetch_one("""
        SELECT user_id, first_name, last_name, email, user_type, is_active
        FROM `user`
        WHERE user_id=%s
    """, (int(user_id),))
    if not user:
        raise ValueError("User ID does not exist.")
    buyer = _fetch_one("SELECT buyer_id FROM buyer WHERE user_id=%s", (int(user_id),))
    seller = _fetch_one("SELECT seller_id FROM seller WHERE user_id=%s", (int(user_id),))
    admin = _fetch_one("SELECT admin_id FROM `admin` WHERE user_id=%s", (int(user_id),))
    user["buyer_id"] = buyer["buyer_id"] if buyer else None
    user["seller_id"] = seller["seller_id"] if seller else None
    user["admin_id"] = admin["admin_id"] if admin else None
    return user


def get_marketplace_products():
    """Products visible to buyers for direct purchase or browsing."""
    return _fetch_all("""
        SELECT
            p.product_id, p.store_id, p.category_id,
            p.title, p.description, p.price, p.stock_quantity,
            p.sale_type, p.item_condition, p.view_count,
            s.store_name, c.name AS category,
            pi.image_url AS primary_image
        FROM product p
        JOIN store s ON p.store_id=s.store_id
        JOIN category c ON p.category_id=c.category_id
        LEFT JOIN product_image pi ON p.product_id=pi.product_id AND pi.is_primary=TRUE
        WHERE p.is_active=TRUE
        ORDER BY p.product_id DESC
    """)


def direct_buy_product(buyer_id, product_id, quantity, shipping_address, payment_method="cash_on_delivery"):
    """Buyer checkout flow: accepts buyer_id or user_id, validates product, creates order/payment/shipment, and reduces stock atomically."""
    buyer_id = resolve_buyer_id(buyer_id)
    product_id = int(product_id)
    quantity = int(quantity)
    shipping_address = str(shipping_address).strip()
    payment_method = str(payment_method or "cash_on_delivery").strip()

    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero.")
    if not shipping_address:
        raise ValueError("Shipping address is required.")
    if payment_method not in {"credit_card", "paypal", "cash_on_delivery"}:
        raise ValueError("Invalid payment method.")
    if not _fetch_one("SELECT buyer_id FROM buyer WHERE buyer_id=%s", (buyer_id,)):
        raise ValueError("Buyer ID does not exist.")

    conn = connect()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute("""
            SELECT product_id, store_id, price, stock_quantity, sale_type, is_active, title
            FROM product
            WHERE product_id=%s
            FOR UPDATE
        """, (product_id,))
        product = cur.fetchone()
        if not product or not product.get("is_active"):
            raise ValueError("Product does not exist or is not active.")
        if product.get("sale_type") not in ("direct", "both"):
            raise ValueError("This product is auction-only, so it cannot be bought directly.")
        if int(product.get("stock_quantity") or 0) < quantity:
            raise ValueError("Not enough stock for this quantity.")

        total = float(product["price"]) * quantity
        cur.execute("""
            INSERT INTO `order` (buyer_id, order_type, shipping_address, total_amount, discount_amount, final_amount, status)
            VALUES (%s, 'direct', %s, %s, 0, %s, 'pending')
        """, (buyer_id, shipping_address, total, total))
        order_id = cur.lastrowid

        cur.execute("""
            INSERT INTO order_item (order_id, product_id, store_id, quantity, unit_price, subtotal)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (order_id, product_id, product["store_id"], quantity, product["price"], total))

        cur.execute("""
            INSERT INTO payment (order_id, amount, payment_method, status)
            VALUES (%s, %s, %s, 'pending')
        """, (order_id, total, payment_method))

        cur.execute("INSERT INTO shipment (order_id, status) VALUES (%s, 'preparing')", (order_id,))
        cur.execute("UPDATE product SET stock_quantity = stock_quantity - %s WHERE product_id=%s", (quantity, product_id))

        conn.commit()
        _safe_notify(_get_user_id_from_buyer(buyer_id), "order_update", "Order created", f"Order #{order_id} was created for {product['title']}.")
        _try_log("direct_buy_product", "order", order_id, f"buyer={buyer_id}, product={product_id}, qty={quantity}")
        return order_id
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def get_buyer_orders(buyer_id):
    buyer_id = resolve_buyer_id(buyer_id)
    return _fetch_all("""
        SELECT o.order_id, o.order_type, o.final_amount, o.status,
               p.status AS payment_status, sh.status AS shipment_status, o.created_at
        FROM `order` o
        LEFT JOIN payment p ON o.order_id=p.order_id
        LEFT JOIN shipment sh ON o.order_id=sh.order_id
        WHERE o.buyer_id=%s
        ORDER BY o.order_id DESC
    """, (int(buyer_id),))


def get_seller_stores(seller_id):
    seller_id = resolve_seller_id(seller_id)
    desc_col = _store_description_column()
    return _fetch_all(f"""
        SELECT store_id, seller_id, store_name, {desc_col} AS description, is_active, rating_avg, created_at
        FROM store
        WHERE seller_id=%s
        ORDER BY store_id DESC
    """, (int(seller_id),))


def get_seller_products(seller_id):
    seller_id = resolve_seller_id(seller_id)
    return _fetch_all("""
        SELECT p.product_id, p.store_id, s.store_name, p.title, p.price, p.stock_quantity,
               p.sale_type, p.item_condition, c.name AS category
        FROM product p
        JOIN store s ON p.store_id=s.store_id
        JOIN category c ON p.category_id=c.category_id
        WHERE s.seller_id=%s AND p.is_active=TRUE
        ORDER BY p.product_id DESC
    """, (int(seller_id),))


def get_seller_orders(seller_id):
    seller_id = resolve_seller_id(seller_id)
    return _fetch_all("""
        SELECT DISTINCT o.order_id, o.status, o.final_amount, o.created_at,
               u.first_name, u.last_name, s.store_name
        FROM `order` o
        JOIN order_item oi ON o.order_id=oi.order_id
        JOIN store s ON oi.store_id=s.store_id
        JOIN buyer b ON o.buyer_id=b.buyer_id
        JOIN `user` u ON b.user_id=u.user_id
        WHERE s.seller_id=%s
        ORDER BY o.order_id DESC
    """, (int(seller_id),))


def get_seller_auctions(seller_id):
    seller_id = resolve_seller_id(seller_id)
    return _fetch_all("""
        SELECT a.auction_id, a.product_id, p.title AS product_title,
               a.current_highest, a.starting_price, a.status, a.end_time,
               a.winner_buyer_id,
               CONCAT(wu.first_name, ' ', wu.last_name) AS winner_name,
               COUNT(b.bid_id) AS bid_count
        FROM auction a
        JOIN product p ON a.product_id=p.product_id
        JOIN store s ON p.store_id=s.store_id
        LEFT JOIN buyer wb ON a.winner_buyer_id=wb.buyer_id
        LEFT JOIN `user` wu ON wb.user_id=wu.user_id
        LEFT JOIN bid b ON a.auction_id=b.auction_id
        WHERE s.seller_id=%s
        GROUP BY a.auction_id, a.product_id, p.title, a.current_highest, a.starting_price,
                 a.status, a.end_time, a.winner_buyer_id, wu.first_name, wu.last_name
        ORDER BY a.auction_id DESC
    """, (int(seller_id),))


# ---------------- Seller Automation Actions ----------------

def seller_add_product(seller_id, store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition):
    """Seller-safe product creation: the store must belong to this seller."""
    seller_id = resolve_seller_id(seller_id)
    store_id, category_id = _validate_product_refs(store_id, category_id)
    store = _fetch_one("SELECT store_id FROM store WHERE store_id=%s AND seller_id=%s", (store_id, seller_id))
    if not store:
        raise ValueError("This Store ID does not belong to this seller.")
    return add_product(store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition)


def seller_create_auction(seller_id, product_id, starting_price, reserve_price, start_time, end_time):
    """Seller-safe auction creation: the product must belong to one of this seller's stores."""
    seller_id = resolve_seller_id(seller_id)
    row = _fetch_one("""
        SELECT p.product_id
        FROM product p
        JOIN store s ON p.store_id=s.store_id
        WHERE p.product_id=%s AND s.seller_id=%s
    """, (int(product_id), seller_id))
    if not row:
        raise ValueError("This Product ID does not belong to this seller.")
    return create_auction(product_id, starting_price, reserve_price, start_time, end_time, "active")


# ---------------- Auction Winner Lifecycle ----------------

def _notification_exists(user_id, title, content_like):
    row = _fetch_one("""
        SELECT notification_id
        FROM notification
        WHERE user_id=%s
          AND title=%s
          AND content LIKE %s
        LIMIT 1
    """, (int(user_id), title, f"%{content_like}%"))
    return bool(row)


def get_auction_winner(auction_id):
    """Return the highest bidder and auction/product/seller details."""
    return _fetch_one("""
        SELECT
            a.auction_id,
            a.product_id,
            a.current_highest,
            a.reserve_price,
            a.status,
            p.title AS product_title,
            p.store_id,
            p.stock_quantity,
            s.seller_id,
            su.user_id AS seller_user_id,
            su.first_name AS seller_first_name,
            su.last_name AS seller_last_name,
            b.bid_id,
            b.buyer_id,
            b.bid_amount,
            bu.user_id AS buyer_user_id,
            bu.first_name AS buyer_first_name,
            bu.last_name AS buyer_last_name
        FROM auction a
        JOIN product p ON a.product_id=p.product_id
        JOIN store st ON p.store_id=st.store_id
        JOIN seller s ON st.seller_id=s.seller_id
        JOIN `user` su ON s.user_id=su.user_id
        LEFT JOIN bid b ON b.auction_id=a.auction_id
             AND b.bid_amount = (
                SELECT MAX(b2.bid_amount)
                FROM bid b2
                WHERE b2.auction_id=a.auction_id
             )
        LEFT JOIN buyer byy ON b.buyer_id=byy.buyer_id
        LEFT JOIN `user` bu ON byy.user_id=bu.user_id
        WHERE a.auction_id=%s
        ORDER BY b.bid_amount DESC
        LIMIT 1
    """, (int(auction_id),))


def _auction_order_exists(buyer_id, product_id):
    return _fetch_one("""
        SELECT o.order_id
        FROM `order` o
        JOIN order_item oi ON o.order_id=oi.order_id
        WHERE o.buyer_id=%s
          AND oi.product_id=%s
          AND o.order_type='auction'
        ORDER BY o.order_id DESC
        LIMIT 1
    """, (int(buyer_id), int(product_id)))


def close_ended_auctions():
    """
    Complete ended auction lifecycle:
    - upcoming -> active when time starts
    - active/upcoming -> ended when time passes
    - choose highest bidder
    - notify winner, seller, and losing bidders
    - create auction order once for winner
    - avoid duplicate processing using notification marker
    """
    conn = connect()
    cur = conn.cursor(dictionary=True)
    processed = 0

    try:
        # First sync statuses
        cur.execute("""
            UPDATE auction
            SET status='active'
            WHERE status='upcoming'
              AND start_time <= NOW()
              AND end_time > NOW()
        """)

        cur.execute("""
            UPDATE auction
            SET status='ended'
            WHERE status IN ('upcoming','active')
              AND end_time <= NOW()
        """)

        # Find ended auctions that have not been finalized yet.
        cur.execute("""
            SELECT
                a.auction_id,
                a.product_id,
                a.current_highest,
                a.reserve_price,
                p.title AS product_title,
                p.store_id,
                p.stock_quantity,
                st.seller_id,
                su.user_id AS seller_user_id
            FROM auction a
            JOIN product p ON a.product_id=p.product_id
            JOIN store st ON p.store_id=st.store_id
            JOIN seller s ON st.seller_id=s.seller_id
            JOIN `user` su ON s.user_id=su.user_id
            WHERE a.status='ended'
        """)
        auctions = cur.fetchall()

        for a in auctions:
            auction_id = int(a["auction_id"])
            marker = f"[auction:{auction_id}]"

            # If seller already received finalization notification, skip.
            cur.execute("""
                SELECT notification_id
                FROM notification
                WHERE user_id=%s
                  AND title='Auction ended'
                  AND content LIKE %s
                LIMIT 1
            """, (a["seller_user_id"], f"%{marker}%"))
            if cur.fetchone():
                continue

            # Highest bid
            cur.execute("""
                SELECT b.bid_id, b.buyer_id, b.bid_amount, u.user_id AS buyer_user_id,
                       u.first_name, u.last_name
                FROM bid b
                JOIN buyer byy ON b.buyer_id=byy.buyer_id
                JOIN `user` u ON byy.user_id=u.user_id
                WHERE b.auction_id=%s
                ORDER BY b.bid_amount DESC, b.bid_time ASC
                LIMIT 1
            """, (auction_id,))
            winner = cur.fetchone()

            if not winner:
                # No bids: notify seller only.
                cur.execute("""
                    INSERT INTO notification (user_id, type, title, content)
                    VALUES (%s, 'system', 'Auction ended', %s)
                """, (a["seller_user_id"], f"{marker} Your auction for {a['product_title']} ended with no bids."))
                processed += 1
                continue

            final_bid = float(winner["bid_amount"] or 0)
            reserve = float(a["reserve_price"] or 0)

            if reserve > 0 and final_bid < reserve:
                # Reserve not met: notify seller and highest bidder.
                cur.execute("""
                    UPDATE auction
                    SET winner_buyer_id=NULL, current_highest=%s
                    WHERE auction_id=%s
                """, (final_bid, auction_id))
                cur.execute("""
                    INSERT INTO notification (user_id, type, title, content)
                    VALUES (%s, 'system', 'Auction ended', %s)
                """, (a["seller_user_id"], f"{marker} Auction for {a['product_title']} ended, but reserve price was not met. Highest bid: ${final_bid:,.2f}."))
                cur.execute("""
                    INSERT INTO notification (user_id, type, title, content)
                    VALUES (%s, 'system', 'Reserve not met', %s)
                """, (winner["buyer_user_id"], f"{marker} Your highest bid on {a['product_title']} did not meet the reserve price."))
                processed += 1
                continue

            # Set winner
            cur.execute("""
                UPDATE auction
                SET winner_buyer_id=%s, current_highest=%s
                WHERE auction_id=%s
            """, (winner["buyer_id"], final_bid, auction_id))

            # Create auction order once
            cur.execute("""
                SELECT o.order_id
                FROM `order` o
                JOIN order_item oi ON o.order_id=oi.order_id
                WHERE o.buyer_id=%s
                  AND oi.product_id=%s
                  AND o.order_type='auction'
                ORDER BY o.order_id DESC
                LIMIT 1
            """, (winner["buyer_id"], a["product_id"]))
            existing_order = cur.fetchone()
            order_id = existing_order["order_id"] if existing_order else None

            if not order_id:
                cur.execute("""
                    INSERT INTO `order` (buyer_id, order_type, shipping_address, total_amount, discount_amount, final_amount, status)
                    VALUES (%s, 'auction', 'To be confirmed by winner', %s, 0, %s, 'pending')
                """, (winner["buyer_id"], final_bid, final_bid))
                order_id = cur.lastrowid

                cur.execute("""
                    INSERT INTO order_item (order_id, product_id, store_id, quantity, unit_price, subtotal)
                    VALUES (%s, %s, %s, 1, %s, %s)
                """, (order_id, a["product_id"], a["store_id"], final_bid, final_bid))

                cur.execute("""
                    INSERT INTO payment (order_id, amount, payment_method, status)
                    VALUES (%s, %s, 'cash_on_delivery', 'pending')
                """, (order_id, final_bid))

                cur.execute("""
                    INSERT INTO shipment (order_id, status)
                    VALUES (%s, 'preparing')
                """, (order_id,))

                # Reduce stock by 1 if available. Avoid negative stock.
                cur.execute("""
                    UPDATE product
                    SET stock_quantity = CASE WHEN stock_quantity > 0 THEN stock_quantity - 1 ELSE 0 END
                    WHERE product_id=%s
                """, (a["product_id"],))

            winner_name = f"{winner.get('first_name','')} {winner.get('last_name','')}".strip()

            # Notify winner
            cur.execute("""
                INSERT INTO notification (user_id, type, title, content)
                VALUES (%s, 'auction_won', 'You won an auction!', %s)
            """, (winner["buyer_user_id"], f"{marker} Congratulations! You won {a['product_title']} with a final bid of ${final_bid:,.2f}. Order #{order_id} was created."))

            # Notify seller
            cur.execute("""
                INSERT INTO notification (user_id, type, title, content)
                VALUES (%s, 'auction_won', 'Auction ended', %s)
            """, (a["seller_user_id"], f"{marker} {winner_name} won {a['product_title']} with ${final_bid:,.2f}. Order #{order_id} was created."))

            # Notify losing bidders once each
            cur.execute("""
                SELECT DISTINCT byy.user_id
                FROM bid b
                JOIN buyer byy ON b.buyer_id=byy.buyer_id
                WHERE b.auction_id=%s
                  AND b.buyer_id<>%s
            """, (auction_id, winner["buyer_id"]))
            losers = cur.fetchall()
            for loser in losers:
                cur.execute("""
                    INSERT INTO notification (user_id, type, title, content)
                    VALUES (%s, 'system', 'Auction ended', %s)
                """, (loser["user_id"], f"{marker} Auction for {a['product_title']} ended. Another buyer won with ${final_bid:,.2f}."))

            processed += 1

        conn.commit()
        return processed

    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def get_auction_winner_display(auction_id):
    return _fetch_one("""
        SELECT a.auction_id, a.winner_buyer_id, a.current_highest,
               p.title AS product_title,
               u.first_name, u.last_name
        FROM auction a
        JOIN product p ON a.product_id=p.product_id
        LEFT JOIN buyer b ON a.winner_buyer_id=b.buyer_id
        LEFT JOIN `user` u ON b.user_id=u.user_id
        WHERE a.auction_id=%s
    """, (int(auction_id),))


def add_product_with_optional_auction(store_id, category_id, title, description, price, stock_quantity,
                                      sale_type, item_condition, starting_price=None, reserve_price=None,
                                      start_time=None, end_time=None):
    """
    Seller workflow:
    - Always creates Product.
    - If sale_type is auction/both, also creates Auction in the same transaction.
    This prevents product type='auction' existing without auction record.
    """
    store_id, category_id = _validate_product_refs(store_id, category_id)
    sale_type = str(sale_type or "direct").strip().lower()
    item_condition = str(item_condition or "new").strip().lower()

    if sale_type not in {"direct", "auction", "both"}:
        raise ValueError("Invalid sale type.")
    if item_condition not in {"new", "used", "refurbished"}:
        raise ValueError("Invalid item condition.")

    conn = connect()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute("""
            INSERT INTO product
            (store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        """, (store_id, category_id, title, description, price, stock_quantity, sale_type, item_condition))
        product_id = cur.lastrowid
        auction_id = None

        if sale_type in ("auction", "both"):
            if not starting_price or not start_time or not end_time:
                raise ValueError("Auction products require Starting Price, Start Time, and End Time.")

            sp = float(starting_price)
            rp = None if reserve_price in (None, "") else float(reserve_price)
            if sp <= 0:
                raise ValueError("Starting price must be greater than zero.")
            if rp is not None and rp < sp:
                raise ValueError("Reserve price cannot be less than starting price.")

            try:
                st = datetime.strptime(str(start_time), "%Y-%m-%d %H:%M:%S")
                et = datetime.strptime(str(end_time), "%Y-%m-%d %H:%M:%S")
            except ValueError:
                raise ValueError("Start/end time must use YYYY-MM-DD HH:MM:SS format.")

            if et <= st:
                raise ValueError("Auction end time must be after start time.")

            status = "active" if st <= datetime.now() < et else "upcoming"
            if et <= datetime.now():
                raise ValueError("Auction end time must be in the future.")

            cur.execute("""
                INSERT INTO auction
                (product_id, starting_price, reserve_price, current_highest, start_time, end_time, status)
                VALUES (%s, %s, %s, 0, %s, %s, %s)
            """, (product_id, sp, rp, start_time, end_time, status))
            auction_id = cur.lastrowid

        conn.commit()
        _try_log("add_product_with_optional_auction", "product", product_id, f"sale_type={sale_type}, auction_id={auction_id}")
        return {"product_id": product_id, "auction_id": auction_id}

    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


# ---------------- Final Polish Helpers ----------------

def update_order_shipping_address(order_id, buyer_id, shipping_address):
    order_id = int(order_id)
    buyer_id = resolve_buyer_id(buyer_id)
    shipping_address = str(shipping_address or "").strip()
    if not shipping_address:
        raise ValueError("Shipping address is required.")
    order_row = _fetch_one("""
        SELECT order_id, order_type
        FROM `order`
        WHERE order_id=%s AND buyer_id=%s
    """, (order_id, buyer_id))
    if not order_row:
        raise ValueError("Order not found for this buyer.")
    _execute("""
        UPDATE `order`
        SET shipping_address=%s
        WHERE order_id=%s AND buyer_id=%s
    """, (shipping_address, order_id, buyer_id))
    _safe_notify(_get_user_id_from_buyer(buyer_id), "order_update", "Shipping address confirmed", f"Shipping address for order #{order_id} was confirmed.")
    _try_log("update_order_shipping_address", "order", order_id, shipping_address)


def get_auction_bids(auction_id):
    return _fetch_all("""
        SELECT b.bid_id, b.auction_id, b.buyer_id, b.bid_amount, b.bid_time, b.is_winning,
               u.first_name, u.last_name
        FROM bid b
        JOIN buyer byy ON b.buyer_id=byy.buyer_id
        JOIN `user` u ON byy.user_id=u.user_id
        WHERE b.auction_id=%s
        ORDER BY b.bid_amount DESC, b.bid_time ASC
    """, (int(auction_id),))


def deactivate_report_target(report_id):
    rp = _fetch_one("SELECT * FROM report WHERE report_id=%s", (int(report_id),))
    if not rp:
        raise ValueError("Report not found.")
    rtype = str(rp.get("reported_type") or "").lower()
    rid = int(rp.get("reported_id"))
    if rtype == "product":
        _execute("UPDATE product SET is_active=FALSE WHERE product_id=%s", (rid,))
    elif rtype == "user":
        _execute("UPDATE `user` SET is_active=FALSE WHERE user_id=%s", (rid,))
    elif rtype == "store":
        try:
            delete_store(rid)
        except Exception:
            _execute("UPDATE store SET is_active=FALSE WHERE store_id=%s", (rid,))
    else:
        raise ValueError("Unsupported reported_type for deactivate action.")
    _execute("UPDATE report SET status='resolved' WHERE report_id=%s", (int(report_id),))
    _try_log("deactivate_report_target", "report", report_id, f"{rtype}:{rid}")


# ---------------- Admin Safe Delete / Deactivate Helpers ----------------

def deactivate_seller_by_user_id(user_id):
    """
    Safely deactivate a seller account:
    - deactivate seller's user account
    - deactivate seller's stores
    - deactivate seller's products
    - cancel active/upcoming auctions for seller products
    Keeps historical orders, reviews, and bids safe.
    """
    user_id = int(user_id)
    seller = _fetch_one("SELECT seller_id FROM seller WHERE user_id=%s", (user_id,))
    if not seller:
        raise ValueError("Selected user is not a seller.")
    seller_id = int(seller["seller_id"])

    conn = connect()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute("UPDATE `user` SET is_active=FALSE WHERE user_id=%s", (user_id,))

        cur.execute("SELECT store_id FROM store WHERE seller_id=%s", (seller_id,))
        stores = cur.fetchall()
        for st in stores:
            store_id = st["store_id"]
            cur.execute("UPDATE store SET is_active=FALSE WHERE store_id=%s", (store_id,))
            cur.execute("SELECT product_id FROM product WHERE store_id=%s", (store_id,))
            products = cur.fetchall()
            for pr in products:
                pid = pr["product_id"]
                cur.execute("UPDATE auction SET status='cancelled' WHERE product_id=%s AND status IN ('upcoming','active')", (pid,))
                cur.execute("UPDATE product SET is_active=FALSE WHERE product_id=%s", (pid,))

        conn.commit()
        _try_log("deactivate_seller_by_user_id", "user", user_id, f"seller_id={seller_id}")
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def deactivate_buyer_by_user_id(user_id):
    """
    Safely deactivate a buyer account without deleting order/bid history.
    """
    user_id = int(user_id)
    buyer = _fetch_one("SELECT buyer_id FROM buyer WHERE user_id=%s", (user_id,))
    if not buyer:
        raise ValueError("Selected user is not a buyer.")
    _execute("UPDATE `user` SET is_active=FALSE WHERE user_id=%s", (user_id,))
    _try_log("deactivate_buyer_by_user_id", "user", user_id, f"buyer_id={buyer['buyer_id']}")


def deactivate_admin_by_user_id(user_id, current_admin_user_id=None):
    """
    Deactivate admin account. Prevent self-deactivation when current admin user id is provided.
    """
    user_id = int(user_id)
    if current_admin_user_id is not None and int(current_admin_user_id) == user_id:
        raise ValueError("You cannot deactivate your own admin account while logged in.")
    adm = _fetch_one("SELECT admin_id FROM `admin` WHERE user_id=%s", (user_id,))
    if not adm:
        raise ValueError("Selected user is not an admin.")
    _execute("UPDATE `user` SET is_active=FALSE WHERE user_id=%s", (user_id,))
    _try_log("deactivate_admin_by_user_id", "user", user_id, f"admin_id={adm['admin_id']}")


def deactivate_user_cascade(user_id, current_admin_user_id=None):
    """
    Role-aware safe delete for Admin Users screen.
    Uses soft-delete/deactivate, not hard delete, to preserve database integrity.
    """
    user = _fetch_one("SELECT user_id, user_type FROM `user` WHERE user_id=%s", (int(user_id),))
    if not user:
        raise ValueError("User does not exist.")
    role = str(user.get("user_type") or "").lower()
    if role == "seller":
        deactivate_seller_by_user_id(user_id)
    elif role == "buyer":
        deactivate_buyer_by_user_id(user_id)
    elif role == "admin":
        deactivate_admin_by_user_id(user_id, current_admin_user_id)
    else:
        _execute("UPDATE `user` SET is_active=FALSE WHERE user_id=%s", (int(user_id),))
        _try_log("deactivate_user_cascade", "user", user_id, role)


# ---------------- Profile Image Helpers ----------------

def save_user_profile_image_path(user_id, image_path):
    """
    Optional DB sync for profile image.
    Works only if the user table has one of these optional columns:
    profile_image, profile_image_path, image_url, avatar_url
    If no column exists, the app still uses local profile_images folder.
    """
    user_id = int(user_id)
    image_path = str(image_path or "").strip()
    if not _fetch_one("SELECT user_id FROM `user` WHERE user_id=%s", (user_id,)):
        raise ValueError("User does not exist.")

    for col in ("profile_image", "profile_image_path", "image_url", "avatar_url"):
        try:
            if _column_exists("user", col):
                _execute(f"UPDATE `user` SET {col}=%s WHERE user_id=%s", (image_path, user_id))
                return True
        except Exception:
            pass
    return False


def get_user_profile_image_path(user_id):
    """
    Optional DB read for profile image path if schema supports it.
    """
    user_id = int(user_id)
    for col in ("profile_image", "profile_image_path", "image_url", "avatar_url"):
        try:
            if _column_exists("user", col):
                row = _fetch_one(f"SELECT {col} AS img FROM `user` WHERE user_id=%s", (user_id,))
                if row and row.get("img"):
                    return row.get("img")
        except Exception:
            pass
    return None
