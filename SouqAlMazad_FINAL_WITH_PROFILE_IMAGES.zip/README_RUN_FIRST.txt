# SouqAlMazad Buyer UI Fix

Fixed:
- Ended auctions no longer show a bidding action.
- Hero auction button is disabled when auction is ended/upcoming.
- Live auctions now show animated countdown labels that update every second.
- Ended auctions show regret-style cards only, no bid button.
- Buyer bid function now checks auction status before trying to bid.
- Notifications now support:
  - Mark Selected Read
  - Mark Selected Unread
  - Mark All Read
  - Mark All Unread
  - Delete Selected

Run:
pip install -r requirements.txt
python souqalmazad_marketplace.py


## Admin/Seller UI updates
- Admin sidebar uses the same light sidebar style as Buyer.
- Admin All Products is now a product gallery with photos and upload image by Product ID.
- Admin Orders now clearly shows Order Status, Payment Status, and Shipment Status.
- Admin can update Shipment status directly.
- Seller sidebar uses the same style.
- Seller My Products is now a product gallery with photos, stock labels, and upload image by Product ID.
- Seller Add Product now shows the new Product ID clearly and provides a separate image upload by ID.


## Login/Register background update
- Added optimized background image under the first login/register screens.
- Added cinematic glass-style login panel.
- Added live visual auction timer effect.
- Added lightweight cards and glow styling without heavy animations.
- Background is compressed and resized to avoid slowing the app.


## Seller My Products update
- Removed the top Product Image Studio bar.
- Added Edit Product panel directly inside My Products.
- Seller can select a product card, edit title, description, price, stock, sale type, and condition.
- Seller can upload image from the edit panel or from product card.


## Seller Product Delete
- Added Delete button in Seller My Products edit panel.
- Added Delete button on every product card.
- Delete asks for confirmation.
- Uses soft delete with is_active=FALSE when available to protect order history.


## Auction visibility fix
- Added auction status synchronization before Buyer Live Auctions opens.
- Seller-created auctions with start_time <= NOW() and end_time > NOW() automatically become active.
- Expired auctions automatically become ended.
- Buyer page now also shows upcoming auctions as Coming Soon, but disables bidding until active.


## Final Auction Winner Lifecycle
Added professional auction finalization:
- Automatically syncs upcoming/active/ended auction statuses.
- Detects highest bidder when auction ends.
- Checks reserve price.
- Saves winner_buyer_id in auction.
- Creates an auction order for the winner once.
- Creates payment and shipment records for auction order.
- Reduces product stock by 1 without going negative.
- Sends notification to winner.
- Sends notification to seller.
- Sends notification to losing bidders.
- Prevents duplicate winner notifications/orders using auction notification marker.
- Buyer, Seller, and Admin auction screens show winner name after auction ends.

Recommended final discussion note:
Auction order uses shipping address "To be confirmed by winner" because the buyer should confirm delivery details after winning.


## Product -> Auction workflow fix
- Seller Add Product now has Auction Details fields.
- If sale_type is auction or both, the system creates Product + Auction together in one transaction.
- Seller must set starting price, reserve price, start time, and end time.
- If start time is now and end time is future, auction becomes active and appears to buyers.
- If start time is future, auction becomes upcoming and appears as Coming Soon.
- This fixes the issue where auction/both products were created without an auction record.


# SouqAlMazad FINAL AUDIT REPORT

- ✅ App Python compile
- ✅ DB helper Python compile
- ✅ requirements.txt dependencies: customtkinter, pillow, mysql-connector-python, python-dotenv, matplotlib
- ✅ assets/product_images folders
- ✅ Login cinematic/background helpers
- ✅ Real glass effect helper
- ✅ Buyer notifications read/unread/all
- ✅ Seller edit product
- ✅ Seller delete product
- ✅ Product creates auction
- ✅ Auction lifecycle close function
- ✅ Auction status sync
- ✅ Winner notifications
- ✅ Admin shipment update
- ✅ Winner shown in auctions
- ✅ Patched seller auction quick time
- ✅ DB datetime import
- ✅ Bid amount column assumption: Uses existing project db_helper convention: bid_amount
- ✅ Product image storage: Uses product_images/<product_id>.* plus optional db.set_product_image
- ✅ Duplicate auction finalization protection
- ✅ DB function references: All referenced db functions found
- ✅ Internal method references: OK
- ✅ Final compile after patches


## Final workflow coverage
✅ Buyer can browse products, buy direct products, bid on active auctions, view orders, wishlist, and notifications.
✅ Seller can add products, upload images, edit products, delete products, and create auctions automatically when sale_type is auction/both.
✅ Admin can view/manage products, orders, payments, shipments, auctions, users, reports, notifications.
✅ Auction lifecycle is complete: upcoming → active → ended → winner detection → order/payment/shipment → notifications.
✅ Database integrity is protected with foreign keys and transaction-based flows where critical.
✅ Soft delete is preferred for products to preserve order history.

## How to run
```bash
pip install -r requirements.txt
python souqalmazad_marketplace.py
```

## Important testing notes
1. For Seller Add Product:
   - If Sale Type = direct, auction fields are ignored.
   - If Sale Type = auction/both, fill Starting Price, Start Time, End Time.
   - Use format: YYYY-MM-DD HH:MM:SS
   - Button Start Now + 1h fills time quickly.

2. For Buyer Auctions:
   - Active auctions accept bids.
   - Upcoming auctions appear as Coming Soon.
   - Ended auctions show winner or no winner.

3. For auction winner:
   - Winner is highest bidder.
   - If reserve_price is not reached, no order is created.
   - If winner exists, auction order/payment/shipment are created automatically.


## Admin Stores/Categories navigation fix
- Added Stores to Admin sidebar.
- Added Categories to Admin sidebar.
- Added Admin Stores screen with Add/Update/Soft Delete.
- Added Admin Categories screen with Add/Update/Delete.
- Category delete is protected if active products use it.
- Store delete is soft delete and deactivates store products/active auctions.



# SouqAlMazad FINAL POLISHED BUILD

Added final requested improvements:
- Admin can create Admin users from Admin > All Users.
- Buyer can confirm shipping address for auction orders.
- Auction Details popup shows auction information and full bid history.
- Buyer/Seller/Admin can view auction details.
- Seller My Auctions changed from dry table to clear auction cards.
- Reports now support Resolve, Dismiss, and Deactivate Target actions.
- Admin Stores and Categories are available in sidebar.
- Product type auction/both creates an auction record with start/end time.
- Auction lifecycle includes winner detection, notifications, payment, shipment, and order creation.

Debug:
- App compile OK.
- DB helper compile OK.
- Final ZIP packaged.



# Delete / Deactivate Final Additions

Added:
- Role-aware safe delete for users.
- Seller safe delete:
  - deactivates seller user account
  - deactivates all seller stores
  - deactivates all products in those stores
  - cancels upcoming/active auctions for those products
  - preserves old orders, bids, reviews, and reports
- Buyer safe delete:
  - deactivates buyer account while preserving orders/bids
- Admin safe delete:
  - deactivates admin account
  - prevents currently logged-in admin from deleting herself/himself
- Store deletion is clearly treated as deactivate/soft delete.
- App and db_helper compile OK.


# SouqAlMazad Expert Review

## What I checked
- Python compile for app and db_helper.
- Missing db function references.
- Duplicate function definitions.
- Buyer/Seller/Admin navigation coverage.
- Auction lifecycle coverage.
- Safe delete behavior.
- Login/security behavior.
- Data-integrity risks.

## Critical issues found and fixed
1. Deactivated users could still log in because login did not check is_active.
   Fixed: Login now blocks inactive accounts.

2. A universal demo password bypass existed: pw == "123456".
   Fixed: Removed this bypass. Login now accepts only stored password formats.

3. Login did not stop users with missing ISA subtype rows.
   Fixed: Login now blocks buyer/seller/admin accounts if the matching subtype row is missing.

4. Admin created new users with a fixed unclear password value.
   Fixed: Admin > All Users now has a Password field and saves it as hash+password.

## Strong features already present
- Full Buyer/Seller/Admin role separation.
- Admin Stores and Categories.
- Seller product edit/delete/upload.
- Product auction/both creates real auction record.
- Auction lifecycle: upcoming → active → ended → winner → order/payment/shipment → notifications.
- Buyer confirms auction shipping address.
- Reports actions: resolve/dismiss/deactivate target.
- Safe delete/deactivate for Seller/Buyer/Admin.

## Remaining recommendation
The project package still depends on an existing MySQL database. I added EXPERT_INTEGRITY_CHECKS.sql to help verify the database state in DBeaver before the demo.


# Profile Image Feature Added

Added:
- Circular profile image in sidebar for all roles: Buyer, Seller, Admin.
- My Profile page added to every sidebar.
- Profile page shows user information and subtype IDs.
- Upload / Change Image button.
- Images stored locally in profile_images/<user_id>.<ext>.
- If the database has profile_image/profile_image_path/image_url/avatar_url column in user table, the path is also saved there.
- If no image exists, the app shows a circular initials placeholder.
- App and db_helper compile OK.
