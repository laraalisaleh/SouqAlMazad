# souqalmazad_marketplace.py
# full marketplace with login + role-based dashboards
# each user type gets their own interface
#
# pip install customtkinter pillow mysql-connector-python python-dotenv

from pathlib import Path
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import hashlib
import shutil

import customtkinter as ctk
import db_helper as db

try:
    from PIL import Image, ImageDraw, ImageOps
except:
    Image = None

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAS_MPL = True
except Exception:
    HAS_MPL = False

BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"
PRODUCT_IMAGES_DIR = BASE_DIR / "product_images"
PRODUCT_IMAGES_DIR.mkdir(exist_ok=True)
PROFILE_IMAGES_DIR = BASE_DIR / "profile_images"
PROFILE_IMAGES_DIR.mkdir(exist_ok=True)

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# colors
C = {
    "bg": "#EEF2EC",
    "card": "#FCFCFA",
    "card2": "#FAFBF8",
    "sidebar": "#FFFFFF",
    "green": "#2E7D4F",
    "green2": "#3FA76A",
    "red": "#C73545",
    "blue": "#2563EB",
    "gold": "#B99052",
    "black": "#111827",
    "text": "#111827",
    "muted": "#6B7280",
    "soft": "#374151",
    "line": "#E4E8DE",
    "accent": "#2E7D4F",
    "mint": "#EAF7EF",
    "pink": "#FDECEF",
    "purple": "#7c3aed",
}


def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()


def money(v):
    try: return f"${float(str(v).replace('$','').replace(',','')):,.2f}"
    except: return f"${v}"


def product_image_path(product_id):
    for ext in [".png", ".jpg", ".jpeg", ".webp"]:
        p = PRODUCT_IMAGES_DIR / f"{product_id}{ext}"
        if p.exists():
            return p
    return None


def make_ctk_image(path, size):
    if not Image or not path or not Path(path).exists():
        return None
    try:
        img = Image.open(path).convert("RGBA")
        img.thumbnail(size)
        return ctk.CTkImage(light_image=img, dark_image=img, size=img.size)
    except Exception:
        return None


class MarketplaceApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("SouqAlMazad | Final Marketplace System")
        self.geometry("1400x820")
        self.configure(fg_color=C["bg"])
        self.minsize(1180, 720)
        self.logged_user = None
        self.show_login()


    # ================================================================
    # CINEMATIC START SCREEN HELPERS
    # ================================================================
    def _clear_window(self):
        for w in self.winfo_children():
            w.destroy()

    def _set_start_background(self):
        """Palestinian aesthetic background."""
        self._bg_refs = getattr(self, "_bg_refs", {})
        self.configure(fg_color="#F5F1E8")

        try:
            bg_path = ASSETS_DIR / "login_background.jpg"

            if Image and bg_path.exists():
                bg_img = ctk.CTkImage(Image.open(bg_path), size=(1600, 900))

                bg_label = ctk.CTkLabel(self, image=bg_img, text="")
                bg_label.place(x=0, y=0, relwidth=1, relheight=1)

                self._bg_refs["login_bg"] = bg_img
                self._bg_refs["login_lbl"] = bg_label

        except Exception:
            self.configure(fg_color="#F5F1E8")

    def _start_timer_text(self):
        # Visual-only timer for login screen, lightweight
        try:
            now = datetime.now()
            total = (34 * 60) + 27 - ((now.minute * 60 + now.second) % (34 * 60 + 27))
            hrs = total // 3600
            mins = (total % 3600) // 60
            secs = total % 60
            return f"{hrs:02d} : {mins:02d} : {secs:02d}"
        except Exception:
            return "00 : 34 : 27"

    def _animate_start_timer(self, label):
        try:
            label.configure(text=self._start_timer_text())
            self.after(1000, lambda: self._animate_start_timer(label))
        except Exception:
            pass

    # NOTE: CustomTkinter frames do not support real alpha transparency.
    # We simulate glass using warm white panels, thin borders, and the image visible around them.
    def _start_card(self, parent, fg="#15170F", radius=26):
        return ctk.CTkFrame(parent, fg_color=fg, corner_radius=radius, border_color="#E7DDC8", border_width=1)

    def _ghost_button(self, parent, text, command=None, active=False):
        return ctk.CTkButton(
            parent, text=text, command=command,
            height=48, corner_radius=14,
            fg_color="#2E7D4F" if active else "transparent",
            hover_color="#3FA76A",
            border_color="#D9CFBB", border_width=1,
            text_color="#0B3D2E",
            font=("Segoe UI", 14, "bold")
        )



    def _glass_label(self, parent, img_name, size):
        path = ASSETS_DIR / img_name
        gimg = ctk.CTkImage(Image.open(path), size=size)
        lbl = ctk.CTkLabel(parent, image=gimg, text="", fg_color="transparent")
        if not hasattr(self, "_glass_refs"):
            self._glass_refs = []
        self._glass_refs.append(gimg)
        return lbl


    # ================================================================
    # LOGIN / REGISTER
    # ================================================================


    def show_login(self):
        self._clear_window()
        self._set_start_background()

        # No big root frame here — elements are placed directly on top of the background.

        # ---------- LEFT BRANDING SIDE ----------
        left = ctk.CTkFrame(self, fg_color="transparent", bg_color="transparent")
        left.place(relx=0.16, rely=0.13, relwidth=0.34, relheight=0.76)

        try:
            if Image and (BASE_DIR / "logo.png").exists():
                logo_img = ctk.CTkImage(Image.open(BASE_DIR / "logo.png"), size=(165, 165))
                ctk.CTkLabel(left, image=logo_img, text="", fg_color="transparent").pack(pady=(10, 2))
                self.login_logo_ref = logo_img
            else:
                ctk.CTkLabel(left, text="⚖️", font=("Segoe UI", 68), text_color="#0F5132").pack(pady=(10, 2))
        except Exception:
            ctk.CTkLabel(left, text="⚖️", font=("Segoe UI", 68), text_color="#0F5132").pack(pady=(10, 2))

        ctk.CTkLabel(left, text="SouqAlMazad", font=("Segoe UI", 38, "bold"),
                     text_color="#0B3D2E", fg_color="transparent").pack()
        ctk.CTkLabel(left, text="Marketplace & Auction System", font=("Segoe UI", 16),
                     text_color="#111827", fg_color="transparent").pack(pady=(2, 22))

        slogan = ctk.CTkFrame(left, fg_color="transparent", bg_color="transparent")
        slogan.pack()
        ctk.CTkLabel(slogan, text="Bid.", font=("Segoe UI", 31, "bold"),
                     text_color="#111827", fg_color="transparent").pack(side="left")
        ctk.CTkLabel(slogan, text=" Win.", font=("Segoe UI", 31, "bold"),
                     text_color="#15803D", fg_color="transparent").pack(side="left")
        ctk.CTkLabel(slogan, text=" Own.", font=("Segoe UI", 31, "bold"),
                     text_color="#9A6B16", fg_color="transparent").pack(side="left")

        ctk.CTkLabel(
            left,
            text="The trusted marketplace for amazing deals\nand exciting live auctions.",
            font=("Segoe UI", 14),
            text_color="#111827",
            justify="center",
            fg_color="transparent"
        ).pack(pady=(12, 24))

        # Smaller glass auction card only — no background block
        auc_card = ctk.CTkFrame(left, fg_color="transparent")
        auc_card.pack(pady=(0, 18), padx=25, fill="x")

        auc_glass = self._glass_label(auc_card, "glass_small.png", (520,180))
        auc_glass.place(relwidth=1, relheight=1)
        top_line = ctk.CTkFrame(auc_card, fg_color="transparent")
        top_line.pack(fill="x", padx=18, pady=(16, 2))
        ctk.CTkLabel(top_line, text="●", text_color="#FF4D3D", font=("Segoe UI", 18, "bold")).pack(side="left")
        ctk.CTkLabel(top_line, text=" LIVE AUCTION", text_color="#D9A512",
                     font=("Segoe UI", 13, "bold")).pack(side="left")
        ctk.CTkLabel(auc_card, text="Featured Auction", text_color="#0B3D2E",
                     font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=20, pady=(6, 0))
        ctk.CTkLabel(auc_card, text="Current Highest Bid", text_color="#6E6A63",
                     font=("Segoe UI", 12)).pack(anchor="w", padx=20, pady=(8, 0))
        ctk.CTkLabel(auc_card, text="$8,450", text_color="#22C55E",
                     font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=20)
        ctk.CTkLabel(auc_card, text="Next Bid: $8,600", text_color="#22C55E",
                     font=("Segoe UI", 12)).pack(anchor="w", padx=20, pady=(0, 14))

        # ---------- RIGHT LOGIN PANEL ----------
        panel = ctk.CTkFrame(self, fg_color="transparent")
        panel.place(relx=0.57, rely=0.18, relwidth=0.34, relheight=0.62)

        glass_bg = self._glass_label(panel, "glass_login.png", (620,620))
        glass_bg.place(relwidth=1, relheight=1)

        ctk.CTkLabel(panel, text="👤", font=("Segoe UI", 38), text_color="#86EFAC").pack(pady=(28, 0))
        title_row = ctk.CTkFrame(panel, fg_color="transparent")
        title_row.pack()
        ctk.CTkLabel(title_row, text="Welcome ", font=("Segoe UI", 27, "bold"),
                     text_color="#0B3D2E").pack(side="left")
        ctk.CTkLabel(title_row, text="Back!", font=("Segoe UI", 27, "bold"),
                     text_color="#22C55E").pack(side="left")
        ctk.CTkLabel(panel, text="Login to continue to your account", font=("Segoe UI", 13),
                     text_color="#6E6A63").pack(pady=(4, 22))

        tabs = ctk.CTkFrame(panel, fg_color="transparent")
        tabs.pack(fill="x", padx=45)
        self._ghost_button(tabs, "👤  Login", active=True).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self._ghost_button(tabs, "👥  Register", command=self.show_register).pack(side="left", fill="x", expand=True, padx=(6, 0))

        self.login_email = ctk.CTkEntry(panel, placeholder_text="Username or Email", width=410, height=52,
                                        corner_radius=14, fg_color="#FFFFFF",
                                        border_color="#D9CFBB", text_color="#0B3D2E",
                                        placeholder_text_color="#8A8F86")
        self.login_email.pack(pady=(22, 10), padx=42)

        self.login_pw = ctk.CTkEntry(panel, placeholder_text="Password", width=410, height=52,
                                     corner_radius=14, show="●", fg_color="#FFFFFF",
                                     border_color="#D9CFBB", text_color="#0B3D2E",
                                     placeholder_text_color="#8A8F86")
        self.login_pw.pack(pady=8, padx=42)

        opt = ctk.CTkFrame(panel, fg_color="transparent")
        opt.pack(fill="x", padx=45, pady=(8, 6))
        self.remember_me = ctk.CTkCheckBox(opt, text="Remember Me", fg_color="#22C55E",
                                           text_color="#0B3D2E", hover_color="#3FA76A")
        self.remember_me.pack(side="left")
        ctk.CTkLabel(opt, text="Forgot Password?", text_color="#22C55E",
                     font=("Segoe UI", 12)).pack(side="right")

        ctk.CTkButton(panel, text="Sign In   →", command=self.do_login,
                      width=410, height=54, fg_color="#2E7D4F",
                      hover_color="#3FA76A", corner_radius=14,
                      font=("Segoe UI", 16, "bold")).pack(pady=(12, 12), padx=42)

        ctk.CTkLabel(panel, text="OR", text_color="#6E6A63", font=("Segoe UI", 12)).pack()

        # Top live auctions tag — direct on background
        live = ctk.CTkFrame(self, fg_color="transparent")
        live.place(relx=0.76, rely=0.09, relwidth=0.18, relheight=0.075)

        live_glass = self._glass_label(live, "glass_live.png", (320,80))
        live_glass.place(relwidth=1, relheight=1)
        ctk.CTkLabel(live, text="((•))  LIVE AUCTIONS   ● 12",
                     text_color="#22C55E", font=("Segoe UI", 13, "bold")).pack(pady=(12, 0))
        ctk.CTkLabel(live, text="Happening Right Now", text_color="#6E6A63",
                     font=("Segoe UI", 11)).pack()


    def do_login(self):
        email = self.login_email.get().strip()
        pw = self.login_pw.get().strip()
        if not email or not pw:
            messagebox.showwarning("Warning", "Enter email and password")
            return

        try:
            conn = db.connect()
            cur = conn.cursor(dictionary=True)
            cur.execute("select * from `user` where email=%s", (email,))
            user = cur.fetchone()
            cur.close(); conn.close()

            if not user:
                messagebox.showerror("Error", "Email not found")
                return

            # Block deactivated users. This makes safe delete/deactivate actually effective.
            if not bool(user.get("is_active", True)):
                messagebox.showerror("Account Disabled", "This account is deactivated. Please contact the admin.")
                return

            # Check password. We support old demo formats, but no universal bypass password.
            stored = user.get('password_hash', '')
            if stored != hash_pw(pw) and stored != pw and stored != f"hash{pw}":
                messagebox.showerror("Error", "Wrong password")
                return

            self.logged_user = user

            # get subtype ids
            buyer = db._fetch_one("select buyer_id from buyer where user_id=%s", (user['user_id'],))
            seller = db._fetch_one("select seller_id from seller where user_id=%s", (user['user_id'],))
            admin = db._fetch_one("select admin_id from `admin` where user_id=%s", (user['user_id'],))
            self.logged_user['buyer_id'] = buyer['buyer_id'] if buyer else None
            self.logged_user['seller_id'] = seller['seller_id'] if seller else None
            self.logged_user['admin_id'] = admin['admin_id'] if admin else None

            # ISA consistency check: user_type must have the matching subtype row.
            utype = str(user['user_type']).lower()
            if utype == 'buyer' and not self.logged_user.get('buyer_id'):
                messagebox.showerror("ISA Error", "Buyer subtype row is missing for this user.")
                return
            if utype == 'seller' and not self.logged_user.get('seller_id'):
                messagebox.showerror("ISA Error", "Seller subtype row is missing for this user.")
                return
            if utype == 'admin' and not self.logged_user.get('admin_id'):
                messagebox.showerror("ISA Error", "Admin subtype row is missing for this user.")
                return

            # route to correct dashboard
            if utype == 'buyer':
                self.show_buyer_dashboard()
            elif utype == 'seller':
                self.show_seller_dashboard()
            elif utype == 'admin':
                self.show_admin_dashboard()
            else:
                messagebox.showerror("Error", "Invalid user type.")

        except Exception as e:
            messagebox.showerror("Error", str(e))



    def show_register(self):
        self._clear_window()
        self._set_start_background()

        left = ctk.CTkFrame(self, fg_color="transparent", bg_color="transparent")
        left.place(relx=0.16, rely=0.16, relwidth=0.34, relheight=0.70)

        try:
            if Image and (BASE_DIR / "logo.png").exists():
                logo_img = ctk.CTkImage(Image.open(BASE_DIR / "logo.png"), size=(160, 160))
                ctk.CTkLabel(left, image=logo_img, text="", fg_color="transparent").pack(pady=(10, 2))
                self.reg_logo_ref = logo_img
            else:
                ctk.CTkLabel(left, text="⚖️", font=("Segoe UI", 68), text_color="#0F5132").pack(pady=(10, 2))
        except Exception:
            ctk.CTkLabel(left, text="⚖️", font=("Segoe UI", 68), text_color="#0F5132").pack(pady=(10, 2))

        ctk.CTkLabel(left, text="SouqAlMazad", font=("Segoe UI", 38, "bold"),
                     text_color="#0B3D2E").pack()
        ctk.CTkLabel(left, text="Start selling, bidding, and growing today",
                     font=("Segoe UI", 17, "bold"), text_color="#111827").pack(pady=(8, 12))
        ctk.CTkLabel(left, text="Create your buyer or seller account.\nAdmin accounts are created securely by the platform.",
                     font=("Segoe UI", 14), text_color="#111827", justify="center").pack()

        panel = ctk.CTkFrame(self, fg_color="transparent")
        panel.place(relx=0.57, rely=0.12, relwidth=0.34, relheight=0.72)

        glass_bg = self._glass_label(panel, "glass_login.png", (620,620))
        glass_bg.place(relwidth=1, relheight=1)

        ctk.CTkLabel(panel, text="👥", font=("Segoe UI", 38), text_color="#86EFAC").pack(pady=(22, 0))
        title_row = ctk.CTkFrame(panel, fg_color="transparent")
        title_row.pack()
        ctk.CTkLabel(title_row, text="Create ", font=("Segoe UI", 27, "bold"),
                     text_color="#0B3D2E").pack(side="left")
        ctk.CTkLabel(title_row, text="Account", font=("Segoe UI", 27, "bold"),
                     text_color="#22C55E").pack(side="left")
        ctk.CTkLabel(panel, text="Join SouqAlMazad today", font=("Segoe UI", 13),
                     text_color="#6E6A63").pack(pady=(4, 18))

        tabs = ctk.CTkFrame(panel, fg_color="transparent")
        tabs.pack(fill="x", padx=45)
        self._ghost_button(tabs, "👤  Login", command=self.show_login).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self._ghost_button(tabs, "👥  Register", active=True).pack(side="left", fill="x", expand=True, padx=(6, 0))

        fields_frame = ctk.CTkFrame(panel, fg_color="transparent")
        fields_frame.pack(fill="x", padx=45, pady=(18, 4))

        def reg_entry(ph, width=410):
            return ctk.CTkEntry(fields_frame, placeholder_text=ph, width=width, height=44,
                                corner_radius=14, fg_color="#FFFFFF", border_color="#D9CFBB",
                                text_color="#0B3D2E", placeholder_text_color="#8A8F86")

        self.reg_fname = reg_entry("First Name", 195)
        self.reg_fname.grid(row=0, column=0, padx=(0, 8), pady=6)
        self.reg_lname = reg_entry("Last Name", 195)
        self.reg_lname.grid(row=0, column=1, padx=(8, 0), pady=6)
        self.reg_email = reg_entry("Email")
        self.reg_email.grid(row=1, column=0, columnspan=2, pady=6)
        self.reg_phone = reg_entry("Phone")
        self.reg_phone.grid(row=2, column=0, columnspan=2, pady=6)
        self.reg_pw = reg_entry("Password")
        self.reg_pw.configure(show="●")
        self.reg_pw.grid(row=3, column=0, columnspan=2, pady=6)

        self.reg_type = ctk.CTkComboBox(fields_frame, values=["buyer", "seller"], width=410, height=44,
                                        corner_radius=14, fg_color="#FFFFFF", border_color="#D9CFBB",
                                        text_color="#0B3D2E", button_color="#2E7D4F")
        self.reg_type.grid(row=4, column=0, columnspan=2, pady=6)
        self.reg_type.set("buyer")

        ctk.CTkButton(panel, text="Create Account   →", command=self.do_register,
                      width=410, height=52, fg_color="#2E7D4F",
                      hover_color="#3FA76A", corner_radius=14,
                      font=("Segoe UI", 16, "bold")).pack(pady=(14, 8), padx=42)

        ctk.CTkButton(panel, text="Already have an account? Sign In", command=self.show_login,
                      width=410, height=42, fg_color="transparent",
                      border_color="#D9CFBB", border_width=1,
                      text_color="#22C55E", corner_radius=14,
                      font=("Segoe UI", 13, "bold")).pack(padx=42)


    def do_register(self):
        try:
            uid = db.add_user(
                self.reg_fname.get(), self.reg_lname.get(),
                self.reg_email.get(), hash_pw(self.reg_pw.get()),
                self.reg_phone.get(), self.reg_type.get()
            )
            messagebox.showinfo("Done", f"Account created! You can login now.")
            self.show_login()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ================================================================
    # SHARED UI HELPERS
    # ================================================================

    # ================================================================
    # PROFILE IMAGE + PROFILE PAGE
    # ================================================================
    def _local_profile_image_path(self, user_id=None):
        user_id = user_id or self.logged_user.get("user_id")
        for ext in [".png", ".jpg", ".jpeg", ".webp"]:
            p = PROFILE_IMAGES_DIR / f"{user_id}{ext}"
            if p.exists():
                return p
        return None

    def _profile_placeholder_image(self, initials="U", size=92):
        img = Image.new("RGBA", (size, size), (234, 247, 239, 255))
        d = ImageDraw.Draw(img)
        d.ellipse((0, 0, size-1, size-1), fill=(234, 247, 239, 255), outline=(46, 125, 79, 255), width=3)
        try:
            # default bitmap font is enough and avoids external font dependency
            d.text((size//2-7, size//2-9), initials[:1].upper(), fill=(11, 61, 46, 255))
        except Exception:
            pass
        return img

    def _make_round_profile_ctk_image(self, size=92):
        try:
            img_path = self._local_profile_image_path()
            db_img = None
            try:
                if hasattr(db, "get_user_profile_image_path"):
                    db_img = db.get_user_profile_image_path(self.logged_user.get("user_id"))
            except Exception:
                db_img = None

            if not img_path and db_img:
                p = BASE_DIR / str(db_img)
                if p.exists():
                    img_path = p

            if Image and img_path and Path(img_path).exists():
                img = Image.open(img_path).convert("RGBA")
                img = ImageOps.fit(img, (size, size), method=Image.LANCZOS)
            else:
                initials = f"{self.logged_user.get('first_name','U')[:1]}{self.logged_user.get('last_name','')[:1]}"
                img = self._profile_placeholder_image(initials, size)

            mask = Image.new("L", (size, size), 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, size-1, size-1), fill=255)
            img.putalpha(mask)
            return ctk.CTkImage(light_image=img, dark_image=img, size=(size, size))
        except Exception:
            initials = f"{self.logged_user.get('first_name','U')[:1]}"
            img = self._profile_placeholder_image(initials, size)
            return ctk.CTkImage(light_image=img, dark_image=img, size=(size, size))

    def _refresh_sidebar_profile_image(self):
        try:
            if hasattr(self, "sidebar_profile_label"):
                profile_img = self._make_round_profile_ctk_image(92)
                self.sidebar_profile_label.configure(image=profile_img, text="")
                self.sidebar_profile_ref = profile_img
        except Exception:
            pass

    def _upload_profile_image(self):
        try:
            f = filedialog.askopenfilename(
                title="Choose profile image",
                filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")]
            )
            if not f:
                return

            src = Path(f)
            ext = src.suffix.lower()
            if ext not in [".png", ".jpg", ".jpeg", ".webp"]:
                messagebox.showerror("Invalid image", "Choose PNG, JPG, JPEG, or WEBP.")
                return

            user_id = self.logged_user.get("user_id")
            for old_ext in [".png", ".jpg", ".jpeg", ".webp"]:
                old = PROFILE_IMAGES_DIR / f"{user_id}{old_ext}"
                if old.exists():
                    old.unlink()

            dest = PROFILE_IMAGES_DIR / f"{user_id}{ext}"
            shutil.copy2(src, dest)

            rel = str(dest.relative_to(BASE_DIR)).replace("\\", "/")
            try:
                if hasattr(db, "save_user_profile_image_path"):
                    db.save_user_profile_image_path(user_id, rel)
            except Exception:
                pass

            messagebox.showinfo("Done", "Profile image updated.")
            self._refresh_sidebar_profile_image()
            self.profile_page()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def profile_page(self):
        try:
            self.set_active(len(self.nav_btns) - 1)
        except Exception:
            pass
        self.clr()
        self.hdr("My Profile", "View your account information and update your profile image")

        card = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=26, border_color=C["line"], border_width=1)
        card.pack(fill="x", padx=30, pady=25)

        top = ctk.CTkFrame(card, fg_color=C["card"])
        top.pack(fill="x", padx=24, pady=24)

        profile_img = self._make_round_profile_ctk_image(130)
        img_lbl = ctk.CTkLabel(top, image=profile_img, text="")
        img_lbl.image_ref = profile_img
        img_lbl.pack(side="left", padx=(0, 24))

        info = ctk.CTkFrame(top, fg_color=C["card"])
        info.pack(side="left", fill="both", expand=True)

        full_name = f"{self.logged_user.get('first_name','')} {self.logged_user.get('last_name','')}".strip()
        ctk.CTkLabel(info, text=full_name, text_color=C["text"], font=("Segoe UI", 26, "bold")).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(info, text=self.logged_user.get("email",""), text_color=C["muted"], font=("Segoe UI", 14)).pack(anchor="w")
        ctk.CTkLabel(info, text=f"Role: {str(self.logged_user.get('user_type','')).upper()}", text_color=C["green"], font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(6, 0))
        ctk.CTkLabel(info, text=f"Phone: {self.logged_user.get('phone','-') or '-'}", text_color=C["soft"], font=("Segoe UI", 13)).pack(anchor="w", pady=(6, 0))
        ctk.CTkLabel(info, text=f"User ID: {self.logged_user.get('user_id')}", text_color=C["muted"], font=("Segoe UI", 12)).pack(anchor="w", pady=(6, 0))

        ctk.CTkButton(top, text="🖼 Upload / Change Image", fg_color=C["gold"], height=42, width=190,
                      corner_radius=14, command=self._upload_profile_image).pack(side="right", padx=10)

        details = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=26, border_color=C["line"], border_width=1)
        details.pack(fill="x", padx=30, pady=(0, 20))

        rows = [
            ("User ID", self.logged_user.get("user_id")),
            ("First Name", self.logged_user.get("first_name")),
            ("Last Name", self.logged_user.get("last_name")),
            ("Email", self.logged_user.get("email")),
            ("Phone", self.logged_user.get("phone") or "-"),
            ("Account Type", self.logged_user.get("user_type")),
            ("Buyer ID", self.logged_user.get("buyer_id") or "-"),
            ("Seller ID", self.logged_user.get("seller_id") or "-"),
            ("Admin ID", self.logged_user.get("admin_id") or "-"),
            ("Active", "Yes" if self.logged_user.get("is_active", True) else "No"),
        ]

        for i, (k, v) in enumerate(rows):
            r = ctk.CTkFrame(details, fg_color=C["card"])
            r.pack(fill="x", padx=22, pady=(12 if i == 0 else 4, 4))
            ctk.CTkLabel(r, text=k, width=140, anchor="w", text_color=C["muted"], font=("Segoe UI", 12, "bold")).pack(side="left")
            ctk.CTkLabel(r, text=str(v), anchor="w", text_color=C["text"], font=("Segoe UI", 13)).pack(side="left", fill="x", expand=True)


    def build_shell(self, role, color, pages):
        for w in self.winfo_children(): w.destroy()

        # Add profile page to every role sidebar without disturbing existing screen indexes.
        pages = list(pages) + [("👤 My Profile", self.profile_page)]

        # sidebar
        sb = ctk.CTkFrame(self, width=300, fg_color=C["sidebar"], corner_radius=0, border_color=C["line"], border_width=1)
        sb.pack(side="left", fill="y"); sb.pack_propagate(False)

        try:
            if Image and (BASE_DIR / "logo.png").exists():
                sb_img = ctk.CTkImage(Image.open(BASE_DIR / "logo.png"), size=(190, 190))
                ctk.CTkLabel(sb, image=sb_img, text="").pack(pady=(10, 0))
                self.sidebar_logo_ref = sb_img
            else:
                ctk.CTkLabel(sb, text="🏪", font=("Segoe UI", 54)).pack(pady=(20, 2))
        except Exception:
            ctk.CTkLabel(sb, text="🏪", font=("Segoe UI", 54)).pack(pady=(20, 2))
        ctk.CTkLabel(sb, text="SouqAlMazad", font=("Segoe UI", 26, "bold"), text_color=C["text"]).pack()

        # user info with circular profile image
        try:
            self.sidebar_profile_ref = self._make_round_profile_ctk_image(92)
            self.sidebar_profile_label = ctk.CTkLabel(sb, image=self.sidebar_profile_ref, text="")
            self.sidebar_profile_label.pack(pady=(6, 4))
        except Exception:
            ctk.CTkLabel(sb, text="👤", font=("Segoe UI", 46), text_color=C["green"]).pack(pady=(6, 4))

        name = f"{self.logged_user['first_name']} {self.logged_user['last_name']}"
        ctk.CTkLabel(sb, text=name, font=("Segoe UI", 13, "bold"), text_color=C["text"]).pack(pady=(2, 0))
        ctk.CTkLabel(sb, text=role.upper(), font=("Segoe UI", 10, "bold"),
                     text_color=color).pack(pady=(0, 14))

        self.nav_btns = []
        for txt, cmd in pages:
            b = ctk.CTkButton(sb, text=txt, command=cmd, fg_color="transparent",
                              text_color=C["soft"], hover_color="#F0F4ED", anchor="w",
                              font=("Segoe UI", 13), height=40, corner_radius=8)
            b.pack(fill="x", padx=10, pady=2)
            self.nav_btns.append(b)

        # logout
        ctk.CTkButton(sb, text="🚪 Logout", command=self.show_login,
                      fg_color=C["red"], text_color="#0B3D2E", height=38,
                      corner_radius=8, font=("Segoe UI", 12, "bold")).pack(side="bottom", fill="x", padx=12, pady=15)

        # main content
        self.main = ctk.CTkFrame(self, fg_color=C["bg"], corner_radius=0)
        self.main.pack(side="right", fill="both", expand=True)

        # style treeview
        s = ttk.Style(); s.theme_use("clam")
        s.configure("Treeview", background=C["card"], foreground=C["soft"], fieldbackground=C["card"], rowheight=36, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#F2F5EF", foreground=C["text"])
        s.map("Treeview", background=[("selected", C["mint"])], foreground=[("selected", C["text"])])

    def set_active(self, idx):
        for i, b in enumerate(self.nav_btns):
            b.configure(fg_color=C["green"] if i == idx else "transparent",
                        text_color="#0B3D2E" if i == idx else C["soft"])

    def clr(self):
        for w in self.main.winfo_children(): w.destroy()

    def hdr(self, title, sub=""):
        f = ctk.CTkFrame(self.main, fg_color=C["bg"])
        f.pack(fill="x", padx=25, pady=(20, 5))
        ctk.CTkLabel(f, text=title, font=("Segoe UI", 32, "bold"), text_color=C["text"]).pack(anchor="w")
        if sub: ctk.CTkLabel(f, text=sub, font=("Segoe UI", 13), text_color=C["muted"]).pack(anchor="w")

    def make_tree(self, parent, cols, ws, h=12):
        fr = ctk.CTkFrame(parent, fg_color=C["card"], corner_radius=22)
        fr.pack(fill="both", expand=True, padx=25, pady=10)
        sc = ttk.Scrollbar(fr, orient="vertical")
        t = ttk.Treeview(fr, columns=cols, show="headings", height=h, yscrollcommand=sc.set)
        sc.configure(command=t.yview)
        for i, c in enumerate(cols):
            t.heading(c, text=c); t.column(c, width=ws[i])
        t.pack(side="left", fill="both", expand=True, padx=(15,0), pady=15)
        sc.pack(side="right", fill="y", pady=15, padx=(0,5))
        return t

    def stat_card(self, parent, icon, label, value, color, col):
        c = ctk.CTkFrame(parent, fg_color=C["card"], corner_radius=22, height=100)
        c.grid(row=0, column=col, padx=8, pady=5, sticky="nsew")
        c.grid_propagate(False); parent.grid_columnconfigure(col, weight=1)
        ctk.CTkLabel(c, text=icon, font=("Segoe UI", 24)).place(x=15, y=10)
        ctk.CTkLabel(c, text=str(value), font=("Segoe UI", 26, "bold"), text_color=color).place(x=15, y=40)
        ctk.CTkLabel(c, text=label, font=("Segoe UI", 11), text_color=C["muted"]).place(x=15, y=72)


    # ================================================================
    # VISUAL ENHANCEMENTS ONLY: charts, images, product studio style
    # ================================================================
    def _embed_chart(self, parent, fig):
        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=(4, 12))
        plt.close(fig)

    def _chart_card(self, parent, title, kind):
        card = ctk.CTkFrame(parent, fg_color=C["card"], border_color=C["line"], border_width=1, corner_radius=24)
        card.pack(side="left", fill="both", expand=True, padx=8)
        ctk.CTkLabel(card, text=title, font=("Segoe UI", 15, "bold"), text_color=C["text"]).pack(anchor="w", padx=16, pady=(12, 0))
        if not HAS_MPL:
            ctk.CTkLabel(card, text="matplotlib not installed", text_color=C["muted"]).pack(pady=30)
            return
        try:
            if kind == "orders":
                rows = db._fetch_all("SELECT status, COUNT(*) AS c FROM `order` GROUP BY status")
                labels = [str(r["status"]) for r in rows]
                sizes = [int(r["c"]) for r in rows]
                fig, ax = plt.subplots(figsize=(3.2, 2.2))
                fig.patch.set_facecolor("#FCFCFA")
                ax.pie(sizes, labels=labels, autopct="%1.0f%%", startangle=90, textprops={"fontsize": 8})
                ax.set_aspect("equal")
                self._embed_chart(card, fig)
            elif kind == "auctions":
                rows = db._fetch_all("SELECT status, COUNT(*) AS c FROM auction GROUP BY status")
                labels = [str(r["status"]) for r in rows]
                sizes = [int(r["c"]) for r in rows]
                fig, ax = plt.subplots(figsize=(3.2, 2.2))
                fig.patch.set_facecolor("#FCFCFA")
                ax.pie(sizes, labels=labels, autopct="%1.0f%%", startangle=90, textprops={"fontsize": 8})
                ax.set_aspect("equal")
                self._embed_chart(card, fig)
            else:
                rows = db._fetch_all("""
                    SELECT p.title, COALESCE(SUM(oi.quantity),0) AS sold_qty
                    FROM product p
                    LEFT JOIN order_item oi ON p.product_id=oi.product_id
                    GROUP BY p.product_id, p.title
                    ORDER BY sold_qty DESC
                    LIMIT 5
                """)
                names = [str(r["title"])[:15] for r in rows]
                sold = [int(r["sold_qty"] or 0) for r in rows]
                fig, ax = plt.subplots(figsize=(3.2, 2.2))
                fig.patch.set_facecolor("#FCFCFA")
                ax.set_facecolor("#FCFCFA")
                ax.barh(names, sold)
                ax.invert_yaxis()
                ax.set_xlabel("Qty Sold", fontsize=8)
                ax.tick_params(labelsize=7)
                for spine in ax.spines.values():
                    spine.set_visible(False)
                fig.tight_layout()
                self._embed_chart(card, fig)
        except Exception:
            ctk.CTkLabel(card, text="No chart data", text_color=C["muted"]).pack(pady=30)

    def add_dashboard_charts(self):
        row = ctk.CTkFrame(self.main, fg_color=C["bg"])
        row.pack(fill="x", padx=25, pady=(0, 16))
        self._chart_card(row, "Orders by Status", "orders")
        self._chart_card(row, "Top Products Sold", "top")
        self._chart_card(row, "Auctions by Status", "auctions")

    def display_product_image(self, parent, product_id, size=(230, 132)):
        img_path = product_image_path(product_id)
        img_ref = make_ctk_image(img_path, size)
        if img_ref:
            lbl = ctk.CTkLabel(parent, image=img_ref, text="")
            lbl.image_ref = img_ref
            lbl.pack(fill="x", padx=12, pady=(12, 4))
            return lbl
        ph = ctk.CTkFrame(parent, fg_color=C["card2"] if "card2" in C else C["card"], height=size[1], corner_radius=18)
        ph.pack(fill="x", padx=12, pady=(12, 4))
        ph.pack_propagate(False)
        ctk.CTkLabel(ph, text="Product Image", text_color=C["muted"], font=("Segoe UI", 12)).pack(expand=True)
        return ph

    def upload_product_image_by_id(self, product_id):
        if not product_id:
            messagebox.showwarning("Warning", "Select a product first.")
            return
        f = filedialog.askopenfilename(title="Choose product image", filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not f:
            return
        src = Path(f)
        ext = src.suffix.lower()
        if ext not in [".png", ".jpg", ".jpeg", ".webp"]:
            messagebox.showerror("Invalid image", "Choose PNG, JPG, JPEG, or WEBP.")
            return
        for old_ext in [".png", ".jpg", ".jpeg", ".webp"]:
            old = PRODUCT_IMAGES_DIR / f"{product_id}{old_ext}"
            if old.exists():
                old.unlink()
        dest = PRODUCT_IMAGES_DIR / f"{product_id}{ext}"
        shutil.copy2(src, dest)
        try:
            db.set_product_image(product_id, str(dest.relative_to(BASE_DIR)).replace("\\", "/"), True)
        except Exception:
            pass
        messagebox.showinfo("Done", "Product image saved.")


    def status_color(self, status):
        s = str(status or "").lower()
        if s in {"delivered", "completed", "confirmed", "active", "paid"}:
            return C["green"]
        if s in {"pending", "processing", "preparing", "shipped", "in_transit", "upcoming"}:
            return C["gold"]
        if s in {"cancelled", "returned", "failed", "ended"}:
            return C["red"]
        return C["muted"]

    def _safe_days_left(self, end_time):
        try:
            if isinstance(end_time, str):
                end = datetime.fromisoformat(end_time.replace("Z", "").split(".")[0])
            else:
                end = end_time
            diff = end - datetime.now()
            seconds = int(diff.total_seconds())
            if seconds <= 0:
                return "ENDED", True
            days = seconds // 86400
            hours = (seconds % 86400) // 3600
            mins = (seconds % 3600) // 60
            if days > 0:
                return f"{days}d {hours}h left", False
            if hours > 0:
                return f"{hours}h {mins}m left", False
            return f"{mins}m left", False
        except Exception:
            return "Time unknown", False

    def _get_order_items_visual(self, order_id):
        try:
            return db._fetch_all("""
                SELECT oi.order_id, oi.product_id, oi.quantity, oi.unit_price, oi.subtotal,
                       p.title, p.stock_quantity, p.sale_type, p.item_condition,
                       s.store_name, c.name AS category
                FROM order_item oi
                JOIN product p ON oi.product_id=p.product_id
                JOIN store s ON oi.store_id=s.store_id
                JOIN category c ON p.category_id=c.category_id
                WHERE oi.order_id=%s
                ORDER BY oi.order_item_id
            """, (order_id,))
        except Exception:
            return []

    def product_caption_card(self, parent, icon, label, value, color=None):
        box = ctk.CTkFrame(parent, fg_color=C["mint"], corner_radius=14)
        box.pack(side="left", padx=4, pady=4, fill="x", expand=True)
        ctk.CTkLabel(box, text=icon, font=("Segoe UI", 17)).pack(anchor="w", padx=8, pady=(6, 0))
        ctk.CTkLabel(box, text=label, text_color=C["muted"], font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=8)
        ctk.CTkLabel(box, text=str(value or "-"), text_color=color or C["text"], font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=8, pady=(0, 8))

    def make_product_visual_card(self, parent, product_id, title, price=None, subtitle="", status_text="", status_color=None, command=None, extra_button=None):
        card = ctk.CTkFrame(parent, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        self.display_product_image(card, product_id, (260, 145))
        ctk.CTkLabel(card, text=str(title or "Product")[:36], font=("Segoe UI", 17, "bold"), text_color=C["text"]).pack(anchor="w", padx=14, pady=(8, 2))
        if price is not None:
            ctk.CTkLabel(card, text=money(price), font=("Segoe UI", 16, "bold"), text_color=C["green"]).pack(anchor="w", padx=14)
        if subtitle:
            ctk.CTkLabel(card, text=subtitle, font=("Segoe UI", 11), text_color=C["muted"], wraplength=240, justify="left").pack(anchor="w", padx=14, pady=(4, 2))
        if status_text:
            badge = ctk.CTkFrame(card, fg_color=status_color or C["gold"], corner_radius=99)
            badge.pack(anchor="w", padx=14, pady=(6, 8))
            ctk.CTkLabel(badge, text=status_text, text_color="#0B3D2E", font=("Segoe UI", 11, "bold")).pack(padx=10, pady=4)
        btnrow = ctk.CTkFrame(card, fg_color="transparent")
        btnrow.pack(fill="x", padx=14, pady=(4, 14))
        if command:
            ctk.CTkButton(btnrow, text="Select", command=command, fg_color=C["black"], hover_color="#2D3748", width=90, height=34, corner_radius=12, font=("Segoe UI", 11, "bold")).pack(side="left", padx=(0, 6))
        if extra_button:
            txt, cmd, col = extra_button
            ctk.CTkButton(btnrow, text=txt, command=cmd, fg_color=col, width=100, height=34, corner_radius=12, font=("Segoe UI", 11, "bold")).pack(side="left")
        return card

    # ================================================================
    # BUYER DASHBOARD
    # ================================================================
    def show_buyer_dashboard(self):
        self.build_shell("Buyer", C["green"], [
            ("🏠 Home", self.buyer_home),
            ("🛍️ Browse Products", self.buyer_browse),
            ("⚡ Live Auctions", self.buyer_auctions),
            ("📦 My Orders", self.buyer_orders),
            ("❤️ My Wishlist", self.buyer_wishlist),
            ("🔔 Notifications", self.buyer_notifs),
        ])
        self.buyer_home()

    def buyer_home(self):
        self.set_active(0); self.clr()
        self.hdr(f"Welcome, {self.logged_user['first_name']}!", "Your shopping dashboard")

        bid = self.logged_user.get('buyer_id')
        cards = ctk.CTkFrame(self.main, fg_color=C["bg"])
        cards.pack(fill="x", padx=25, pady=10)

        try:
            orders = db.get_buyer_orders(bid) if bid else []
            wishl = db._fetch_one("select count(*) as c from wishlist where buyer_id=%s", (bid,)) if bid else {'c': 0}
            notifs = db._fetch_one("select count(*) as c from notification where user_id=%s and is_read=false",
                                   (self.logged_user['user_id'],))
        except:
            orders = []; wishl = {'c': 0}; notifs = {'c': 0}

        self.stat_card(cards, "📦", "My Orders", len(orders), C["blue"], 0)
        self.stat_card(cards, "❤️", "Wishlist", wishl['c'], C["red"], 1)
        self.stat_card(cards, "🔔", "Unread", notifs['c'], C["gold"], 2)

        self.add_dashboard_charts()

        # recent orders
        t = self.make_tree(self.main, ("ID","Type","Total","Status","Payment","Shipment","Date"),
                           [45,80,85,85,85,85,130], h=8)
        for o in orders[:8]:
            t.insert("","end",values=(o.get('order_id'), o.get('order_type'),
                money(o.get('final_amount')), o.get('status'),
                o.get('payment_status') or '-', o.get('shipment_status') or '-',
                str(o.get('created_at',''))[:16]))

    def buyer_browse(self):
        self.set_active(1); self.clr()
        self.hdr("Browse Products", "Find what you need")

        # search
        sf = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22)
        sf.pack(fill="x", padx=25, pady=10)
        sr = ctk.CTkFrame(sf, fg_color=C["card"])
        sr.pack(fill="x", padx=15, pady=12)
        self.b_search = ctk.CTkEntry(sr, placeholder_text="Search products...", width=300, height=38, corner_radius=10)
        self.b_search.grid(row=0, column=0, padx=5)
        ctk.CTkButton(sr, text="🔍 Search", width=90, fg_color=C["green"], height=38,
                      corner_radius=10, command=self.load_buyer_products).grid(row=0, column=1, padx=5)

        # products scroll area
        self.buyer_prod_frame = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], height=450)
        self.buyer_prod_frame.pack(fill="both", expand=True, padx=25, pady=5)
        self.load_buyer_products()

    def load_buyer_products(self):
        for w in self.buyer_prod_frame.winfo_children(): w.destroy()
        try:
            products = db.get_marketplace_products()
        except:
            products = db.get_all_products()

        search = self.b_search.get().lower() if hasattr(self, 'b_search') else ""
        if search:
            products = [p for p in products if search in str(p.get('title','')).lower()
                        or search in str(p.get('category','')).lower()]

        if not products:
            ctk.CTkLabel(self.buyer_prod_frame, text="No products found.",
                         text_color=C["muted"], font=("Segoe UI", 14)).pack(pady=20)
            return

        for i, p in enumerate(products):
            card = ctk.CTkFrame(self.buyer_prod_frame, fg_color=C["card"], corner_radius=22,
                                border_color=C["line"], border_width=1)
            card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
            self.buyer_prod_frame.grid_columnconfigure(i%3, weight=1)

            self.display_product_image(card, p.get('product_id'), (230, 125))

            ctk.CTkLabel(card, text=p.get('title',''), font=("Segoe UI", 15, "bold"),
                         text_color=C["text"]).pack(anchor="w", padx=12, pady=(12,2))
            ctk.CTkLabel(card, text=f"{money(p.get('price'))}  •  {p.get('category','')}",
                         font=("Segoe UI", 13, "bold"), text_color=C["green"]).pack(anchor="w", padx=12)
            ctk.CTkLabel(card, text=f"{p.get('store_name','')}  •  {p.get('item_condition','')}  •  Stock: {p.get('stock_quantity',0)}",
                         font=("Segoe UI", 11), text_color=C["muted"]).pack(anchor="w", padx=12, pady=(2,8))

            btns = ctk.CTkFrame(card, fg_color=C["card"])
            btns.pack(fill="x", padx=12, pady=(0,12))

            if p.get('sale_type') in ('direct','both'):
                ctk.CTkButton(btns, text="🛒 Buy Now", width=90, height=32,
                              fg_color=C["green"], corner_radius=8, font=("Segoe UI", 11, "bold"),
                              command=lambda pr=p: self.buyer_buy(pr)).pack(side="left", padx=(0,5))
            ctk.CTkButton(btns, text="❤️", width=40, height=32,
                          fg_color=C["red"], corner_radius=8,
                          command=lambda pid=p.get('product_id'): self.buyer_add_wish(pid)).pack(side="left")

    def buyer_buy(self, product):
        # buy dialog
        win = ctk.CTkToplevel(self)
        win.title("Buy Product"); win.geometry("400x350")
        win.configure(fg_color=C["card"])
        win.grab_set()

        ctk.CTkLabel(win, text=f"🛒 Buy: {product.get('title','')}", font=("Segoe UI", 16, "bold"),
                     text_color=C["text"]).pack(pady=(20,5))
        ctk.CTkLabel(win, text=f"Price: {money(product.get('price'))}", font=("Segoe UI", 14),
                     text_color=C["green"]).pack()

        f = ctk.CTkFrame(win, fg_color=C["card"])
        f.pack(padx=30, pady=15)

        ctk.CTkLabel(f, text="Quantity:").grid(row=0, column=0, padx=5, pady=5)
        qty = ctk.CTkEntry(f, width=80, height=35, corner_radius=8)
        qty.grid(row=0, column=1, padx=5, pady=5); qty.insert(0, "1")

        ctk.CTkLabel(f, text="Address:").grid(row=1, column=0, padx=5, pady=5)
        addr = ctk.CTkEntry(f, width=250, height=35, corner_radius=8, placeholder_text="Your delivery address")
        addr.grid(row=1, column=1, padx=5, pady=5)

        ctk.CTkLabel(f, text="Payment:").grid(row=2, column=0, padx=5, pady=5)
        pay = ctk.CTkComboBox(f, values=["credit_card","paypal","cash_on_delivery"], width=200, height=35)
        pay.grid(row=2, column=1, padx=5, pady=5); pay.set("cash_on_delivery")

        def confirm():
            try:
                oid = db.direct_buy_product(
                    self.logged_user['buyer_id'], product['product_id'],
                    qty.get(), addr.get(), pay.get()
                )
                # auto notification
                try:
                    db.add_notification(self.logged_user['user_id'], 'order_update',
                                       'Order Placed!', f'Your order #{oid} has been placed.')
                except: pass
                messagebox.showinfo("Done", f"Order #{oid} placed successfully!")
                win.destroy()
                self.buyer_home()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        ctk.CTkButton(win, text="✅ Confirm Purchase", command=confirm, width=250, height=42,
                      fg_color=C["green"], corner_radius=10, font=("Segoe UI", 13, "bold")).pack(pady=15)

    def buyer_add_wish(self, pid):
        try:
            db.add_wishlist(self.logged_user['buyer_id'], pid)
            messagebox.showinfo("Done", "Added to wishlist!")
        except Exception as e:
            messagebox.showerror("Error", str(e))


    def _sync_auction_statuses(self):
        """
        Complete auction lifecycle before displaying auctions:
        active/upcoming status sync, winner detection, notifications, and auction order creation.
        """
        try:
            if hasattr(db, "close_ended_auctions"):
                db.close_ended_auctions()
                return
        except Exception as e:
            # Do not crash UI; show auction data as much as possible.
            print("Auction lifecycle sync error:", e)

        # Fallback if db_helper is older
        try:
            db._execute("""
                UPDATE auction
                SET status='active'
                WHERE status='upcoming'
                  AND start_time <= NOW()
                  AND end_time > NOW()
            """)
            db._execute("""
                UPDATE auction
                SET status='ended'
                WHERE status IN ('upcoming','active')
                  AND end_time <= NOW()
            """)
        except Exception:
            pass


    def _selected_tree_first_value(self, tree, warning="Select a row first."):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", warning)
            return None
        return tree.item(sel[0])["values"][0]

    def _show_auction_details_popup(self, auction_id):
        try:
            auc = db._fetch_one("""
                SELECT a.*, p.title AS product_title, st.store_name,
                       CONCAT(wu.first_name, ' ', wu.last_name) AS winner_name
                FROM auction a
                JOIN product p ON a.product_id=p.product_id
                JOIN store st ON p.store_id=st.store_id
                LEFT JOIN buyer wb ON a.winner_buyer_id=wb.buyer_id
                LEFT JOIN `user` wu ON wb.user_id=wu.user_id
                WHERE a.auction_id=%s
            """, (auction_id,))
            bids = db.get_auction_bids(auction_id) if hasattr(db, "get_auction_bids") else []
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        if not auc:
            messagebox.showerror("Error", "Auction not found.")
            return

        win = ctk.CTkToplevel(self)
        win.title(f"Auction #{auction_id} Details")
        win.geometry("780x560")
        win.configure(fg_color=C["bg"])
        win.grab_set()

        header = ctk.CTkFrame(win, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
        header.pack(fill="x", padx=18, pady=14)

        ctk.CTkLabel(header, text=f"Auction #{auc.get('auction_id')} — {auc.get('product_title')}",
                     text_color=C["text"], font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
        ctk.CTkLabel(header, text=f"Store: {auc.get('store_name')} | Status: {auc.get('status')} | Winner: {auc.get('winner_name') or '-'}",
                     text_color=C["muted"], font=("Segoe UI", 13)).pack(anchor="w", padx=18)
        ctk.CTkLabel(header, text=f"Start: {auc.get('start_time')}     End: {auc.get('end_time')}",
                     text_color=C["muted"], font=("Segoe UI", 13)).pack(anchor="w", padx=18, pady=(2, 12))
        ctk.CTkLabel(header, text=f"Starting: {money(auc.get('starting_price'))} | Reserve: {money(auc.get('reserve_price') or 0)} | Current Highest: {money(auc.get('current_highest'))}",
                     text_color=C["green"], font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=18, pady=(0, 16))

        ctk.CTkLabel(win, text="Bid History", text_color=C["text"], font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=24, pady=(4, 2))
        t = ttk.Treeview(win, columns=("Bid ID","Buyer","Amount","Time","Winning"), show="headings", height=13)
        widths = [70, 180, 120, 170, 90]
        for col, w in zip(("Bid ID","Buyer","Amount","Time","Winning"), widths):
            t.heading(col, text=col)
            t.column(col, width=w)
        t.pack(fill="both", expand=True, padx=18, pady=(4, 14))

        for b in bids:
            buyer = f"{b.get('first_name','')} {b.get('last_name','')}".strip()
            t.insert("", "end", values=(b.get("bid_id"), buyer, money(b.get("bid_amount")), str(b.get("bid_time",""))[:19], "Yes" if b.get("is_winning") else "No"))

    def _buyer_confirm_shipping_popup(self, order_id):
        win = ctk.CTkToplevel(self)
        win.title("Confirm Auction Shipping Address")
        win.geometry("520x260")
        win.configure(fg_color=C["bg"])
        win.grab_set()

        box = ctk.CTkFrame(win, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
        box.pack(fill="both", expand=True, padx=18, pady=18)

        ctk.CTkLabel(box, text=f"Confirm Shipping Address for Order #{order_id}",
                     text_color=C["text"], font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=18, pady=(18, 6))
        ctk.CTkLabel(box, text="This is useful for auction orders created automatically after winning.",
                     text_color=C["muted"], font=("Segoe UI", 12)).pack(anchor="w", padx=18, pady=(0, 14))

        ent = ctk.CTkEntry(box, width=450, height=42, corner_radius=12, placeholder_text="Shipping Address")
        ent.pack(padx=18, pady=8)

        def save():
            try:
                db.update_order_shipping_address(order_id, self.logged_user.get("buyer_id"), ent.get())
                messagebox.showinfo("Done", "Shipping address confirmed.")
                win.destroy()
                self.buyer_orders()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        ctk.CTkButton(box, text="Save Address", fg_color=C["green"], height=40, corner_radius=12,
                      command=save).pack(pady=14)

    def buyer_auctions(self):
        self.set_active(2); self.clr()
        self.hdr("Live Auctions", "Feel the countdown, compete, and win before it is gone")

        self._sync_auction_statuses()

        try:
            auctions = db.get_auctions()
        except Exception:
            auctions = []

        active = [a for a in auctions if str(a.get("status", "")).lower() == "active"]
        ended = [a for a in auctions if str(a.get("status", "")).lower() == "ended"]
        upcoming = [a for a in auctions if str(a.get("status", "")).lower() == "upcoming"]

        # Pick best active auction first, otherwise upcoming, otherwise ended for regret section.
        hero = active[0] if active else (upcoming[0] if upcoming else (ended[0] if ended else None))

        hero_card = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        hero_card.pack(fill="x", padx=25, pady=(10, 12))

        left = ctk.CTkFrame(hero_card, fg_color=C["card"])
        left.pack(side="left", fill="both", expand=True, padx=22, pady=18)

        if hero:
            self.display_product_image(left, hero.get("product_id"), (560, 190))
            ctk.CTkLabel(left, text="🔥 Best Auction Right Now" if str(hero.get("status")).lower()=="active" else "⌛ Auction Spotlight",
                         font=("Segoe UI", 13, "bold"), text_color=C["red"]).pack(anchor="w", pady=(8, 0))
            ctk.CTkLabel(left, text=str(hero.get("product_title", "Auction")),
                         font=("Segoe UI", 27, "bold"), text_color=C["text"]).pack(anchor="w", pady=(6, 2))
            ctk.CTkLabel(left, text=f"Current highest bid: {money(hero.get('current_highest'))}  •  {hero.get('store_name','')}",
                         font=("Segoe UI", 16, "bold"), text_color=C["green"]).pack(anchor="w")

            timer_box = ctk.CTkFrame(hero_card, fg_color=C["mint"], corner_radius=22)
            timer_box.pack(side="right", fill="y", padx=20, pady=18)
            ctk.CTkLabel(timer_box, text="⏳", font=("Segoe UI", 38)).pack(pady=(25, 0))

            timer_label = ctk.CTkLabel(timer_box, text="", font=("Segoe UI", 30, "bold"),
                                       text_color=C["red"] if str(hero.get("status")).lower()=="ended" else C["green"])
            timer_label.pack(padx=40, pady=(8, 4))
            self._start_countdown_label(timer_label, hero.get("end_time"), hero.get("status"))

            status_lower = str(hero.get("status", "")).lower()
            if status_lower == "active":
                ctk.CTkLabel(timer_box, text="Hurry up — auction is live",
                             font=("Segoe UI", 12, "bold"), text_color=C["text"]).pack(pady=(0, 15))
                ctk.CTkButton(timer_box, text="Bid on this auction", fg_color=C["black"], width=210, height=42,
                              corner_radius=14,
                              command=lambda aid=hero.get("auction_id"): (self.b_auc.delete(0,"end"), self.b_auc.insert(0, aid))
                              ).pack(pady=8)
                ctk.CTkButton(timer_box, text="View Details", fg_color=C["gold"], width=210, height=38,
                              corner_radius=14,
                              command=lambda aid=hero.get("auction_id"): self._show_auction_details_popup(aid)).pack(pady=4)
            elif status_lower == "upcoming":
                ctk.CTkLabel(timer_box, text="Coming soon — get ready",
                             font=("Segoe UI", 12, "bold"), text_color=C["text"]).pack(pady=(0, 15))
                ctk.CTkButton(timer_box, text="Not active yet", fg_color=C["gold"], width=210, height=42,
                              corner_radius=14, state="disabled").pack(pady=8)
            else:
                end_msg = f"Winner: {hero.get('winner_name')}" if hero.get("winner_name") else "You missed this one"
                ctk.CTkLabel(timer_box, text=end_msg,
                             font=("Segoe UI", 12, "bold"), text_color=C["text"]).pack(pady=(0, 15))
                ctk.CTkButton(timer_box, text="Auction ended", fg_color=C["red"], width=210, height=42,
                              corner_radius=14, state="disabled").pack(pady=8)
        else:
            ctk.CTkLabel(left, text="No auctions available right now.",
                         font=("Segoe UI", 18, "bold"), text_color=C["muted"]).pack(pady=50)

        # Bid form only for active auctions
        bf = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22)
        bf.pack(fill="x", padx=25, pady=10)
        r = ctk.CTkFrame(bf, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=12)
        ctk.CTkLabel(r, text="Auction ID:", font=("Segoe UI", 12, "bold"), text_color=C["soft"]).grid(row=0, column=0, padx=5)
        self.b_auc = ctk.CTkEntry(r, width=90, height=36, corner_radius=10)
        self.b_auc.grid(row=0, column=1, padx=8)
        ctk.CTkLabel(r, text="Your Bid:", font=("Segoe UI", 12, "bold"), text_color=C["soft"]).grid(row=0, column=2, padx=5)
        self.b_amt = ctk.CTkEntry(r, width=140, height=36, corner_radius=10, placeholder_text="Amount")
        self.b_amt.grid(row=0, column=3, padx=8)
        ctk.CTkButton(r, text="💰 Place Bid", fg_color=C["green"], width=150, height=38,
                      corner_radius=12, command=self.buyer_bid).grid(row=0, column=4, padx=10)

        # Active auction cards
        area = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], height=390)
        area.pack(fill="both", expand=True, padx=25, pady=(8, 15))

        ctk.CTkLabel(area, text="Live now — bid before the timer ends",
                     font=("Segoe UI", 20, "bold"), text_color=C["green"]).grid(row=0, column=0, columnspan=3, sticky="w", padx=5, pady=(5, 10))

        row = 1
        col = 0
        if active:
            for a in active:
                card = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
                card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
                area.grid_columnconfigure(col, weight=1)

                self.display_product_image(card, a.get("product_id"), (250, 125))
                ctk.CTkLabel(card, text=str(a.get("product_title", ""))[:28],
                             font=("Segoe UI", 16, "bold"), text_color=C["text"]).pack(anchor="w", padx=14)
                ctk.CTkLabel(card, text=f"Highest: {money(a.get('current_highest'))}",
                             font=("Segoe UI", 14, "bold"), text_color=C["green"]).pack(anchor="w", padx=14, pady=(3, 2))
                timer = ctk.CTkLabel(card, text="", font=("Segoe UI", 18, "bold"), text_color=C["red"])
                timer.pack(anchor="w", padx=14, pady=(0, 6))
                self._start_countdown_label(timer, a.get("end_time"), a.get("status"))
                ctk.CTkButton(card, text="Select to Bid", fg_color=C["black"], width=120, height=34,
                              corner_radius=12,
                              command=lambda aid=a.get("auction_id"): (self.b_auc.delete(0,"end"), self.b_auc.insert(0, aid))
                              ).pack(anchor="w", padx=14, pady=(0, 6))
                ctk.CTkButton(card, text="Details", fg_color=C["gold"], width=120, height=32,
                              corner_radius=12,
                              command=lambda aid=a.get("auction_id"): self._show_auction_details_popup(aid)
                              ).pack(anchor="w", padx=14, pady=(0, 14))

                col += 1
                if col == 3:
                    col = 0
                    row += 1
        else:
            ctk.CTkLabel(area, text="No active auctions right now.",
                         font=("Segoe UI", 14), text_color=C["muted"]).grid(row=row, column=0, sticky="w", padx=10, pady=10)
            row += 1

        # Upcoming auctions: visible to buyer but not biddable yet
        if upcoming:
            row += 1
            ctk.CTkLabel(area, text="Coming soon — sellers prepared these auctions",
                         font=("Segoe UI", 20, "bold"), text_color=C["gold"]).grid(row=row, column=0, columnspan=3, sticky="w", padx=5, pady=(25, 10))
            row += 1
            col = 0
            for a in upcoming[:6]:
                card = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
                card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
                self.display_product_image(card, a.get("product_id"), (250, 125))
                ctk.CTkLabel(card, text=str(a.get("product_title", ""))[:28],
                             font=("Segoe UI", 16, "bold"), text_color=C["text"]).pack(anchor="w", padx=14)
                ctk.CTkLabel(card, text=f"Starting bid: {money(a.get('starting_price'))}",
                             font=("Segoe UI", 14, "bold"), text_color=C["gold"]).pack(anchor="w", padx=14, pady=(3, 2))
                timer = ctk.CTkLabel(card, text="Not active yet", font=("Segoe UI", 13, "bold"), text_color=C["muted"])
                timer.pack(anchor="w", padx=14, pady=(0, 14))
                col += 1
                if col == 3:
                    col = 0
                    row += 1

        # Ended auctions: regret, no bid button
        row += 1
        ctk.CTkLabel(area, text="Ended auctions — someone already won these",
                     font=("Segoe UI", 20, "bold"), text_color=C["red"]).grid(row=row, column=0, columnspan=3, sticky="w", padx=5, pady=(25, 10))
        row += 1
        col = 0
        for a in ended[:6]:
            card = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
            card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
            self.display_product_image(card, a.get("product_id"), (250, 125))
            ctk.CTkLabel(card, text=str(a.get("product_title", ""))[:28],
                         font=("Segoe UI", 16, "bold"), text_color=C["text"]).pack(anchor="w", padx=14)
            ctk.CTkLabel(card, text=f"Final bid: {money(a.get('current_highest'))}",
                         font=("Segoe UI", 14, "bold"), text_color=C["red"]).pack(anchor="w", padx=14, pady=(3, 2))
            winner_txt = f"Winner: {a.get('winner_name')}" if a.get('winner_name') else "No winner"
            ctk.CTkLabel(card, text=winner_txt,
                         font=("Segoe UI", 12, "bold"), text_color=C["green"] if a.get('winner_name') else C["muted"]).pack(anchor="w", padx=14, pady=(0, 3))
            ctk.CTkLabel(card, text="Ended — bidding closed",
                         font=("Segoe UI", 12, "bold"), text_color=C["muted"]).pack(anchor="w", padx=14, pady=(0, 14))
            col += 1
            if col == 3:
                col = 0
                row += 1

    def buyer_bid(self):
        try:
            auction_id = int(self.b_auc.get())
            auc = db._fetch_one("SELECT status FROM auction WHERE auction_id=%s", (auction_id,))
            if not auc:
                messagebox.showerror("Error", "Auction not found.")
                return
            if str(auc.get("status", "")).lower() != "active":
                messagebox.showerror("Error", "This auction is not active. You cannot bid on ended or upcoming auctions.")
                return
            bid_id = db.place_bid(auction_id, self.logged_user['buyer_id'], float(self.b_amt.get()))
            messagebox.showinfo("Done", "Bid placed!")
            self.buyer_auctions()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def buyer_orders(self):
        self.set_active(3); self.clr()
        self.hdr("My Orders", "Track every purchase visually")
        bid = self.logged_user.get('buyer_id')
        try:
            orders = db.get_buyer_orders(bid) if bid else []
        except Exception:
            orders = []

        wrap = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], corner_radius=0)
        wrap.pack(fill="both", expand=True, padx=25, pady=10)

        if not orders:
            ctk.CTkLabel(wrap, text="No orders yet. Start shopping and your orders will appear here.", text_color=C["muted"], font=("Segoe UI", 16, "bold")).pack(pady=40)
            return

        for i, o in enumerate(orders):
            items = self._get_order_items_visual(o.get('order_id'))
            first = items[0] if items else {}
            title = first.get('title') or f"Order #{o.get('order_id')}"
            subtitle = f"Order #{o.get('order_id')} • {o.get('order_type')} • {str(o.get('created_at',''))[:16]}"
            card = ctk.CTkFrame(wrap, fg_color=C["card"], corner_radius=26, border_color=C["line"], border_width=1)
            card.grid(row=i//2, column=i%2, padx=10, pady=10, sticky="nsew")
            wrap.grid_columnconfigure(i%2, weight=1)
            self.display_product_image(card, first.get('product_id'), (330, 170))
            ctk.CTkLabel(card, text=title, text_color=C["text"], font=("Segoe UI", 20, "bold")).pack(anchor="w", padx=16, pady=(8, 2))
            ctk.CTkLabel(card, text=subtitle, text_color=C["muted"], font=("Segoe UI", 12)).pack(anchor="w", padx=16)
            ctk.CTkLabel(card, text=f"Total: {money(o.get('final_amount'))}", text_color=C["green"], font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=16, pady=(4, 6))
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=(2, 14))
            self.product_caption_card(row, "🧾", "Order", o.get('status'), self.status_color(o.get('status')))
            self.product_caption_card(row, "💳", "Payment", o.get('payment_status') or 'pending', self.status_color(o.get('payment_status')))
            self.product_caption_card(row, "🚚", "Shipment", o.get('shipment_status') or 'preparing', self.status_color(o.get('shipment_status')))

            if str(o.get('order_type')).lower() == 'auction':
                ctk.CTkButton(card, text="📍 Confirm Auction Shipping Address", fg_color=C["gold"], height=38,
                              corner_radius=12,
                              command=lambda oid=o.get('order_id'): self._buyer_confirm_shipping_popup(oid)).pack(anchor="w", padx=16, pady=(0, 14))

    def buyer_wishlist(self):
        self.set_active(4); self.clr()
        self.hdr("My Wishlist", "Saved products with status and quick actions")
        try:
            wishlist = [w for w in db.get_wishlist() if w.get('buyer_id') == self.logged_user.get('buyer_id')]
        except Exception:
            wishlist = []

        wrap = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], corner_radius=0)
        wrap.pack(fill="both", expand=True, padx=25, pady=10)

        if not wishlist:
            ctk.CTkLabel(wrap, text="Your wishlist is empty. Save products you love to see them here.", text_color=C["muted"], font=("Segoe UI", 16, "bold")).pack(pady=40)
            return

        for i, w in enumerate(wishlist):
            product_id = w.get('product_id')
            try:
                p = db._fetch_one("""
                    SELECT p.product_id, p.title, p.price, p.stock_quantity, p.sale_type, p.item_condition,
                           s.store_name, c.name AS category
                    FROM product p
                    JOIN store s ON p.store_id=s.store_id
                    JOIN category c ON p.category_id=c.category_id
                    WHERE p.product_id=%s
                """, (product_id,)) or {}
            except Exception:
                p = {}
            stock = int(p.get('stock_quantity') or 0)
            status = "Out of stock" if stock == 0 else ("Low stock" if stock <= 5 else "Available")
            color = C["red"] if stock == 0 else (C["gold"] if stock <= 5 else C["green"])
            subtitle = f"{p.get('category','')} • {p.get('sale_type','')} • {p.get('store_name','')} • Saved: {str(w.get('added_at',''))[:16]}"
            card = self.make_product_visual_card(
                wrap, product_id, p.get('title') or w.get('product_title'), p.get('price') or w.get('price'),
                subtitle=subtitle, status_text=f"{status} ({stock})", status_color=color,
                extra_button=("Remove", lambda wid=w.get('wishlist_id'): (db.remove_wishlist(wid), messagebox.showinfo("Done", "Removed!"), self.buyer_wishlist()), C["red"])
            )
            card.grid(row=i//3, column=i%3, padx=9, pady=9, sticky="nsew")
            wrap.grid_columnconfigure(i%3, weight=1)

    def remove_wish(self, tree):
        sel = tree.selection()
        if sel:
            wid = tree.item(sel[0])['values'][0]
            db.remove_wishlist(wid)
            messagebox.showinfo("Done", "Removed!"); self.buyer_wishlist()

    def buyer_notifs(self):
        self.set_active(5); self.clr()
        self.hdr("Notifications", "Your alerts — read, unread, or remove old ones")

        top = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        top.pack(fill="x", padx=25, pady=(8, 10))
        ctk.CTkLabel(top, text="Notification Center", text_color=C["text"], font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        ctk.CTkLabel(top, text="Select one message to mark it read/unread, or apply the action to all messages.",
                     text_color=C["muted"], font=("Segoe UI", 12)).pack(anchor="w", padx=16, pady=(0, 14))

        t = self.make_tree(self.main, ("ID","Type","Title","Content","Read","Date"),
                           [50,110,160,360,80,150], h=13)
        try:
            notes = [n for n in db.get_notifications() if n.get('user_id') == self.logged_user['user_id']]
        except Exception:
            notes = []
        for n in notes:
            t.insert("","end",values=(n['notification_id'], n.get('type'),
                n.get('title'), n.get('content','')[:80],
                "Read" if n.get('is_read') else "Unread",
                str(n.get('created_at',''))[:16]))

        actions = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        actions.pack(fill="x", padx=25, pady=(0, 12))

        def selected_id():
            sel = t.selection()
            if not sel:
                messagebox.showwarning("Warning", "Select a notification first.")
                return None
            return t.item(sel[0])['values'][0]

        def set_one(is_read):
            nid = selected_id()
            if nid:
                try:
                    db._execute("UPDATE notification SET is_read=%s WHERE notification_id=%s AND user_id=%s",
                                (bool(is_read), nid, self.logged_user['user_id']))
                    self.buyer_notifs()
                except Exception as e:
                    messagebox.showerror("Error", str(e))

        def set_all(is_read):
            try:
                db._execute("UPDATE notification SET is_read=%s WHERE user_id=%s",
                            (bool(is_read), self.logged_user['user_id']))
                self.buyer_notifs()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def delete_one():
            nid = selected_id()
            if nid and messagebox.askyesno("Confirm", "Delete this notification?"):
                try:
                    db._execute("DELETE FROM notification WHERE notification_id=%s AND user_id=%s",
                                (nid, self.logged_user['user_id']))
                    self.buyer_notifs()
                except Exception as e:
                    messagebox.showerror("Error", str(e))

        ctk.CTkButton(actions, text="✅ Mark Selected Read", fg_color=C["green"], width=170, height=38,
                      corner_radius=12, command=lambda: set_one(True)).pack(side="left", padx=8, pady=12)
        ctk.CTkButton(actions, text="↩ Mark Selected Unread", fg_color=C["blue"], width=180, height=38,
                      corner_radius=12, command=lambda: set_one(False)).pack(side="left", padx=8, pady=12)
        ctk.CTkButton(actions, text="☑ Mark All Read", fg_color=C["gold"], width=145, height=38,
                      corner_radius=12, command=lambda: set_all(True)).pack(side="left", padx=8, pady=12)
        ctk.CTkButton(actions, text="☐ Mark All Unread", fg_color=C["purple"], width=155, height=38,
                      corner_radius=12, command=lambda: set_all(False)).pack(side="left", padx=8, pady=12)
        ctk.CTkButton(actions, text="🗑 Delete Selected", fg_color=C["red"], width=150, height=38,
                      corner_radius=12, command=delete_one).pack(side="left", padx=8, pady=12)

    def show_seller_dashboard(self):
        self.build_shell("Seller", C["gold"], [
            ("🏠 Home", self.seller_home),
            ("🏪 My Stores", self.seller_stores),
            ("📦 My Products", self.seller_products),
            ("🛒 My Orders", self.seller_orders),
            ("⚡ My Auctions", self.seller_aucs),
            ("➕ Add Product", self.seller_add_prod),
        ])
        self.seller_home()

    def seller_home(self):
        self.set_active(0); self.clr()
        self.hdr(f"Welcome, {self.logged_user['first_name']}!", "Your seller dashboard")
        sid = self.logged_user.get('seller_id')
        cards = ctk.CTkFrame(self.main, fg_color=C["bg"])
        cards.pack(fill="x", padx=25, pady=10)
        try:
            stores = db.get_seller_stores(sid) if sid else []
            prods = db.get_seller_products(sid) if sid else []
            orders = db.get_seller_orders(sid) if sid else []
            aucs = db.get_seller_auctions(sid) if sid else []
        except:
            stores = []; prods = []; orders = []; aucs = []
        self.stat_card(cards, "🏪", "Stores", len(stores), C["blue"], 0)
        self.stat_card(cards, "📦", "Products", len(prods), C["green"], 1)
        self.stat_card(cards, "🛒", "Orders", len(orders), C["gold"], 2)
        self.stat_card(cards, "⚡", "Auctions", len(aucs), C["purple"], 3)

        self.add_dashboard_charts()

    def seller_stores(self):
        self.set_active(1); self.clr()
        self.hdr("My Stores", "Manage your stores")
        sid = self.logged_user.get('seller_id')

        # add store form
        fm = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22)
        fm.pack(fill="x", padx=25, pady=10)
        ctk.CTkLabel(fm, text="Admin accounts can be created here safely by an existing admin. Public registration still allows only Buyer/Seller.", text_color=C["muted"], font=("Segoe UI", 11)).pack(anchor="w", padx=15, pady=(10, 0))
        r = ctk.CTkFrame(fm, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=12)
        ctk.CTkLabel(r, text="Name:").grid(row=0, column=0, padx=5)
        self.s_name = ctk.CTkEntry(r, width=160, height=35, corner_radius=8)
        self.s_name.grid(row=0, column=1, padx=5)
        ctk.CTkLabel(r, text="Description:").grid(row=0, column=2, padx=5)
        self.s_desc = ctk.CTkEntry(r, width=250, height=35, corner_radius=8)
        self.s_desc.grid(row=0, column=3, padx=5)
        ctk.CTkButton(r, text="➕ Add Store", fg_color=C["green"], width=110, height=35,
                      corner_radius=8, command=lambda: self._add_store(sid)).grid(row=0, column=4, padx=10)

        t = self.make_tree(self.main, ("ID","Name","Description","Rating","Active","Created"),
                           [45,150,200,70,60,130])
        try:
            for s in db.get_seller_stores(sid):
                t.insert("","end",values=(s['store_id'], s.get('store_name'),
                    s.get('description','')[:40], s.get('rating_avg'),
                    "✅" if s.get('is_active') else "❌", str(s.get('created_at',''))[:16]))
        except: pass

    def _add_store(self, sid):
        try:
            db.add_store(sid, self.s_name.get(), self.s_desc.get())
            messagebox.showinfo("Done", "Store added!"); self.seller_stores()
        except Exception as e:
            messagebox.showerror("Error", str(e))



    def seller_products(self):
        self.set_active(2); self.clr()
        self.hdr("My Products", "Your product listings with images, stock, and edit tools")
        sid = self.logged_user.get('seller_id')

        # Edit panel on the same page
        edit = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        edit.pack(fill="x", padx=25, pady=(8, 10))

        ctk.CTkLabel(edit, text="Edit Product", font=("Segoe UI", 17, "bold"),
                     text_color=C["text"]).grid(row=0, column=0, padx=(18, 10), pady=(14, 4), sticky="w")
        ctk.CTkLabel(edit, text="Choose Edit Product from any card below, then update values here.",
                     font=("Segoe UI", 11), text_color=C["muted"]).grid(row=0, column=1, columnspan=7, padx=5, pady=(14, 4), sticky="w")

        ctk.CTkLabel(edit, text="ID:", font=("Segoe UI", 11, "bold"), text_color=C["soft"]).grid(row=1, column=0, padx=(18, 4), pady=7, sticky="e")
        self.sp_edit_id = ctk.CTkEntry(edit, width=70, height=34, corner_radius=10)
        self.sp_edit_id.grid(row=1, column=1, padx=4, pady=7)

        self.sp_edit_title = ctk.CTkEntry(edit, placeholder_text="Title", width=155, height=34, corner_radius=10)
        self.sp_edit_title.grid(row=1, column=2, padx=4, pady=7)

        self.sp_edit_price = ctk.CTkEntry(edit, placeholder_text="Price", width=90, height=34, corner_radius=10)
        self.sp_edit_price.grid(row=1, column=3, padx=4, pady=7)

        self.sp_edit_stock = ctk.CTkEntry(edit, placeholder_text="Stock", width=80, height=34, corner_radius=10)
        self.sp_edit_stock.grid(row=1, column=4, padx=4, pady=7)

        self.sp_edit_sale = ctk.CTkComboBox(edit, values=["direct","auction","both"], width=105, height=34, corner_radius=10)
        self.sp_edit_sale.grid(row=1, column=5, padx=4, pady=7)
        self.sp_edit_sale.set("direct")

        self.sp_edit_cond = ctk.CTkComboBox(edit, values=["new","used","refurbished"], width=125, height=34, corner_radius=10)
        self.sp_edit_cond.grid(row=1, column=6, padx=4, pady=7)
        self.sp_edit_cond.set("new")

        self.sp_edit_desc = ctk.CTkEntry(edit, placeholder_text="Description", width=250, height=34, corner_radius=10)
        self.sp_edit_desc.grid(row=1, column=7, padx=4, pady=7)

        ctk.CTkButton(edit, text="💾 Update", fg_color=C["green"], width=105, height=36,
                      corner_radius=12, command=self._seller_update_selected_product).grid(row=1, column=8, padx=(8, 4), pady=7)

        ctk.CTkButton(edit, text="🖼 Upload Image", fg_color=C["gold"], width=130, height=36,
                      corner_radius=12,
                      command=lambda: self.upload_product_image_by_id(self.sp_edit_id.get())
                      ).grid(row=1, column=9, padx=(4, 4), pady=7)

        ctk.CTkButton(edit, text="🗑 Delete", fg_color=C["red"], width=95, height=36,
                      corner_radius=12,
                      command=self._seller_delete_selected_product
                      ).grid(row=1, column=10, padx=(4, 18), pady=7)

        area = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], height=560)
        area.pack(fill="both", expand=True, padx=25, pady=(0, 15))

        try:
            products = db.get_seller_products(sid)
        except Exception as e:
            products = []
            messagebox.showerror("Error", str(e))

        if not products:
            empty = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=24)
            empty.pack(fill="x", padx=10, pady=10)
            ctk.CTkLabel(empty, text="No products yet.", text_color=C["muted"],
                         font=("Segoe UI", 14, "bold")).pack(padx=20, pady=30)
            return

        for i, p in enumerate(products):
            card = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=24,
                                border_color=C["line"], border_width=1)
            card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
            area.grid_columnconfigure(i%3, weight=1)

            self.display_product_image(card, p.get("product_id"), (250, 135))

            top = ctk.CTkFrame(card, fg_color=C["card"])
            top.pack(fill="x", padx=14, pady=(8, 0))
            ctk.CTkLabel(top, text=str(p.get("title",""))[:26],
                         font=("Segoe UI", 16, "bold"), text_color=C["text"]).pack(side="left")
            ctk.CTkLabel(top, text=f"ID #{p.get('product_id')}",
                         font=("Segoe UI", 11, "bold"), text_color=C["muted"]).pack(side="right")

            stock = int(p.get("stock_quantity") or 0)
            stock_txt = "Out of stock" if stock == 0 else ("Low stock" if stock <= 5 else "In stock")
            stock_color = C["red"] if stock == 0 else (C["gold"] if stock <= 5 else C["green"])

            ctk.CTkLabel(card, text=money(p.get("price")),
                         font=("Segoe UI", 16, "bold"), text_color=C["green"]).pack(anchor="w", padx=14, pady=(5, 0))
            ctk.CTkLabel(card, text=f"{p.get('category','')} • {p.get('sale_type','')} • {p.get('item_condition','')}",
                         font=("Segoe UI", 11), text_color=C["muted"]).pack(anchor="w", padx=14, pady=(2, 0))
            ctk.CTkLabel(card, text=f"{stock_txt} ({stock})",
                         font=("Segoe UI", 12, "bold"), text_color=stock_color).pack(anchor="w", padx=14, pady=(4, 8))
            ctk.CTkLabel(card, text=f"Store: {p.get('store_name','')}",
                         font=("Segoe UI", 11), text_color=C["soft"]).pack(anchor="w", padx=14, pady=(0, 8))

            btns = ctk.CTkFrame(card, fg_color=C["card"])
            btns.pack(fill="x", padx=14, pady=(0, 14))

            ctk.CTkButton(btns, text="Edit Product", fg_color=C["black"], width=112, height=34,
                          corner_radius=12,
                          command=lambda pr=p: self._seller_fill_edit_form(pr)
                          ).pack(side="left", padx=(0, 8))

            ctk.CTkButton(btns, text="Upload Image", fg_color=C["gold"], width=120, height=34,
                          corner_radius=12,
                          command=lambda pid=p.get("product_id"): self.upload_product_image_by_id(pid)
                          ).pack(side="left", padx=(0, 8))

            ctk.CTkButton(btns, text="Delete", fg_color=C["red"], width=85, height=34,
                          corner_radius=12,
                          command=lambda pr=p: (self._seller_fill_edit_form(pr), self._seller_delete_selected_product())
                          ).pack(side="left")


    def _seller_update_selected_product(self):
        try:
            pid = self.sp_edit_id.get().strip()
            if not pid:
                messagebox.showwarning("Warning", "Select a product first using Edit Product.")
                return

            db._execute("""
                UPDATE product
                SET title=%s,
                    description=%s,
                    price=%s,
                    stock_quantity=%s,
                    sale_type=%s,
                    item_condition=%s
                WHERE product_id=%s
            """, (
                self.sp_edit_title.get().strip(),
                self.sp_edit_desc.get().strip(),
                self.sp_edit_price.get().strip(),
                self.sp_edit_stock.get().strip(),
                self.sp_edit_sale.get(),
                self.sp_edit_cond.get(),
                pid
            ))

            messagebox.showinfo("Done", "Product updated successfully.")
            self.seller_products()
        except Exception as e:
            messagebox.showerror("Error", str(e))


    def _seller_delete_selected_product(self):
        try:
            pid = self.sp_edit_id.get().strip()
            if not pid:
                messagebox.showwarning("Warning", "Select a product first using Edit Product.")
                return

            if not messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this product?"):
                return

            # Prefer soft delete when is_active exists to preserve order history.
            try:
                db._execute("UPDATE product SET is_active=FALSE WHERE product_id=%s", (pid,))
            except Exception:
                # Fallback for schemas without is_active.
                db._execute("DELETE FROM product WHERE product_id=%s", (pid,))

            messagebox.showinfo("Done", "Product deleted successfully.")
            self.seller_products()

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _seller_fill_edit_form(self, product):
        self.sp_edit_id.delete(0, "end")
        self.sp_edit_id.insert(0, str(product.get("product_id", "")))

        self.sp_edit_title.delete(0, "end")
        self.sp_edit_title.insert(0, str(product.get("title", "")))

        self.sp_edit_desc.delete(0, "end")
        self.sp_edit_desc.insert(0, str(product.get("description", "")))

        self.sp_edit_price.delete(0, "end")
        self.sp_edit_price.insert(0, str(product.get("price", "")))

        self.sp_edit_stock.delete(0, "end")
        self.sp_edit_stock.insert(0, str(product.get("stock_quantity", "")))

        self.sp_edit_sale.set(str(product.get("sale_type", "direct")))
        self.sp_edit_cond.set(str(product.get("item_condition", "new")))


    def seller_orders(self):
        self.set_active(3); self.clr()
        self.hdr("My Orders", "Orders containing your products")
        sid = self.logged_user.get('seller_id')

        t = self.make_tree(self.main, ("ID","Buyer","Store","Total","Status","Date"),
                           [45,130,110,90,85,130])

        # status update
        uf = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22)
        uf.pack(fill="x", padx=25, pady=10)
        r = ctk.CTkFrame(uf, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=12)
        ctk.CTkLabel(r, text="Update Order Status:").grid(row=0, column=0, padx=5)
        self.so_status = ctk.CTkComboBox(r, values=["confirmed","processing","shipped","delivered"], width=140, height=35)
        self.so_status.grid(row=0, column=1, padx=5)
        ctk.CTkButton(r, text="✏️ Update", fg_color=C["blue"], width=100, height=35,
                      corner_radius=8, command=lambda: self._seller_upd_order(t)).grid(row=0, column=2, padx=5)

        ctk.CTkLabel(r, text="Shipment:").grid(row=0, column=3, padx=(20,5))
        self.so_ship = ctk.CTkComboBox(r, values=["preparing","shipped","in_transit","delivered"], width=130, height=35)
        self.so_ship.grid(row=0, column=4, padx=5)
        ctk.CTkButton(r, text="📦 Update", fg_color=C["gold"], width=100, height=35,
                      corner_radius=8, command=lambda: self._seller_upd_ship(t)).grid(row=0, column=5, padx=5)

        try:
            for o in db.get_seller_orders(sid):
                t.insert("","end",values=(o.get('order_id'),
                    f"{o.get('first_name','')} {o.get('last_name','')}",
                    o.get('store_name'), money(o.get('final_amount')),
                    o.get('status'), str(o.get('created_at',''))[:16]))
        except: pass

    def _seller_upd_order(self, tree):
        sel = tree.selection()
        if not sel: messagebox.showwarning("Warning", "Select an order"); return
        oid = tree.item(sel[0])['values'][0]
        try:
            db.update_order_status(oid, self.so_status.get())
            messagebox.showinfo("Done", "Order status updated!")
            self.seller_orders()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _seller_upd_ship(self, tree):
        sel = tree.selection()
        if not sel: messagebox.showwarning("Warning", "Select an order"); return
        oid = tree.item(sel[0])['values'][0]
        try:
            db.update_shipment_status(oid, self.so_ship.get())
            messagebox.showinfo("Done", "Shipment updated!")
        except Exception as e:
            messagebox.showerror("Error", str(e))


    def seller_aucs(self):
        self.set_active(4); self.clr()
        self.hdr("My Auctions", "Track auction sessions, bids, status, and winners")
        self._sync_auction_statuses()
        sid = self.logged_user.get('seller_id')

        info = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
        info.pack(fill="x", padx=25, pady=(8, 10))
        ctk.CTkLabel(info, text="Status guide: Active = buyers can bid now | Upcoming = waiting for start time | Ended = winner selected | Cancelled = closed",
                     text_color=C["muted"], font=("Segoe UI", 12)).pack(anchor="w", padx=16, pady=14)

        area = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], height=610)
        area.pack(fill="both", expand=True, padx=25, pady=(0, 15))

        try:
            auctions = db.get_seller_auctions(sid)
        except Exception as e:
            auctions = []
            messagebox.showerror("Error", str(e))

        if not auctions:
            ctk.CTkLabel(area, text="No auctions yet. Add a product with sale type auction or both.",
                         text_color=C["muted"], font=("Segoe UI", 15, "bold")).pack(pady=35)
            return

        for i, a in enumerate(auctions):
            card = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
            card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
            area.grid_columnconfigure(i%3, weight=1)

            self.display_product_image(card, a.get("product_id"), (250, 130))

            ctk.CTkLabel(card, text=str(a.get("product_title",""))[:28],
                         text_color=C["text"], font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=14, pady=(8, 2))
            status = str(a.get("status","")).lower()
            status_color = C["green"] if status=="active" else (C["gold"] if status=="upcoming" else (C["red"] if status=="ended" else C["muted"]))
            ctk.CTkLabel(card, text=f"Status: {a.get('status')}",
                         text_color=status_color, font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=14)

            ctk.CTkLabel(card, text=f"Starting: {money(a.get('starting_price'))} | Highest: {money(a.get('current_highest'))}",
                         text_color=C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=14, pady=(4, 0))
            ctk.CTkLabel(card, text=f"Bids: {a.get('bid_count',0)}",
                         text_color=C["soft"], font=("Segoe UI", 12)).pack(anchor="w", padx=14)
            ctk.CTkLabel(card, text=f"Winner: {a.get('winner_name') or '-'}",
                         text_color=C["text"], font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=14)
            ctk.CTkLabel(card, text=f"Ends: {str(a.get('end_time',''))[:16]}",
                         text_color=C["muted"], font=("Segoe UI", 11)).pack(anchor="w", padx=14, pady=(0, 10))

            ctk.CTkButton(card, text="View Bid Details", fg_color=C["black"], height=34,
                          corner_radius=12,
                          command=lambda aid=a.get("auction_id"): self._show_auction_details_popup(aid)).pack(anchor="w", padx=14, pady=(0, 14))


    def seller_add_prod(self):
        self.set_active(5); self.clr()
        self.hdr("Add Product", "Add a product; if it is auction/both, create its auction schedule immediately")
        sid = self.logged_user.get('seller_id')

        fm = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        fm.pack(fill="x", padx=25, pady=10)

        ctk.CTkLabel(fm, text="Product Details", font=("Segoe UI", 18, "bold"),
                     text_color=C["text"]).pack(anchor="w", padx=20, pady=(18, 4))
        ctk.CTkLabel(fm, text="Important: choosing auction or both requires auction timing, so buyers can see and bid.",
                     font=("Segoe UI", 12), text_color=C["muted"]).pack(anchor="w", padx=20, pady=(0, 10))

        f = ctk.CTkFrame(fm, fg_color=C["card"])
        f.pack(fill="x", padx=20, pady=10)

        fields = {}
        spec = [
            ("Title", 260), ("Price", 120), ("Stock", 90),
            ("Store ID", 90), ("Category ID", 100), ("Description", 320)
        ]
        for i, (lbl, w) in enumerate(spec):
            ctk.CTkLabel(f, text=lbl+":", text_color=C["soft"],
                         font=("Segoe UI", 12, "bold")).grid(row=i//3, column=(i%3)*2, padx=6, pady=8, sticky="w")
            e = ctk.CTkEntry(f, width=w, height=38, corner_radius=12)
            e.grid(row=i//3, column=(i%3)*2+1, padx=6, pady=8)
            fields[lbl] = e

        r2 = ctk.CTkFrame(fm, fg_color=C["card"])
        r2.pack(fill="x", padx=20, pady=(4, 10))
        ctk.CTkLabel(r2, text="Sale Type:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).pack(side="left", padx=5)
        sale = ctk.CTkComboBox(r2, values=["direct","auction","both"], width=120, height=38, corner_radius=12)
        sale.pack(side="left", padx=6); sale.set("direct")
        ctk.CTkLabel(r2, text="Condition:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).pack(side="left", padx=(20,5))
        cond = ctk.CTkComboBox(r2, values=["new","used","refurbished"], width=135, height=38, corner_radius=12)
        cond.pack(side="left", padx=6); cond.set("new")

        # Auction details box: used when sale_type is auction/both
        auction_box = ctk.CTkFrame(fm, fg_color=C["mint"], corner_radius=18, border_color=C["line"], border_width=1)
        auction_box.pack(fill="x", padx=20, pady=(0, 16))

        ctk.CTkLabel(auction_box, text="Auction Details — required only for auction / both",
                     font=("Segoe UI", 15, "bold"), text_color=C["text"]).grid(row=0, column=0, columnspan=8, padx=15, pady=(12, 4), sticky="w")

        self.ap_starting = ctk.CTkEntry(auction_box, width=130, height=36, corner_radius=10, placeholder_text="Starting Price")
        self.ap_starting.grid(row=1, column=0, padx=(15, 5), pady=10)

        self.ap_reserve = ctk.CTkEntry(auction_box, width=130, height=36, corner_radius=10, placeholder_text="Reserve Price")
        self.ap_reserve.grid(row=1, column=1, padx=5, pady=10)

        self.ap_start = ctk.CTkEntry(auction_box, width=190, height=36, corner_radius=10, placeholder_text="Start: YYYY-MM-DD HH:MM:SS")
        self.ap_start.grid(row=1, column=2, padx=5, pady=10)

        self.ap_end = ctk.CTkEntry(auction_box, width=190, height=36, corner_radius=10, placeholder_text="End: YYYY-MM-DD HH:MM:SS")
        self.ap_end.grid(row=1, column=3, padx=5, pady=10)

        def fill_now_plus():
            try:
                now = datetime.now()
                start_txt = now.strftime("%Y-%m-%d %H:%M:%S")
                end_txt = (__import__("datetime").datetime.now().replace(microsecond=0) + __import__("datetime").timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
                self.ap_start.delete(0, "end"); self.ap_start.insert(0, start_txt)
                self.ap_end.delete(0, "end"); self.ap_end.insert(0, end_txt)
            except Exception:
                pass

        ctk.CTkButton(auction_box, text="⏱ Start Now + 1h", fg_color=C["gold"], width=135, height=36,
                      corner_radius=10, command=fill_now_plus).grid(row=1, column=4, padx=8, pady=10)

        ctk.CTkLabel(auction_box, text="If sale type is direct, these fields are ignored.",
                     font=("Segoe UI", 11), text_color=C["muted"]).grid(row=2, column=0, columnspan=5, padx=15, pady=(0, 12), sticky="w")

        def add():
            try:
                if hasattr(db, "add_product_with_optional_auction"):
                    result = db.add_product_with_optional_auction(
                        fields["Store ID"].get(), fields["Category ID"].get(),
                        fields["Title"].get(), fields["Description"].get(),
                        fields["Price"].get(), fields["Stock"].get(),
                        sale.get(), cond.get(),
                        self.ap_starting.get(), self.ap_reserve.get(),
                        self.ap_start.get(), self.ap_end.get()
                    )
                    product_id = result.get("product_id")
                    auction_id = result.get("auction_id")
                else:
                    product_id = db.add_product(fields["Store ID"].get(), fields["Category ID"].get(),
                                   fields["Title"].get(), fields["Description"].get(),
                                   fields["Price"].get(), fields["Stock"].get(),
                                   sale.get(), cond.get())
                    auction_id = None
                    if sale.get() in ("auction", "both"):
                        auction_id = db.create_auction(product_id, self.ap_starting.get(), self.ap_reserve.get(),
                                                       self.ap_start.get(), self.ap_end.get())

                self.new_product_image_id.delete(0, "end")
                self.new_product_image_id.insert(0, str(product_id))

                if auction_id:
                    messagebox.showinfo("Done", f"Product #{product_id} added and Auction #{auction_id} created successfully.")
                else:
                    messagebox.showinfo("Done", f"Product #{product_id} added successfully.")

            except Exception as e:
                messagebox.showerror("Error", str(e))

        ctk.CTkButton(r2, text="➕ Add Product", fg_color=C["green"], width=145, height=40,
                      corner_radius=12, font=("Segoe UI", 13, "bold"), command=add).pack(side="right", padx=10)

        img_box = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        img_box.pack(fill="x", padx=25, pady=10)
        ctk.CTkLabel(img_box, text="Image Upload", font=("Segoe UI", 17, "bold"),
                     text_color=C["text"]).pack(side="left", padx=(18, 10), pady=16)
        ctk.CTkLabel(img_box, text="Product ID:", text_color=C["soft"],
                     font=("Segoe UI", 12, "bold")).pack(side="left", padx=5)
        self.new_product_image_id = ctk.CTkEntry(img_box, width=110, height=38, corner_radius=12,
                                                 placeholder_text="ID")
        self.new_product_image_id.pack(side="left", padx=6, pady=14)
        ctk.CTkButton(img_box, text="🖼 Upload Image by ID", fg_color=C["gold"], width=170, height=40,
                      corner_radius=12,
                      command=lambda: self.upload_product_image_by_id(self.new_product_image_id.get())
                      ).pack(side="left", padx=10, pady=14)


    def show_admin_dashboard(self):
        self.build_shell("Admin", C["accent"], [
            ("📊 Dashboard", self.admin_home),
            ("👥 All Users", self.admin_users),
            ("📦 All Products", self.admin_products),
            ("🛒 All Orders", self.admin_orders),
            ("⚡ All Auctions", self.admin_auctions),
            ("🏪 Stores", self.admin_stores),
            ("📂 Categories", self.admin_categories),
            ("⚠️ Reports", self.admin_reports),
            ("🔔 Notifications", self.admin_notifs),
        ])
        self.admin_home()

    def admin_home(self):
        self.set_active(0); self.clr()
        self.hdr("Admin Dashboard", "Platform overview")
        try: s = db.get_stats()
        except: s = {'users':0,'products':0,'orders':0,'auctions':0}
        cards = ctk.CTkFrame(self.main, fg_color=C["bg"])
        cards.pack(fill="x", padx=25, pady=10)
        self.stat_card(cards, "👥", "Users", s['users'], C["blue"], 0)
        self.stat_card(cards, "📦", "Products", s['products'], C["green"], 1)
        self.stat_card(cards, "🛒", "Orders", s['orders'], C["red"], 2)
        self.stat_card(cards, "⚡", "Auctions", s['auctions'], C["purple"], 3)

        self.add_dashboard_charts()

        # recent orders
        t = self.make_tree(self.main, ("ID","Buyer","Total","Status","Payment","Shipment","Date"),
                           [45,130,90,85,85,85,130])
        try:
            for o in db.get_all_orders()[:10]:
                t.insert("","end",values=(o.get('order_id'),
                    f"{o.get('first_name','')} {o.get('last_name','')}",
                    money(o.get('total_amount')), o.get('status'),
                    o.get('payment_status') or '-', o.get('shipment_status') or '-',
                    str(o.get('created_at',''))[:16]))
        except: pass

    def admin_users(self):
        self.set_active(1); self.clr()
        self.hdr("All Users", "Manage platform users")
        fm = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22)
        fm.pack(fill="x", padx=25, pady=10)
        ctk.CTkLabel(fm, text="Admin accounts can be created here safely by an existing admin. Public registration still allows only Buyer/Seller.", text_color=C["muted"], font=("Segoe UI", 11)).pack(anchor="w", padx=15, pady=(10, 0))
        r = ctk.CTkFrame(fm, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=12)
        self.au_fn = ctk.CTkEntry(r, placeholder_text="First", width=110, height=35, corner_radius=8)
        self.au_fn.grid(row=0, column=0, padx=4)
        self.au_ln = ctk.CTkEntry(r, placeholder_text="Last", width=110, height=35, corner_radius=8)
        self.au_ln.grid(row=0, column=1, padx=4)
        self.au_em = ctk.CTkEntry(r, placeholder_text="Email", width=160, height=35, corner_radius=8)
        self.au_em.grid(row=0, column=2, padx=4)
        self.au_ph = ctk.CTkEntry(r, placeholder_text="Phone", width=110, height=35, corner_radius=8)
        self.au_ph.grid(row=0, column=3, padx=4)
        self.au_pw = ctk.CTkEntry(r, placeholder_text="Password", width=110, height=35, corner_radius=8, show="●")
        self.au_pw.grid(row=0, column=4, padx=4)
        self.au_tp = ctk.CTkComboBox(r, values=["buyer","seller","admin"], width=100, height=35)
        self.au_tp.grid(row=0, column=5, padx=4); self.au_tp.set("buyer")
        ctk.CTkButton(r, text="➕ Add", fg_color=C["green"], width=70, height=35, corner_radius=8,
                      command=self._admin_add_user).grid(row=0, column=6, padx=4)
        ctk.CTkButton(r, text="Delete User", fg_color=C["red"], width=155, height=35, corner_radius=8,
                      command=lambda: self._admin_del_user(t)).grid(row=0, column=7, padx=4)

        t = self.make_tree(self.main, ("ID","First","Last","Email","Phone","Type","Active"),
                           [40,90,90,170,100,70,55])
        try:
            for u in db.get_all_users():
                t.insert("","end",values=(u['user_id'], u['first_name'], u['last_name'],
                    u['email'], u.get('phone',''), u['user_type'],
                    "✅" if u.get('is_active') else "❌"))
        except: pass

    def _admin_add_user(self):
        try:
            pw = self.au_pw.get().strip() if hasattr(self, "au_pw") else ""
            if not pw:
                messagebox.showwarning("Warning", "Password is required for the new user.")
                return
            db.add_user(self.au_fn.get(), self.au_ln.get(), self.au_em.get(),
                        f"hash{pw}", self.au_ph.get(), self.au_tp.get())
            messagebox.showinfo("Done", "User added!")
            self.admin_users()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _admin_del_user(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a user")
            return
        vals = tree.item(sel[0])['values']
        uid = vals[0]
        role = str(vals[5]).lower() if len(vals) > 5 else ""

        msg = (
            "This is a SAFE DELETE / DEACTIVATE action.\n\n"
            "If the selected user is a Seller, the system will:\n"
            "- deactivate the seller account\n"
            "- deactivate their stores\n"
            "- deactivate their products\n"
            "- cancel active/upcoming auctions\n"
            "- keep old orders, bids, and reviews for history\n\n"
            "Continue?"
        )

        if messagebox.askyesno("Confirm Safe Delete", msg):
            try:
                if hasattr(db, "deactivate_user_cascade"):
                    db.deactivate_user_cascade(uid, self.logged_user.get("user_id"))
                else:
                    db.delete_user(uid)
                messagebox.showinfo("Done", f"{role.title() if role else 'User'} deactivated safely.")
                self.admin_users()
            except Exception as e:
                messagebox.showerror("Error", str(e))


    def admin_products(self):
        self.set_active(2); self.clr()
        self.hdr("All Products", "Platform-wide product gallery with photos and product tools")

        tools = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        tools.pack(fill="x", padx=25, pady=(8, 10))
        ctk.CTkLabel(tools, text="Admin Product Studio", font=("Segoe UI", 17, "bold"),
                     text_color=C["text"]).pack(side="left", padx=(18, 10), pady=14)
        ctk.CTkLabel(tools, text="Product ID:", font=("Segoe UI", 12, "bold"),
                     text_color=C["soft"]).pack(side="left", padx=(10, 5))
        self.admin_img_pid = ctk.CTkEntry(tools, width=100, height=36, corner_radius=12,
                                          placeholder_text="ID")
        self.admin_img_pid.pack(side="left", padx=5, pady=12)
        ctk.CTkButton(tools, text="🖼 Upload Image", fg_color=C["gold"], width=145, height=38,
                      corner_radius=12,
                      command=lambda: self.upload_product_image_by_id(self.admin_img_pid.get())
                      ).pack(side="left", padx=10, pady=12)

        area = ctk.CTkScrollableFrame(self.main, fg_color=C["bg"], height=600)
        area.pack(fill="both", expand=True, padx=25, pady=(0, 15))

        try:
            products = db.get_all_products()
        except Exception as e:
            products = []
            messagebox.showerror("Error", str(e))

        if not products:
            ctk.CTkLabel(area, text="No products found.", text_color=C["muted"],
                         font=("Segoe UI", 14, "bold")).pack(pady=30)
            return

        for i, p in enumerate(products):
            card = ctk.CTkFrame(area, fg_color=C["card"], corner_radius=24,
                                border_color=C["line"], border_width=1)
            card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
            area.grid_columnconfigure(i%3, weight=1)

            self.display_product_image(card, p.get("product_id"), (250, 135))
            top = ctk.CTkFrame(card, fg_color=C["card"])
            top.pack(fill="x", padx=14, pady=(8, 0))
            ctk.CTkLabel(top, text=str(p.get("title",""))[:25],
                         font=("Segoe UI", 16, "bold"), text_color=C["text"]).pack(side="left")
            ctk.CTkLabel(top, text=f"ID #{p.get('product_id')}",
                         font=("Segoe UI", 11, "bold"), text_color=C["muted"]).pack(side="right")

            stock = int(p.get("stock_quantity") or 0)
            stock_txt = "Out of stock" if stock == 0 else ("Low stock" if stock <= 5 else "In stock")
            stock_color = C["red"] if stock == 0 else (C["gold"] if stock <= 5 else C["green"])

            ctk.CTkLabel(card, text=money(p.get("price")),
                         font=("Segoe UI", 16, "bold"), text_color=C["green"]).pack(anchor="w", padx=14, pady=(5, 0))
            ctk.CTkLabel(card, text=f"{p.get('category','')} • {p.get('sale_type','')} • {p.get('item_condition','')}",
                         font=("Segoe UI", 11), text_color=C["muted"]).pack(anchor="w", padx=14, pady=(2, 0))
            ctk.CTkLabel(card, text=f"{stock_txt} ({stock})",
                         font=("Segoe UI", 12, "bold"), text_color=stock_color).pack(anchor="w", padx=14, pady=(4, 6))
            ctk.CTkLabel(card, text=f"Store: {p.get('store_name','')}",
                         font=("Segoe UI", 11), text_color=C["soft"]).pack(anchor="w", padx=14, pady=(0, 8))

            btns = ctk.CTkFrame(card, fg_color=C["card"])
            btns.pack(fill="x", padx=14, pady=(0, 14))
            ctk.CTkButton(btns, text="Use ID", fg_color=C["black"], width=85, height=34,
                          corner_radius=12,
                          command=lambda pid=p.get("product_id"): (self.admin_img_pid.delete(0, "end"),
                                                                   self.admin_img_pid.insert(0, pid))
                          ).pack(side="left", padx=(0, 8))
            ctk.CTkButton(btns, text="Upload Image", fg_color=C["gold"], width=120, height=34,
                          corner_radius=12,
                          command=lambda pid=p.get("product_id"): self.upload_product_image_by_id(pid)
                          ).pack(side="left", padx=(0, 8))

            ctk.CTkButton(btns, text="Delete", fg_color=C["red"], width=85, height=34,
                          corner_radius=12,
                          command=lambda pr=p: (self._seller_fill_edit_form(pr), self._seller_delete_selected_product())
                          ).pack(side="left")



    def admin_orders(self):
        self.set_active(3); self.clr()
        self.hdr("All Orders", "Manage order, payment, and shipment statuses clearly")

        uf = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        uf.pack(fill="x", padx=25, pady=10)

        r = ctk.CTkFrame(uf, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=14)

        ctk.CTkLabel(r, text="Order Status:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=5)
        self.ao_st = ctk.CTkComboBox(r, values=["pending","confirmed","processing","shipped","delivered","cancelled","returned"],
                                     width=135, height=36, corner_radius=12)
        self.ao_st.grid(row=0, column=1, padx=5)
        ctk.CTkButton(r, text="✏️ Update Order", fg_color=C["blue"], width=125, height=36,
                      corner_radius=12, command=lambda: self._admin_upd_order(t)).grid(row=0, column=2, padx=6)

        ctk.CTkLabel(r, text="Payment:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).grid(row=0, column=3, padx=(18,5))
        self.ao_pay = ctk.CTkComboBox(r, values=["pending","completed","failed","refunded"], width=125, height=36, corner_radius=12)
        self.ao_pay.grid(row=0, column=4, padx=5)
        ctk.CTkButton(r, text="💳 Update", fg_color=C["gold"], width=105, height=36,
                      corner_radius=12, command=lambda: self._admin_upd_pay(t)).grid(row=0, column=5, padx=6)

        ctk.CTkLabel(r, text="Shipment:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).grid(row=0, column=6, padx=(18,5))
        self.ao_ship = ctk.CTkComboBox(r, values=["preparing","shipped","in_transit","delivered","returned"], width=130, height=36, corner_radius=12)
        self.ao_ship.grid(row=0, column=7, padx=5)
        ctk.CTkButton(r, text="🚚 Update", fg_color=C["green"], width=105, height=36,
                      corner_radius=12, command=lambda: self._admin_upd_ship(t)).grid(row=0, column=8, padx=6)

        ctk.CTkButton(r, text="🗑️ Delete", fg_color=C["red"], width=90, height=36,
                      corner_radius=12, command=lambda: self._admin_del_order(t)).grid(row=0, column=9, padx=(18,5))

        t = self.make_tree(self.main, ("ID","Buyer","Type","Total","Order Status","Payment Status","Shipment Status","Date"),
                           [45,140,85,95,110,120,125,145], h=14)

        try:
            for o in db.get_all_orders():
                order_status = o.get('status') or '-'
                payment_status = o.get('payment_status') or '-'
                shipment_status = o.get('shipment_status') or '-'
                t.insert("","end",values=(o.get('order_id'),
                    f"{o.get('first_name','')} {o.get('last_name','')}",
                    o.get('order_type'), money(o.get('total_amount')),
                    f"🧾 {order_status}", f"💳 {payment_status}",
                    f"🚚 {shipment_status}", str(o.get('created_at',''))[:16]))
        except Exception as e:
            messagebox.showerror("Error", str(e))


    def _admin_upd_order(self, tree):
        sel = tree.selection()
        if not sel: return
        try:
            db.update_order_status(tree.item(sel[0])['values'][0], self.ao_st.get())
            messagebox.showinfo("Done", "Updated!"); self.admin_orders()
        except Exception as e: messagebox.showerror("Error", str(e))

    def _admin_upd_pay(self, tree):
        sel = tree.selection()
        if not sel: return
        try:
            db.update_payment_status(tree.item(sel[0])['values'][0], self.ao_pay.get())
            messagebox.showinfo("Done", "Payment updated!")
        except Exception as e: messagebox.showerror("Error", str(e))


    def _admin_upd_ship(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select an order")
            return
        try:
            db.update_shipment_status(tree.item(sel[0])['values'][0], self.ao_ship.get())
            messagebox.showinfo("Done", "Shipment updated!")
            self.admin_orders()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _admin_del_order(self, tree):
        sel = tree.selection()
        if not sel: return
        if messagebox.askyesno("Confirm", "Delete order?"):
            try:
                db.delete_order(tree.item(sel[0])['values'][0])
                messagebox.showinfo("Done", "Deleted!"); self.admin_orders()
            except Exception as e: messagebox.showerror("Error", str(e))

    def admin_auctions(self):
        self.set_active(4); self.clr()
        self.hdr("All Auctions", "Platform auctions")
        self._sync_auction_statuses()
        t = self.make_tree(self.main, ("ID","Product","Store","Start$","Highest","Bids","Status","Winner","Ends"),
                           [40,140,90,80,80,50,75,130,130])
        try:
            for a in db.get_auctions():
                winner = a.get('winner_name') if a.get('winner_name') else '-'
                t.insert("","end",values=(a['auction_id'], a.get('product_title'),
                    a.get('store_name'), money(a.get('starting_price')),
                    money(a.get('current_highest')), a.get('bid_count',0),
                    a.get('status'), winner, str(a.get('end_time',''))[:16]))
        except: pass

        actions = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
        actions.pack(fill="x", padx=25, pady=8)
        ctk.CTkButton(actions, text="View Selected Auction Details", fg_color=C["black"], height=38,
                      corner_radius=12,
                      command=lambda: self._show_auction_details_popup(self._selected_tree_first_value(t, "Select an auction first.")) if self._selected_tree_first_value(t, "Select an auction first.") else None
                      ).pack(side="left", padx=12, pady=12)


    def admin_stores(self):
        self.set_active(5); self.clr()
        self.hdr("Stores", "Manage seller stores and verify store ownership")

        form = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        form.pack(fill="x", padx=25, pady=10)

        row = ctk.CTkFrame(form, fg_color=C["card"])
        row.pack(fill="x", padx=15, pady=12)

        ctk.CTkLabel(row, text="Store ID:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=5)
        self.as_id = ctk.CTkEntry(row, width=70, height=36, corner_radius=10, placeholder_text="ID")
        self.as_id.grid(row=0, column=1, padx=5)

        ctk.CTkLabel(row, text="Seller ID:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).grid(row=0, column=2, padx=5)
        self.as_seller = ctk.CTkEntry(row, width=90, height=36, corner_radius=10, placeholder_text="Seller ID")
        self.as_seller.grid(row=0, column=3, padx=5)

        self.as_name = ctk.CTkEntry(row, width=180, height=36, corner_radius=10, placeholder_text="Store Name")
        self.as_name.grid(row=0, column=4, padx=5)

        self.as_desc = ctk.CTkEntry(row, width=260, height=36, corner_radius=10, placeholder_text="Description")
        self.as_desc.grid(row=0, column=5, padx=5)

        def fill_from_tree():
            sel = t.selection()
            if not sel:
                messagebox.showwarning("Warning", "Select a store first.")
                return
            vals = t.item(sel[0])["values"]
            self.as_id.delete(0, "end"); self.as_id.insert(0, vals[0])
            self.as_seller.delete(0, "end"); self.as_seller.insert(0, vals[1])
            self.as_name.delete(0, "end"); self.as_name.insert(0, vals[2])
            self.as_desc.delete(0, "end"); self.as_desc.insert(0, vals[3])

        def add_store():
            try:
                db.add_store(self.as_seller.get(), self.as_name.get(), self.as_desc.get())
                messagebox.showinfo("Done", "Store added successfully.")
                self.admin_stores()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def update_store():
            try:
                db.update_store(self.as_id.get(), self.as_name.get(), self.as_desc.get())
                messagebox.showinfo("Done", "Store updated successfully.")
                self.admin_stores()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def delete_store():
            try:
                if not self.as_id.get().strip():
                    messagebox.showwarning("Warning", "Select a store first.")
                    return
                if not messagebox.askyesno("Confirm", "Soft delete this store and deactivate its products?"):
                    return
                db.delete_store(self.as_id.get())
                messagebox.showinfo("Done", "Store deactivated successfully.")
                self.admin_stores()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        ctk.CTkButton(row, text="Select", fg_color=C["black"], width=80, height=36,
                      corner_radius=10, command=fill_from_tree).grid(row=0, column=6, padx=5)
        ctk.CTkButton(row, text="Add", fg_color=C["green"], width=80, height=36,
                      corner_radius=10, command=add_store).grid(row=0, column=7, padx=5)
        ctk.CTkButton(row, text="Update", fg_color=C["blue"], width=90, height=36,
                      corner_radius=10, command=update_store).grid(row=0, column=8, padx=5)
        ctk.CTkButton(row, text="Deactivate", fg_color=C["red"], width=105, height=36,
                      corner_radius=10, command=delete_store).grid(row=0, column=9, padx=5)

        t = self.make_tree(self.main, ("Store ID","Seller ID","Store Name","Description","Owner","Active","Products"),
                           [75,75,180,260,150,70,80], h=15)

        try:
            stores = db.get_stores()
            for s in stores:
                product_count = 0
                try:
                    pc = db._fetch_one("SELECT COUNT(*) AS c FROM product WHERE store_id=%s AND is_active=TRUE", (s.get("store_id"),))
                    product_count = pc.get("c", 0) if pc else 0
                except Exception:
                    pass
                owner = f"{s.get('first_name','')} {s.get('last_name','')}".strip()
                active = "Yes" if s.get("is_active", True) else "No"
                t.insert("", "end", values=(s.get("store_id"), s.get("seller_id"),
                    s.get("store_name"), s.get("description",""), owner, active, product_count))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def admin_categories(self):
        self.set_active(6); self.clr()
        self.hdr("Categories", "Manage marketplace product categories")

        form = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=24, border_color=C["line"], border_width=1)
        form.pack(fill="x", padx=25, pady=10)

        row = ctk.CTkFrame(form, fg_color=C["card"])
        row.pack(fill="x", padx=15, pady=12)

        ctk.CTkLabel(row, text="Category ID:", text_color=C["soft"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=5)
        self.ac_id = ctk.CTkEntry(row, width=80, height=36, corner_radius=10, placeholder_text="ID")
        self.ac_id.grid(row=0, column=1, padx=5)

        self.ac_name = ctk.CTkEntry(row, width=190, height=36, corner_radius=10, placeholder_text="Category Name")
        self.ac_name.grid(row=0, column=2, padx=5)

        self.ac_desc = ctk.CTkEntry(row, width=320, height=36, corner_radius=10, placeholder_text="Description")
        self.ac_desc.grid(row=0, column=3, padx=5)

        def fill_from_tree():
            sel = t.selection()
            if not sel:
                messagebox.showwarning("Warning", "Select a category first.")
                return
            vals = t.item(sel[0])["values"]
            self.ac_id.delete(0, "end"); self.ac_id.insert(0, vals[0])
            self.ac_name.delete(0, "end"); self.ac_name.insert(0, vals[1])
            self.ac_desc.delete(0, "end"); self.ac_desc.insert(0, vals[2])

        def add_category():
            try:
                db.add_category(self.ac_name.get(), self.ac_desc.get())
                messagebox.showinfo("Done", "Category added successfully.")
                self.admin_categories()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def update_category():
            try:
                db.update_category(self.ac_id.get(), self.ac_name.get(), self.ac_desc.get())
                messagebox.showinfo("Done", "Category updated successfully.")
                self.admin_categories()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def delete_category():
            try:
                if not self.ac_id.get().strip():
                    messagebox.showwarning("Warning", "Select a category first.")
                    return
                if not messagebox.askyesno("Confirm", "Delete this category? It cannot be deleted if active products use it."):
                    return
                db.delete_category(self.ac_id.get())
                messagebox.showinfo("Done", "Category deleted successfully.")
                self.admin_categories()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        ctk.CTkButton(row, text="Select", fg_color=C["black"], width=80, height=36,
                      corner_radius=10, command=fill_from_tree).grid(row=0, column=4, padx=5)
        ctk.CTkButton(row, text="Add", fg_color=C["green"], width=80, height=36,
                      corner_radius=10, command=add_category).grid(row=0, column=5, padx=5)
        ctk.CTkButton(row, text="Update", fg_color=C["blue"], width=90, height=36,
                      corner_radius=10, command=update_category).grid(row=0, column=6, padx=5)
        ctk.CTkButton(row, text="Deactivate", fg_color=C["red"], width=105, height=36,
                      corner_radius=10, command=delete_category).grid(row=0, column=7, padx=5)

        t = self.make_tree(self.main, ("ID","Name","Description","Active Products"),
                           [70,190,420,120], h=15)

        try:
            for c in db.get_categories():
                t.insert("", "end", values=(c.get("category_id"), c.get("name"),
                    c.get("description",""), c.get("product_count", 0)))
        except Exception as e:
            messagebox.showerror("Error", str(e))



    def admin_reports(self):
        self.set_active(7); self.clr()
        self.hdr("Reports", "Handle violations and moderation actions")

        uf = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22, border_color=C["line"], border_width=1)
        uf.pack(fill="x", padx=25, pady=10)
        r = ctk.CTkFrame(uf, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=12)
        self.ar_st = ctk.CTkComboBox(r, values=["reviewed","resolved","dismissed"], width=120, height=35)
        self.ar_st.grid(row=0, column=0, padx=5)
        ctk.CTkButton(r, text="✏️ Update Status", fg_color=C["blue"], width=130, height=35,
                      corner_radius=8, command=lambda: self._admin_upd_report(t)).grid(row=0, column=1, padx=5)
        ctk.CTkButton(r, text="🚫 Deactivate Target", fg_color=C["red"], width=150, height=35,
                      corner_radius=8, command=lambda: self._admin_deactivate_report_target(t)).grid(row=0, column=2, padx=5)
        ctk.CTkButton(r, text="✅ Resolve", fg_color=C["green"], width=95, height=35,
                      corner_radius=8, command=lambda: self._admin_set_report_status(t, "resolved")).grid(row=0, column=3, padx=5)
        ctk.CTkButton(r, text="Dismiss", fg_color=C["gold"], width=95, height=35,
                      corner_radius=8, command=lambda: self._admin_set_report_status(t, "dismissed")).grid(row=0, column=4, padx=5)

        t = self.make_tree(self.main, ("ID","Reporter","Type","Target","Reason","Status","Date"),
                           [40,120,70,60,180,80,130])
        try:
            for rp in db.get_all_reports():
                t.insert("","end",values=(rp['report_id'],
                    f"{rp.get('first_name','')} {rp.get('last_name','')}",
                    rp.get('reported_type'), rp.get('reported_id'),
                    rp.get('reason'), rp.get('status'),
                    str(rp.get('created_at',''))[:16]))
        except: pass

    def _admin_set_report_status(self, tree, status):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a report")
            return
        try:
            rid = tree.item(sel[0])['values'][0]
            db.update_report_status(rid, status)
            messagebox.showinfo("Done", f"Report marked as {status}.")
            self.admin_reports()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _admin_deactivate_report_target(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a report")
            return
        rid = tree.item(sel[0])['values'][0]
        if not messagebox.askyesno("Confirm", "Deactivate the reported target and resolve this report?"):
            return
        try:
            db.deactivate_report_target(rid)
            messagebox.showinfo("Done", "Reported target deactivated and report resolved.")
            self.admin_reports()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _admin_upd_report(self, tree):
        sel = tree.selection()
        if not sel: return
        try:
            db.update_report_status(tree.item(sel[0])['values'][0], self.ar_st.get())
            messagebox.showinfo("Done", "Report updated!"); self.admin_reports()
        except Exception as e: messagebox.showerror("Error", str(e))

    def admin_notifs(self):
        self.set_active(8); self.clr()
        self.hdr("Send Notification", "Alert users")

        fm = ctk.CTkFrame(self.main, fg_color=C["card"], corner_radius=22)
        fm.pack(fill="x", padx=25, pady=10)
        ctk.CTkLabel(fm, text="Admin accounts can be created here safely by an existing admin. Public registration still allows only Buyer/Seller.", text_color=C["muted"], font=("Segoe UI", 11)).pack(anchor="w", padx=15, pady=(10, 0))
        r = ctk.CTkFrame(fm, fg_color=C["card"])
        r.pack(fill="x", padx=15, pady=12)
        ctk.CTkLabel(r, text="User ID:").grid(row=0, column=0, padx=5)
        self.an_uid = ctk.CTkEntry(r, width=60, height=35, corner_radius=8)
        self.an_uid.grid(row=0, column=1, padx=5)
        ctk.CTkLabel(r, text="Type:").grid(row=0, column=2, padx=5)
        self.an_type = ctk.CTkComboBox(r, values=["system","promotion","order_update"], width=130, height=35)
        self.an_type.grid(row=0, column=3, padx=5)
        ctk.CTkLabel(r, text="Title:").grid(row=0, column=4, padx=5)
        self.an_title = ctk.CTkEntry(r, width=150, height=35, corner_radius=8)
        self.an_title.grid(row=0, column=5, padx=5)
        ctk.CTkLabel(r, text="Content:").grid(row=0, column=6, padx=5)
        self.an_content = ctk.CTkEntry(r, width=200, height=35, corner_radius=8)
        self.an_content.grid(row=0, column=7, padx=5)
        ctk.CTkButton(r, text="📤 Send", fg_color=C["green"], width=80, height=35,
                      corner_radius=8, command=self._send_notif).grid(row=0, column=8, padx=5)

        t = self.make_tree(self.main, ("ID","User","Type","Title","Content","Read","Date"),
                           [40,100,80,120,180,45,125])
        try:
            for n in db.get_notifications():
                t.insert("","end",values=(n['notification_id'],
                    f"{n.get('first_name','')} {n.get('last_name','')}",
                    n.get('type'), n.get('title'), n.get('content','')[:40],
                    "✅" if n.get('is_read') else "❌",
                    str(n.get('created_at',''))[:16]))
        except: pass

    def _send_notif(self):
        try:
            db.add_notification(int(self.an_uid.get()), self.an_type.get(),
                                self.an_title.get(), self.an_content.get())
            messagebox.showinfo("Done", "Notification sent!"); self.admin_notifs()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ================================================================
    # Notification actions: read/unread/delete
    # ================================================================
    def _selected_notification_id(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a notification first.")
            return None
        return tree.item(sel[0])["values"][0]

    def _set_notification_read_state(self, notification_id, is_read):
        try:
            db._execute("UPDATE notification SET is_read=%s WHERE notification_id=%s AND user_id=%s",
                        (bool(is_read), notification_id, self.logged_user["user_id"]))
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return False
        return True

    def _set_all_notifications_read_state(self, is_read):
        try:
            db._execute("UPDATE notification SET is_read=%s WHERE user_id=%s",
                        (bool(is_read), self.logged_user["user_id"]))
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return False
        return True

    def _delete_notification(self, notification_id):
        try:
            db._execute("DELETE FROM notification WHERE notification_id=%s AND user_id=%s",
                        (notification_id, self.logged_user["user_id"]))
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return False
        return True

    def _refresh_buyer_notifs_after(self, ok):
        if ok:
            self.buyer_notifs()

    # ================================================================
    # Live auction countdown animation
    # ================================================================
    def _auction_time_left_text(self, end_time, status):
        status = str(status or "").lower()
        if status == "ended":
            return "ENDED"
        try:
            if isinstance(end_time, str):
                end_dt = datetime.fromisoformat(str(end_time).replace("Z", "").replace(" ", "T"))
            else:
                end_dt = end_time
            diff = end_dt - datetime.now()
            total = int(diff.total_seconds())
            if total <= 0:
                return "ENDING NOW"
            days = total // 86400
            hours = (total % 86400) // 3600
            mins = (total % 3600) // 60
            secs = total % 60
            if days > 0:
                return f"{days}d {hours:02d}h {mins:02d}m"
            return f"{hours:02d}:{mins:02d}:{secs:02d}"
        except Exception:
            return "LIVE"

    def _start_countdown_label(self, label, end_time, status):
        def tick():
            try:
                txt = self._auction_time_left_text(end_time, status)
                label.configure(text=txt)
                if txt not in ("ENDED", "ENDING NOW"):
                    self.after(1000, tick)
            except Exception:
                pass
        tick()


if __name__ == "__main__":
    app = MarketplaceApp()
    app.mainloop()
